# -*- coding: utf-8 -*-
"""recorder.py - マイク録音 (第2段)

ホットキー押下中にマイク入力を溜め、解放で numpy 配列(16kHz モノラル)を返す。
faster-whisper はこの配列をそのまま受け取れる(ffmpeg 不要)。
"""

import numpy as np
import sounddevice as sd

SAMPLE_RATE = 16000


class Recorder:
    """押下中だけ録音するシンプルなレコーダー。"""

    def __init__(self, sample_rate=SAMPLE_RATE):
        self.sample_rate = sample_rate
        self._frames = []
        self._stream = None

    def start(self):
        """録音を開始する。"""
        self._frames = []
        self._stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="float32",
            callback=self._callback,
        )
        self._stream.start()

    def _callback(self, indata, frames, time_info, status):
        self._frames.append(indata.copy())

    def stop(self):
        """録音を停止し、float32 の1次元配列を返す。"""
        if self._stream is None:
            return np.zeros(0, dtype="float32")
        try:
            self._stream.stop()
            self._stream.close()
        finally:
            self._stream = None
        if not self._frames:
            return np.zeros(0, dtype="float32")
        return np.concatenate(self._frames, axis=0).flatten().astype("float32")


def read_wav_file(path, target_sr=SAMPLE_RATE):
    """WAV ファイルを読み、float32 の16kHzモノラル配列にして返す。

    検証(--test-wav)と性能比較で使う。標準ライブラリ wave のみで完結する。
    """
    import wave

    with wave.open(str(path), "rb") as w:
        sr = w.getframerate()
        ch = w.getnchannels()
        sampwidth = w.getsampwidth()
        raw = w.readframes(w.getnframes())

    if sampwidth == 2:
        data = np.frombuffer(raw, dtype="<i2").astype("float32") / 32768.0
    elif sampwidth == 4:
        data = np.frombuffer(raw, dtype="<i4").astype("float32") / 2147483648.0
    elif sampwidth == 1:
        data = (np.frombuffer(raw, dtype="uint8").astype("float32") - 128.0) / 128.0
    else:
        raise ValueError(f"未対応のWAV形式です(sampwidth={sampwidth})")

    if ch > 1:
        data = data.reshape(-1, ch).mean(axis=1)
    if sr != target_sr and len(data) > 0:
        idx = (np.arange(int(len(data) * target_sr / sr)) * sr / target_sr).astype(int)
        idx = idx[idx < len(data)]
        data = data[idx]
    return data.astype("float32")
