# -*- coding: utf-8 -*-
"""mic_check.py - マイクの自己診断 (Round4)

マイクが正しく拾えているかを、実際に数秒録音して音量レベルで判定する。
「ホットキーを押しても文字が出ない」時に、原因がマイク側かを切り分けられる。
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402

SAMPLE_RATE = 16000


def list_input_devices():
    """録音に使える入力デバイスの (番号, 名前) 一覧を返す。"""
    import sounddevice as sd

    devices = []
    for idx, dev in enumerate(sd.query_devices()):
        if dev.get("max_input_channels", 0) > 0:
            devices.append((idx, dev.get("name", "")))
    return devices


def judge_level(peak):
    """録音のピーク音量(0.0〜1.0)から状態を判定する。

    戻り値: (状態, メッセージ)
    """
    if peak < 0.01:
        return ("無音", "ほとんど音を拾えていません。マイクのミュート・接続・"
                        "既定デバイスの設定を確認してください。")
    if peak < 0.05:
        return ("小さい", "音は拾えていますが小さめです。マイクに近づくか、"
                          "Windowsのマイク音量を上げると安定します。")
    return ("OK", "マイクは正常に音を拾えています。")


def record_and_measure(seconds=3):
    """seconds 秒録音し、(ピーク, 実効値RMS) を返す。"""
    import sounddevice as sd

    audio = sd.rec(int(seconds * SAMPLE_RATE), samplerate=SAMPLE_RATE,
                   channels=1, dtype="float32")
    sd.wait()
    audio = audio.flatten()
    if audio.size == 0:
        return 0.0, 0.0
    peak = float(np.max(np.abs(audio)))
    rms = float(np.sqrt(np.mean(audio ** 2)))
    return peak, rms


def main():
    print("=" * 56)
    print(" マイク自己診断")
    print("=" * 56)
    try:
        devices = list_input_devices()
    except Exception as e:
        print(f"音声デバイスの取得に失敗しました: {e}")
        input("Enterキーで閉じます...")
        return 1

    print(" 使えるマイク(入力デバイス):")
    for idx, name in devices:
        print(f"   [{idx}] {name}")
    if not devices:
        print("   入力デバイスが見つかりません。マイクの接続を確認してください。")
        input("Enterキーで閉じます...")
        return 1

    print("-" * 56)
    input(" 準備ができたら Enter を押し、3秒間マイクに話してください...")
    print(" 録音中...")
    peak, rms = record_and_measure(3)
    state, message = judge_level(peak)
    print("-" * 56)
    print(f" 判定: {state}")
    print(f" {message}")
    print(f" (ピーク音量={peak:.3f} / 平均={rms:.3f})")
    input("Enterキーで閉じます...")
    return 0


if __name__ == "__main__":
    sys.exit(main())
