# -*- coding: utf-8 -*-
"""check_gpu.py - GPU確認 + 本番モデルの事前ダウンロード (セットアップ.batから実行)

(Step1) 本番で使うモデル(settings.json の model_size)を実際に CUDA でロードする。
初回ダウンロードのもたつき・リンクエラーをセットアップ時に済ませておくことで、
本番の初回起動から GPU で高速に動くようにする。
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    print("GPU(CUDA)の確認と、音声認識モデルの事前ダウンロードを行います。")
    print("初回はモデルのダウンロードで数分かかることがあります...")

    try:
        settings = json.loads(
            (ROOT / "config" / "settings.json").read_text(encoding="utf-8")
        )
    except Exception:
        settings = {}
    model_size = settings.get("model_size", "large-v3-turbo")

    sys.path.insert(0, str(ROOT / "src"))
    try:
        from transcriber import Transcriber
    except ImportError:
        print("  faster-whisper が未インストールです。セットアップが未完了です。")
        return

    transcriber = Transcriber(settings)
    if transcriber.device == "cuda":
        print(f"  -> OK: GPU(CUDA)で {model_size} が使えます。高速に動きます。")
    else:
        print("  -> CPUで動作します(GPUは使えませんでした)。認識がかなり遅くなります。")
        if transcriber.cpu_fallback_reason:
            print(f"     原因: {transcriber.cpu_fallback_reason}")
        print("     GPUドライバ/CUDA環境を確認のうえ、再度実行してみてください。")


if __name__ == "__main__":
    main()
