# -*- coding: utf-8 -*-
"""proofread_cli.py - 今日の履歴を Ollama で推敲する(裏方・非リアルタイム)

トレイ「今日の履歴を推敲する (AI)」と、 ツール終了時に、 別プロセスとして
無窓で呼ばれる。 本番のリアルタイム認識には一切影響しない(速度を守る)。
Ollama が無い・落ちている時は静かに何もしない(安全側)。

使い方:
    pythonw proofread_cli.py          # 推敲だけ(終了時に裏で実行)
    pythonw proofread_cli.py --open   # 推敲後に結果をメモ帳で開く(手動実行)
"""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import history  # noqa: E402
from punctuate import (  # noqa: E402
    proofread_history_file, warmup_proofread, unload_model,
)

SETTINGS_PATH = ROOT / "config" / "settings.json"


def _load_settings():
    """設定だけ直接読む(fillers 等は推敲に不要なので load_config は使わない)。"""
    try:
        return json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _mark_proofread_done():
    """自動推敲スケジューラ向けに「今日推敲した」印を settings に残す。

    read-modify-write で他のキーを壊さない。一時ファイル経由で原子的に置換。
    """
    import datetime
    try:
        s = _load_settings()
        s["last_proofread_date"] = f"{datetime.datetime.now():%Y%m%d}"
        tmp = SETTINGS_PATH.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(s, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")
        tmp.replace(SETTINGS_PATH)
    except Exception:
        pass


def main(argv):
    open_after = "--open" in argv
    settings = _load_settings()
    src_path = history.today_log()
    if not src_path.exists():
        return 0
    warmup_proofread(settings)
    out_path = proofread_history_file(src_path, settings)
    if out_path:
        # 育つAI第2段: 推敲結果から誤変換ペア候補を抽出して蓄積する。
        # 純Python処理(Ollama不要)。失敗しても推敲結果は守る(安全側)。
        try:
            import learning
            learning.update_from_refined(src_path, out_path)
        except Exception:
            pass
        _mark_proofread_done()
    # バッチ完了後、モデルをメモリから降ろして PC を軽く保つ。
    unload_model(settings)
    if open_after and out_path and Path(out_path).exists():
        try:
            os.startfile(str(out_path))
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
