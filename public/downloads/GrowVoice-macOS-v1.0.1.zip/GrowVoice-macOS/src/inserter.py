# -*- coding: utf-8 -*-
"""inserter.py - カーソル位置へのテキスト挿入 (第2段 / Mac対応)

2つの方式を用意し、確実な方を使う:
  方式1 クリップボード経由(高速・確実。既定)
  方式2 直接入力(Unicode)。クリップボードが他プロセスにロックされて
        使えない時の自動フォールバック。Mac は直接入力に等価物が無いので
        platform_compat.type_text_directly が False を返し、上位はリトライする。

挿入前のクリップボード内容は退避し、挿入後に元へ戻す。

初回挿入が失敗する問題への対策:
  - 録音キー(Win: Ctrl+Alt / Mac: 右⌥)を離した「直後」 は
    keyboard / pynput の非同期キューで「修飾キーがまだ押下中」と
    判定されることがあり、ただの「v」キーが送られて貼り付けが効かない。
  - 対策として platform_compat.paste_at_cursor() が修飾キーの解放を
    最大 250ms 待ってから Ctrl+V (Win) / Cmd+V (Mac) を送る。
  - 加えて起動時 warmup() で pyperclip(OLE / NSPasteboard)の初回コストを
    潰しておき、一発目の挿入が遅延しないようにする。

旦那様の Windows 環境では、挙動は従来と同一。OS 差は platform_compat 側で吸収。
"""

import threading
import time

import pyperclip

import platform_compat


def _clip_copy(text, retries=6, wait=0.1):
    """クリップボードへのコピーをリトライ付きで行う。成否を返す。"""
    for _ in range(retries):
        try:
            pyperclip.copy(text)
            return True
        except Exception:
            time.sleep(wait)
    return False


def _clip_paste(retries=6, wait=0.1):
    """クリップボードの読み取りをリトライ付きで行う。失敗時は空文字。"""
    for _ in range(retries):
        try:
            return pyperclip.paste()
        except Exception:
            time.sleep(wait)
    return ""


def _insert_via_clipboard(text, restore_delay=0.10):
    """高速化版:貼り付けキーを送ったら即 return し、クリップボード復元は
    別スレッドで行う。旦那様体感の挿入時間が 0.2s → 0.05s 程度に縮む。
    貼り付けキーの送信(Win: Ctrl+V / Mac: Cmd+V)と、その直前の修飾キー
    解放待ちは platform_compat.paste_at_cursor() が担当する。
    """
    saved = _clip_paste()
    if not _clip_copy(text):
        return False
    try:
        time.sleep(0.02)  # クリップボード反映待ち
        platform_compat.paste_at_cursor()
    except Exception:
        _clip_copy(saved)
        return False

    # クリップボード復元は挿入完了後に別スレッドで(旦那様を待たせない)
    def _restore_in_background():
        try:
            time.sleep(restore_delay)
            _clip_copy(saved)
        except Exception:
            pass
    threading.Thread(target=_restore_in_background, daemon=True).start()
    return True


def _insert_via_typing(text):
    """直接入力。Win では Unicode 注入なので IME を経由しない。
    Mac には等価物が無く、platform_compat.type_text_directly() は False を返す。
    """
    try:
        if platform_compat.type_text_directly(text):
            return True
        print(" 【エラー】直接入力に失敗しました(この OS ではサポート外)。")
        return False
    except Exception as e:
        print(f" 【エラー】直接入力に失敗しました: {e}")
        return False


def insert_text(text):
    """text をカーソル位置に挿入する。成功したら True を返す。

    クリップボードが使えない時は自動で直接入力に切り替える。
    """
    if not text:
        return False
    if _insert_via_clipboard(text):
        return True
    print(" クリップボードが使えないため直接入力に切り替えます。")
    return _insert_via_typing(text)


def warmup():
    """起動時に1回だけ呼ぶ。一発目の挿入が遅延しないように、
    pyperclip(OLE / NSPasteboard)の初回呼び出しコストと修飾キー判定の
    内部状態を事前に暖機する。

    具体的にやっていること:
      1. クリップボードの読み書きを1往復(OLE 初期化を済ませる)
      2. 修飾キー押下判定の初回コストも軽く払う
    """
    try:
        original = _clip_paste(retries=2, wait=0.02)
        _clip_copy(original or "", retries=2, wait=0.02)
    except Exception:
        pass
    try:
        platform_compat.is_modifier_held("ctrl")
        platform_compat.is_modifier_held("alt")
    except Exception:
        pass
