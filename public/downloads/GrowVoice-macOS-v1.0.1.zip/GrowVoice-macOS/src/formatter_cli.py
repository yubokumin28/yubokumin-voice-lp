# -*- coding: utf-8 -*-
"""formatter_cli.py - 整形エンジンを手で試すCLI(第1段の動作確認用)。

文章を入力してEnterを押すと、整形(1)(2)(3)の結果が出る。
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from formatter import load_config, format_text  # noqa: E402

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


def main():
    try:
        config = load_config(CONFIG_DIR)
    except ValueError as e:
        print("【エラー】" + str(e))
        input("Enterキーで閉じます...")
        return

    n_rep = len(config.get("replacements", []))
    print("=" * 56)
    print(" 整形エンジン お試しモード")
    print("=" * 56)
    print(" 文章を入力してEnterを押すと、整形結果が出ます。")
    print(" 整形は (1)繰り返し除去 (2)フィラー除去 (3)誤変換の置換。")
    print(f" 現在の置換辞書の登録数: {n_rep} 件")
    print(" 何も入力せずEnter、または q で終了します。")
    print("-" * 56)

    while True:
        try:
            text = input("\n入力 > ")
        except (EOFError, KeyboardInterrupt):
            break
        if text.strip() in ("", "q", "Q"):
            break
        result = format_text(text, config)
        print("整形 > " + result)

    print("\n終了しました。")


if __name__ == "__main__":
    main()
