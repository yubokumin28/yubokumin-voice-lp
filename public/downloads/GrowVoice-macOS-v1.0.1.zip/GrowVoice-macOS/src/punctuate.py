# -*- coding: utf-8 -*-
"""punctuate.py - ローカルAIで句読点を補う (④ AI整形)

音声認識の生テキストには句読点が付きにくく読みづらい。PC内で動く Ollama に
「言葉は変えず、と。だけ補って」と指示し、読みやすく整える。

通信先は localhost の Ollama だけ。ネット越しのAIは使わない(完全ローカル)。

安全第一の設計:
  - Ollama が無い・遅い・落ちている時は、元のテキストをそのまま使う。
  - AI が句読点以外を書き換えた疑いがある時も、元のテキストを使う
    (句読点を除いた中身が元と一致するかで判定)。
  - 一度失敗したら以降はAIを呼ばない(毎回タイムアウトを待たないため)。
"""

import json
import re
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / "config"

# Ollama が使えるか。呼び出し失敗で False になり、以降はAIを呼ばない。
_available = True

_PROMPT = (
    "次の日本語の文に句読点(読点「、」と句点「。」)だけを補ってください。\n"
    "厳守事項:\n"
    "- 言葉・語順・漢字かな表記は一切変えない。誤字も直さない。\n"
    "- 追加してよいのは「、」と「。」だけ。それ以外の記号は足さない。\n"
    "- 元からある記号(「?」など)はそのまま残す。\n"
    "- 説明や前置きを書かず、句読点を補った文だけを1行で出力する。\n"
    "対象の文:\n"
)

# 鉤括弧モード(オプション・既定OFF)
# 旦那様が settings.json で punctuation_brackets:true にしたときだけ使う。
# 引用・台詞っぽい箇所を「」で括る判断を Ollama に任せる。誤判定リスクあり
# だが、句読点モードと同じく「言葉を変えていない」フィルタで安全側に倒す。
_PROMPT_WITH_BRACKETS = (
    "次の日本語の文に句読点(「、」「。」)と鉤括弧(「」)を補ってください。\n"
    "厳守事項:\n"
    "- 言葉・語順・漢字かな表記は一切変えない。誤字も直さない。\n"
    "- 追加してよいのは「、」「。」「「」「」」のみ。それ以外の記号は足さない。\n"
    "- 鉤括弧は明確な引用・台詞・呼称(『XXさんは「Y」と言った』『「ABC」プロジェクト』)に限る。\n"
    "  迷ったら付けない。文章全体を括らない。\n"
    "- 元からある記号(「?」など)はそのまま残す。\n"
    "- 説明や前置きを書かず、補った文だけを1行で出力する。\n"
    "対象の文:\n"
)


def _strip_marks(text):
    """比較用に、句読点・括弧・空白を除いた文字列を返す。"""
    return re.sub(r"[、。「」\s]", "", text)


def _accept_or_fallback(original, ai_output):
    """AIの出力を採用してよいか判定する。だめなら original を返す。

    句読点(と空白)を除いた中身が元と一致しない = AIが言葉を書き換えた、
    または前置き等を足した、とみなして採用しない。
    """
    if not ai_output:
        return original
    if _strip_marks(ai_output) != _strip_marks(original):
        return original
    return ai_output


def _call_ollama(prompt, settings, timeout):
    """Ollama の生成APIを1回呼び、応答テキストを返す。"""
    base = settings.get("ollama_url", "http://localhost:11434").rstrip("/")
    payload = {
        "model": settings.get("ollama_model", "gemma4:latest"),
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0},
        # バッチ中はモデルを保持し、終了後に unload_model で降ろす
        "keep_alive": settings.get("ollama_keep_alive", "5m"),
    }
    req = urllib.request.Request(
        base + "/api/generate",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    return (result.get("response") or "").strip()


def unload_model(settings):
    """推敲バッチの後にモデルをメモリ(RAM/VRAM)から降ろす。

    keep_alive:0 を送ると Ollama は即座にモデルを解放する。PC を軽く保つため
    自動推敲の最後に呼ぶ。失敗しても無視(安全側)。
    """
    try:
        base = settings.get("ollama_url", "http://localhost:11434").rstrip("/")
        payload = {"model": settings.get("ollama_model", "gemma4:latest"),
                   "keep_alive": 0}
        req = urllib.request.Request(
            base + "/api/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=10).close()
    except Exception:
        pass


def _pick_prompt(settings):
    """設定に応じて句読点専用 or 鉤括弧付きプロンプトを選ぶ。
    punctuation_brackets:true の時だけ鉤括弧版(既定 false=句読点のみ)。"""
    if settings.get("punctuation_brackets", False):
        return _PROMPT_WITH_BRACKETS
    return _PROMPT


def add_punctuation(text, settings):
    """text に句読点を補って返す。失敗・不審な書き換え時は text をそのまま返す。"""
    global _available
    if not text or not settings.get("punctuation", True) or not _available:
        return text
    timeout = float(settings.get("ollama_timeout_sec", 6.0))
    prompt = _pick_prompt(settings)
    try:
        out = _call_ollama(prompt + text, settings, timeout)
    except Exception as e:
        _available = False
        print(f" 【情報】句読点AIを使えないため、以降は元の文のまま挿入します: {e}")
        return text
    return _accept_or_fallback(text, out)


def warmup(settings):
    """起動時にモデルを1度読み込み、初回の待ちを減らす。

    モデルの読み込みは時間がかかるのでタイムアウトを長めにとる。
    失敗した時は以降AIを呼ばない(句読点なしで動作)。
    """
    global _available
    if not settings.get("punctuation", True):
        return
    try:
        _call_ollama(_pick_prompt(settings) + "テストです", settings, timeout=90.0)
    except Exception as e:
        _available = False
        print(f" 【情報】句読点AI(Ollama)の準備に失敗。句読点なしで動作します: {e}")


# ---------------------------------------------------------------------------
# 推敲(④ 育つAI 第1段)- 句読点だけでなく「明らかな誤認識」も直す
# ---------------------------------------------------------------------------
# 句読点モード(add_punctuation)は「言葉を一切変えない」 安全設計だが、
# 旦那様の要望は「本当はこう言いたかった」 に近づけること。 そこで誤字訂正も
# 許す推敲モードを別に用意する。 リアルタイム認識には使わず、 終了時/手動で
# 履歴をまとめて推敲する裏方専用(速度に一切影響しない)。

_PROOFREAD_PROMPT = (
    "次は音声認識された日本語の文です。 読みやすい自然な文に整えてください。\n"
    "やってよいこと:\n"
    "- まず文の切れ目を見極め、一文ごとに「。」で区切る(話が変わる所で必ず文を切る)。\n"
    "- 意味のまとまりの区切りに「、」を打つ(多すぎず、自然な位置に)。\n"
    "- 疑問の文末(〜ですか・〜かな・〜だっけ・〜だろう 等)は「。」でなく「?」にする。\n"
    "- 明確な引用・発話・作品名・特に強調したい語だけ、控えめに「」で囲む。\n"
    "- 明らかな誤認識・誤字を、 文脈から正しい語に直す。\n"
    "厳守事項:\n"
    "- 話した内容・意味・語順は変えない。 新しい情報や言葉を足さない。\n"
    "- 擬態語・擬音語・言い回し(どんどん・ぐっと・きらきら 等)は別の語に変えない。\n"
    "- 「」は付けすぎない。引用や強調だと確信できない所には付けない(迷ったら付けない)。\n"
    "- 説明や前置きを書かず、 整えた文だけを1行で出力する。\n"
    "対象の文:\n"
)


# ---------------------------------------------------------------------------
# 句読点の個人ルール化(③ 育つ句読点)
# ---------------------------------------------------------------------------
# 旦那様が実際に使った文(推敲済み)から「読点入りの文」をためておき、推敲AIに
# お手本として見せる。使うほど旦那様の句読点の付け方(読点の量・区切り位置)に
# 寄っていく。speed: その場の挿入には一切関与しない(裏の推敲だけが少し賢くなる)。
# settings の punctuation_personalize:false で無効化、punct_style_max で例の数。

def _style_path(config_dir=None):
    base = Path(config_dir) if config_dir else CONFIG_DIR
    return base / "punct_style.json"


def _load_style_examples(config_dir=None):
    """お手本文のリストを返す(壊れていたら空)。"""
    try:
        data = json.loads(_style_path(config_dir).read_text(encoding="utf-8"))
        ex = data.get("examples", [])
        return [s for s in ex if isinstance(s, str) and s.strip()]
    except Exception:
        return []


def _build_style_prefix(examples):
    """お手本文から few-shot ブロックを作る。例が無ければ空文字。"""
    if not examples:
        return ""
    lines = "\n".join(f"・{s}" for s in examples)
    return ("次の例は、この人が好む句読点・区切りの付け方です。\n"
            "読点(、)の量や区切る位置の癖を、この文体に倣ってください。\n"
            f"{lines}\n\n")


def update_style_from_refined(refined_path, settings=None, config_dir=None,
                              max_examples=None):
    """推敲済みファイルから「読点入りの自然な文」をお手本に取り込む(ローリング)。

    旦那様の実際の語彙・文の形を反映した例だけを残す。新しいものを優先し、
    重複を除いて最新 max_examples 件に保つ。失敗しても何もしない(安全側)。
    """
    settings = settings or {}
    if not settings.get("punctuation_personalize", True):
        return
    if max_examples is None:
        max_examples = int(settings.get("punct_style_max", 6))
    try:
        text = Path(refined_path).read_text(encoding="utf-8")
    except Exception:
        return
    fresh = []
    for line in text.splitlines():
        m = _HISTORY_LINE_RE.match(line)
        body = (m.group(2) if m else line).strip()
        # 読点を含み、長すぎず短すぎない自然な一文だけをお手本にする
        if "、" in body and 12 <= len(body) <= 70 and body not in fresh:
            fresh.append(body)
    if not fresh:
        return
    old = _load_style_examples(config_dir)
    # 新しい例を前に、既存を後ろに。重複を除いて最新 max_examples 件。
    merged = []
    for s in fresh + old:
        if s not in merged:
            merged.append(s)
    merged = merged[:max_examples]
    try:
        _style_path(config_dir).write_text(
            json.dumps({"version": 1, "examples": merged},
                       ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8")
    except Exception:
        pass


def _accept_proofread(original, ai_output):
    """推敲結果を緩く検査する。 不審(空・極端な長さ変化)なら original を返す。

    句読点モードと違い誤字訂正を許すので中身の一致は求めない。 代わりに、
    前置き混入や暴走を弾くため「1行目だけ・長さが元の0.5〜1.8倍」を条件にする。
    """
    if not ai_output or not ai_output.strip():
        return original
    out = ai_output.strip().splitlines()[0].strip()
    if not out:
        return original
    n0, n1 = len(original), len(out)
    if n1 < max(2, n0 * 0.5) or n1 > n0 * 1.8:
        return original
    return out


def proofread_text(text, settings, style_prefix=""):
    """text を推敲して返す。 失敗・不審時は text をそのまま返す(安全側)。

    style_prefix: 句読点の個人化お手本(few-shot)。空なら従来どおり。
    """
    global _available
    if not text or not _available:
        return text
    timeout = float(settings.get("proofread_timeout_sec", 15.0))
    try:
        out = _call_ollama(style_prefix + _PROOFREAD_PROMPT + text,
                           settings, timeout)
    except Exception as e:
        _available = False
        print(f" 【情報】推敲AIを使えないため、 推敲をスキップします: {e}")
        return text
    return _accept_proofread(text, out)


def warmup_proofread(settings):
    """推敲用にモデルを1度読み込み、 初回の待ちを減らす。"""
    global _available
    try:
        _call_ollama(_PROOFREAD_PROMPT + "テストです", settings, timeout=90.0)
    except Exception as e:
        _available = False
        print(f" 【情報】推敲AI(Ollama)の準備に失敗。 推敲をスキップします: {e}")


_HISTORY_LINE_RE = re.compile(r"^(\[\d{2}:\d{2}:\d{2}\]\s*)(.*)$")


def proofread_history_file(src_path, settings):
    """history_YYYYMMDD.txt を推敲し history_YYYYMMDD_refined.txt に書き出す。

    各行 "[HH:MM:SS] 本文" の本文だけを推敲する。 生テキスト補足行
    "    (認識の生テキスト: ...)" 等はそのまま残す。 元ファイルは消さない。
    返り値: 出力ファイルパス(対象が無ければ None)。
    """
    src_path = Path(src_path)
    if not src_path.exists():
        return None
    # 句読点の個人化: ためたお手本を few-shot として推敲AIに見せる(任意)。
    style_prefix = ""
    if settings.get("punctuation_personalize", True):
        style_prefix = _build_style_prefix(_load_style_examples())
    out_path = src_path.with_name(src_path.stem + "_refined.txt")
    out_lines = []
    for line in src_path.read_text(encoding="utf-8").splitlines():
        m = _HISTORY_LINE_RE.match(line)
        if m and m.group(2).strip():
            out_lines.append(
                m.group(1) + proofread_text(m.group(2), settings, style_prefix))
        else:
            out_lines.append(line)
    out_path.write_text("\n".join(out_lines) + "\n", encoding="utf-8")
    # 今回の推敲結果から、次回用のお手本を更新する(ローリング)。
    try:
        update_style_from_refined(out_path, settings)
    except Exception:
        pass
    return out_path
