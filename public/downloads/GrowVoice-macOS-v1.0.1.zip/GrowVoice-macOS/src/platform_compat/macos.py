# -*- coding: utf-8 -*-
"""macos.py - platform_compat の macOS 実装

旦那様の方針:
  - 既存の Windows 挙動は 1 ミリも変えない。本ファイルは macOS で起動した
    ときだけ読まれる(__init__.py が sys.platform で振り分け)。
  - 重い外部ライブラリ(pynput / pyobjc / fcntl)は Windows でも構文チェック
    だけは通したいので、すべて関数内で遅延 import する。

提供する関数とクラスは base.py の仕様に従う。意味論は windows.py と同じで、
本体側コードは OS を意識しない。
"""

import os
import subprocess
import sys
import threading
import time
from pathlib import Path


# ---------------------------------------------------------------------------
# プロジェクトルート(windows.py と同じ仕組み)
# ---------------------------------------------------------------------------
_ROOT = Path(__file__).resolve().parents[2]


def set_project_root(path):
    global _ROOT
    _ROOT = Path(path)


# ---------------------------------------------------------------------------
# 内部状態:押下中の修飾キーを追跡する(is_modifier_held / paste_at_cursor が参照)
# ---------------------------------------------------------------------------
_held_modifiers = set()
_held_lock = threading.Lock()


# ===========================================================================
# ホットキー(pynput.keyboard.Listener)
# ===========================================================================

# 設定 UI のキー名 ("right alt" / "right option" / "ctrl+alt" 等) を
# pynput.keyboard.Key の属性名に対応づける表。値は属性名の文字列で、
# 関数内で getattr(keyboard.Key, name) として解決する。
_KEY_NAME_TO_PYNPUT = {
    "right alt": "alt_r",
    "right option": "alt_r",
    "left alt": "alt_l",
    "left option": "alt_l",
    "alt": "alt",
    "alt gr": "alt_gr",
    "right ctrl": "ctrl_r",
    "right control": "ctrl_r",
    "left ctrl": "ctrl_l",
    "left control": "ctrl_l",
    "ctrl": "ctrl",
    "control": "ctrl",
    "right shift": "shift_r",
    "left shift": "shift_l",
    "shift": "shift",
    "right cmd": "cmd_r",
    "right command": "cmd_r",
    "right windows": "cmd_r",
    "left cmd": "cmd_l",
    "left command": "cmd_l",
    "left windows": "cmd_l",
    "cmd": "cmd",
    "command": "cmd",
    "windows": "cmd",
    "space": "space",
    "enter": "enter",
    "tab": "tab",
    "esc": "esc",
    "escape": "esc",
}


# pynput の Key を「修飾キー汎用名(ctrl / alt / shift / cmd)」に対応づける表。
# is_modifier_held("ctrl") などの判定はこの汎用名で集合 _held_modifiers を参照する。
_PYNPUT_TO_GENERIC = {
    "ctrl": "ctrl", "ctrl_l": "ctrl", "ctrl_r": "ctrl",
    "alt": "alt", "alt_l": "alt", "alt_r": "alt", "alt_gr": "alt",
    "shift": "shift", "shift_l": "shift", "shift_r": "shift",
    "cmd": "cmd", "cmd_l": "cmd", "cmd_r": "cmd",
}


def _resolve_target_keys(key_label):
    """設定 UI のキー名("right alt" 等)から、マッチさせる pynput Key 群を返す。

    "ctrl+alt" のような組み合わせは未サポート(旦那様の Mac 既定は右⌥ 単独)。
    複合キーが来た場合は、最後の要素(主キー)だけを採用する。
    """
    from pynput import keyboard as _kb

    parts = [p.strip().lower() for p in str(key_label).split("+") if p.strip()]
    if not parts:
        return []
    name = parts[-1]
    attr = _KEY_NAME_TO_PYNPUT.get(name)
    if attr is None:
        # マップに無いキーは KeyCode.from_char で扱う(1 文字キーなど)
        try:
            return [_kb.KeyCode.from_char(name)]
        except Exception:
            return []
    key = getattr(_kb.Key, attr, None)
    return [key] if key is not None else []


def _key_attr_name(key):
    """pynput のキーオブジェクトから属性名("alt_r" 等)を取り出す。"""
    try:
        # Key 列挙体なら .name でとれる
        return key.name
    except AttributeError:
        return None


def is_modifier_held(name):
    """ctrl / alt / shift / cmd のいずれかが押下中か。"""
    n = str(name).lower().strip()
    with _held_lock:
        return n in _held_modifiers


def register_hotkey_listener(key_label, on_press, on_release):
    """録音キーのフックを登録する。

    pynput.keyboard.Listener が 1 本のスレッドで全キー押下を監視し、
      - 修飾キーの押下/解放で _held_modifiers を更新
      - 録音キーに一致した瞬間 on_press / on_release を呼ぶ
    長押し 0.3 秒の判定は呼び出し側(hotkey_app)に任せる。
    Windows 側と同じ意味論(押下瞬間 / 解放瞬間のコールバック)。
    """
    from pynput import keyboard as _kb

    targets = _resolve_target_keys(key_label)
    pressed = {"down": False}  # 連続イベント抑制用

    def _track(key, is_down):
        name = _key_attr_name(key)
        if not name:
            return
        generic = _PYNPUT_TO_GENERIC.get(name)
        if generic is None:
            return
        with _held_lock:
            if is_down:
                _held_modifiers.add(generic)
            else:
                _held_modifiers.discard(generic)

    def _matches(key):
        for t in targets:
            if t is None:
                continue
            if key == t:
                return True
        return False

    def _on_press(key):
        _track(key, True)
        if _matches(key) and not pressed["down"]:
            pressed["down"] = True
            try:
                on_press()
            except Exception:
                pass

    def _on_release(key):
        _track(key, False)
        if _matches(key) and pressed["down"]:
            pressed["down"] = False
            try:
                on_release()
            except Exception:
                pass

    listener = _kb.Listener(on_press=_on_press, on_release=_on_release)
    listener.daemon = True
    listener.start()
    return listener


def unregister_hotkey_listener(listener):
    if not listener:
        return
    try:
        listener.stop()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 全キーを on_event(event) に流す汎用フック群(hotkey_app.py 用)
# ---------------------------------------------------------------------------
# Windows の keyboard.hook / add_hotkey / unhook_all / wait と同じ意味論を
# pynput.keyboard.Listener で再現する。event オブジェクトは
#   .name        : "left alt" / "right ctrl" / "f9" / "a" など(keyboard 風)
#   .event_type  : "down" / "up"
# を持つ。これで hotkey_app.py 側のロジック(held_names のキー名追跡・
# hotkey_matches 判定)が OS を意識せず動く。

# pynput の Key 属性名 → keyboard ライブラリ風キー名 への逆引き表。
# 既存 _KEY_NAME_TO_PYNPUT の対になる(hotkey_app の held_names と
# hotkey_matches が前提とする命名規則に揃える)。
_PYNPUT_ATTR_TO_KEY_NAME = {
    "alt_r": "right alt",
    "alt_l": "left alt",
    "alt": "alt",
    "alt_gr": "alt gr",
    "ctrl_r": "right ctrl",
    "ctrl_l": "left ctrl",
    "ctrl": "ctrl",
    "shift_r": "right shift",
    "shift_l": "left shift",
    "shift": "shift",
    "cmd_r": "right windows",
    "cmd_l": "left windows",
    "cmd": "windows",
    "space": "space",
    "enter": "enter",
    "tab": "tab",
    "esc": "esc",
    "backspace": "backspace",
    "delete": "delete",
    "up": "up",
    "down": "down",
    "left": "left",
    "right": "right",
    "home": "home",
    "end": "end",
    "page_up": "page up",
    "page_down": "page down",
    "insert": "insert",
    "caps_lock": "caps lock",
    "f1": "f1", "f2": "f2", "f3": "f3", "f4": "f4", "f5": "f5",
    "f6": "f6", "f7": "f7", "f8": "f8", "f9": "f9", "f10": "f10",
    "f11": "f11", "f12": "f12",
}


class _KeyEvent:
    """Windows 側の keyboard.KeyboardEvent と互換の最小ラッパー。

    .name / .event_type を持つだけ。hotkey_app.py は両方しか参照しない。
    """

    __slots__ = ("name", "event_type")

    def __init__(self, name, event_type):
        self.name = name
        self.event_type = event_type


def _pynput_key_to_name(key):
    """pynput のキーオブジェクトから keyboard 風キー名を引く。

    Key 列挙体は .name(属性名)で逆引き、文字キー(KeyCode)は .char。
    解決できない時は None。
    """
    attr = _key_attr_name(key)
    if attr is not None:
        mapped = _PYNPUT_ATTR_TO_KEY_NAME.get(attr)
        if mapped is not None:
            return mapped
        return attr  # f13 等、表に無くても素の属性名を返す
    try:
        ch = getattr(key, "char", None)
        if ch:
            return str(ch).lower()
    except Exception:
        pass
    return None


# install_global_key_hook で起動した Listener 群を管理する。
# unhook_all_global で全停止し、 wait_forever で 1 本でも生きている間は待つ。
_global_hooks = {"listeners": [], "lock": threading.Lock()}
_global_wait_event = threading.Event()


def install_global_key_hook(on_event):
    """全キーの押下/解放イベントを on_event(event) に流す。

    Windows の keyboard.hook 相当。返り値は Listener オブジェクト。
    on_event には _KeyEvent(.name, .event_type="down"/"up") が渡る。

    内部の修飾キー追跡(_held_modifiers)も同時に更新するので、
    is_modifier_held("alt") 等が install 後すぐに正しく動く。
    """
    from pynput import keyboard as _kb

    def _track(key, is_down):
        name = _key_attr_name(key)
        if not name:
            return
        generic = _PYNPUT_TO_GENERIC.get(name)
        if generic is None:
            return
        with _held_lock:
            if is_down:
                _held_modifiers.add(generic)
            else:
                _held_modifiers.discard(generic)

    def _on_press(key):
        _track(key, True)
        name = _pynput_key_to_name(key)
        if name is None:
            return
        try:
            on_event(_KeyEvent(name, "down"))
        except Exception:
            pass

    def _on_release(key):
        _track(key, False)
        name = _pynput_key_to_name(key)
        if name is None:
            return
        try:
            on_event(_KeyEvent(name, "up"))
        except Exception:
            pass

    listener = _kb.Listener(on_press=_on_press, on_release=_on_release)
    listener.daemon = True
    listener.start()
    with _global_hooks["lock"]:
        _global_hooks["listeners"].append(listener)
    return listener


# add_emergency_reset_hotkey で起動した GlobalHotKeys を保持する。
_global_hotkeys_handles = []


def _to_pynput_hotkey(label):
    """"pause" / "ctrl+alt+r" 等のラベルを pynput GlobalHotKeys 用の文字列に変換。

    pynput は "<ctrl>+<alt>+r" のような表記を求める。
    """
    parts = [p.strip().lower() for p in str(label).split("+") if p.strip()]
    if not parts:
        return None
    # pynput 用の修飾キー表記
    mod_map = {
        "ctrl": "<ctrl>", "left ctrl": "<ctrl_l>", "right ctrl": "<ctrl_r>",
        "alt": "<alt>", "left alt": "<alt_l>", "right alt": "<alt_r>",
        "alt gr": "<alt_gr>",
        "shift": "<shift>", "left shift": "<shift_l>",
        "right shift": "<shift_r>",
        "cmd": "<cmd>", "left cmd": "<cmd_l>", "right cmd": "<cmd_r>",
        "windows": "<cmd>", "left windows": "<cmd_l>",
        "right windows": "<cmd_r>",
        "pause": "<pause>", "scroll lock": "<scroll_lock>",
        "caps lock": "<caps_lock>",
        "f1": "<f1>", "f2": "<f2>", "f3": "<f3>", "f4": "<f4>", "f5": "<f5>",
        "f6": "<f6>", "f7": "<f7>", "f8": "<f8>", "f9": "<f9>", "f10": "<f10>",
        "f11": "<f11>", "f12": "<f12>",
        "esc": "<esc>", "escape": "<esc>",
    }
    out = []
    for p in parts:
        if p in mod_map:
            out.append(mod_map[p])
        elif len(p) == 1:
            out.append(p)
        else:
            # 表に無いキー(home 等)は <name> 形に
            out.append(f"<{p}>")
    return "+".join(out)


def add_emergency_reset_hotkey(label, callback):
    """単発の緊急リセットキーを登録する(例 "pause" で callback を呼ぶ)。

    pynput.keyboard.GlobalHotKeys で実装。失敗時は例外をそのまま投げる
    (呼び出し側の Windows 同等動作と整合)。
    """
    from pynput import keyboard as _kb

    hk = _to_pynput_hotkey(label)
    if not hk:
        raise ValueError(f"緊急リセットキーのラベルを解釈できません: {label}")
    listener = _kb.GlobalHotKeys({hk: callback})
    listener.daemon = True
    listener.start()
    _global_hotkeys_handles.append(listener)
    return listener


def unhook_all_global():
    """install_global_key_hook / add_emergency_reset_hotkey で起動した
    Listener を全停止する。再登録(keepalive)前に呼ぶ。"""
    with _global_hooks["lock"]:
        listeners = list(_global_hooks["listeners"])
        _global_hooks["listeners"].clear()
    for L in listeners:
        try:
            L.stop()
        except Exception:
            pass
    handles = list(_global_hotkeys_handles)
    _global_hotkeys_handles.clear()
    for L in handles:
        try:
            L.stop()
        except Exception:
            pass


def wait_forever():
    """メインスレッドを常駐させる(プロセスが終了するまでブロック)。

    Windows の keyboard.wait() 相当。
    _global_wait_event は外部から set されない(stop_keepalive の wait と
    同じく、 os._exit で終了する設計)。
    """
    try:
        _global_wait_event.wait()
    except KeyboardInterrupt:
        pass


# ===========================================================================
# カーソル位置への挿入(AppleScript で Cmd+V を送る)
# ===========================================================================

# 修飾キーの解放を待つ最大時間(Windows 側と同じ値)
_MODIFIER_WAIT_MAX = 0.25
_MODIFIER_WAIT_POLL = 0.01


def _wait_modifiers_release(max_wait=_MODIFIER_WAIT_MAX, poll=_MODIFIER_WAIT_POLL):
    """録音キー(右⌥ 等)の解放を最大 max_wait 秒待つ。Windows と同等。"""
    waited = 0.0
    while waited < max_wait:
        if not is_modifier_held("alt") and not is_modifier_held("ctrl"):
            return True
        time.sleep(poll)
        waited += poll
    return False


def paste_at_cursor():
    """貼り付け(Cmd+V)を送る。前段でクリップボードに本文がコピーされている前提。

    録音キー(右⌥)を離した直後はまだ alt が押下中扱いで、Cmd+V を送っても
    キーが合成されて誤動作することがあるため、最大 250ms 解放を待ってから送る。
    """
    _wait_modifiers_release()
    script = 'tell application "System Events" to keystroke "v" using command down'
    try:
        subprocess.run(
            ["osascript", "-e", script],
            check=False,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=2.0,
        )
    except Exception:
        pass


def type_text_directly(text):  # noqa: ARG001
    """macOS には IME バイパスの直接注入が無い。呼び出し側はクリップボード経由で再試行する。"""
    return False


# ===========================================================================
# 単一インスタンス制御(fcntl.flock + ロックファイル)
# ===========================================================================

_LOCK_DIR = Path.home() / "Library" / "Caches"
_LOCK_NAME = "voice_input_tool.lock"


class SingleInstance:
    """flock によるロックファイルで二重起動を抑止する。"""

    def __init__(self, name=None):  # noqa: ARG002
        import fcntl

        self._fcntl = fcntl
        self._fh = None
        self.already_running = False

        try:
            _LOCK_DIR.mkdir(parents=True, exist_ok=True)
            self._fh = open(str(_LOCK_DIR / _LOCK_NAME), "w")
            try:
                fcntl.flock(self._fh.fileno(),
                            fcntl.LOCK_EX | fcntl.LOCK_NB)
                # ロック取得成功:この PID を書いておく(デバッグ用)
                try:
                    self._fh.write(str(os.getpid()))
                    self._fh.flush()
                except Exception:
                    pass
            except (BlockingIOError, OSError):
                # 既に他プロセスが握っている
                self.already_running = True
                try:
                    self._fh.close()
                except Exception:
                    pass
                self._fh = None
        except Exception:
            # ロックそのものが作れない場合は素通し(誤検知より起動失敗の方が痛い)
            self.already_running = False
            self._fh = None

    def release(self):
        if self._fh is None:
            return
        try:
            self._fcntl.flock(self._fh.fileno(), self._fcntl.LOCK_UN)
        except Exception:
            pass
        try:
            self._fh.close()
        except Exception:
            pass
        self._fh = None


# ===========================================================================
# 自動起動(LaunchAgent plist + launchctl)
# ===========================================================================

_LAUNCHAGENT_DIR = Path.home() / "Library" / "LaunchAgents"
_LAUNCHAGENT_LABEL = "com.voiceinput.tool"
_LAUNCHAGENT_FILE = _LAUNCHAGENT_DIR / f"{_LAUNCHAGENT_LABEL}.plist"


def _plist_contents():
    """LaunchAgent の plist 文字列を組み立てる。

    venv の python が無ければシステム python にフォールバック。
    起動対象は src/hotkey_app.py(本体)。
    """
    venv_python = _ROOT / ".venv" / "bin" / "python"
    python_path = str(venv_python if venv_python.exists() else sys.executable)
    script_path = str(_ROOT / "src" / "hotkey_app.py")
    workdir = str(_ROOT)

    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"'
        ' "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n'
        '<dict>\n'
        f'  <key>Label</key><string>{_LAUNCHAGENT_LABEL}</string>\n'
        '  <key>ProgramArguments</key>\n'
        '  <array>\n'
        f'    <string>{python_path}</string>\n'
        f'    <string>{script_path}</string>\n'
        '  </array>\n'
        f'  <key>WorkingDirectory</key><string>{workdir}</string>\n'
        '  <key>RunAtLoad</key><true/>\n'
        '  <key>KeepAlive</key><false/>\n'
        '  <key>ProcessType</key><string>Interactive</string>\n'
        '</dict>\n'
        '</plist>\n'
    )


def is_autostart_enabled():
    try:
        return _LAUNCHAGENT_FILE.exists()
    except Exception:
        return False


def toggle_autostart():
    """LaunchAgent を ON/OFF 反転。切替後の状態(True=ON)を返す。"""
    try:
        if _LAUNCHAGENT_FILE.exists():
            # OFF にする:unload してから plist 削除
            try:
                subprocess.run(
                    ["launchctl", "unload", str(_LAUNCHAGENT_FILE)],
                    check=False, stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL, timeout=5.0,
                )
            except Exception:
                pass
            try:
                _LAUNCHAGENT_FILE.unlink()
            except Exception:
                pass
            return False
        # ON にする:plist 生成 → load
        _LAUNCHAGENT_DIR.mkdir(parents=True, exist_ok=True)
        _LAUNCHAGENT_FILE.write_text(_plist_contents(), encoding="utf-8")
        try:
            subprocess.run(
                ["launchctl", "load", str(_LAUNCHAGENT_FILE)],
                check=False, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, timeout=5.0,
            )
        except Exception:
            pass
        return True
    except Exception:
        return is_autostart_enabled()


def get_autostart_description():
    return "macOS LaunchAgent(ログイン時起動)"


# ===========================================================================
# 子プロセス起動(無窓・分離)
# ===========================================================================

def find_no_console_python():
    """macOS は GUI 起動でターミナル窓は出ないので、ふつうの python を返す。

    venv の python を優先、無ければシステム python。
    """
    venv_python = _ROOT / ".venv" / "bin" / "python"
    if venv_python.exists():
        return str(venv_python)
    return sys.executable


def spawn_detached(python_path, script_path, *args, low_priority=False):
    """子プロセスを親プロセスから完全分離して起動する。

    start_new_session=True で新規セッショングループを切り、
    親が死んでも子は生き続け、親が SIGINT を受けても子は受けない。
    low_priority=True なら子プロセス側で os.nice(10) する。
    """
    kwargs = {
        "cwd": str(_ROOT),
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
        "start_new_session": True,
    }
    if low_priority:
        def _renice():
            try:
                os.nice(10)
            except Exception:
                pass
        kwargs["preexec_fn"] = _renice
    subprocess.Popen([python_path, str(script_path), *args], **kwargs)


# ===========================================================================
# パス・OS UI を開く
# ===========================================================================

def open_path(path):
    """ファイル/フォルダを Finder で開く。"""
    try:
        subprocess.run(["open", str(path)], check=False)
    except Exception:
        pass


def open_system_taskbar_settings():
    """メニューバー(=Windows のタスクバー相当)設定を開く。

    macOS にはピンポイントの URL が無いので Control Center 設定を開く。
    """
    try:
        subprocess.run(
            ["open",
             "x-apple.systempreferences:com.apple.ControlCenter-Settings.extension"],
            check=False,
        )
    except Exception:
        try:
            subprocess.run(["open", "-b", "com.apple.systempreferences"],
                           check=False)
        except Exception:
            pass


# ===========================================================================
# プロセス生存確認
# ===========================================================================

def is_process_alive(pid):
    if pid <= 0:
        return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # 存在はする(他ユーザ所有でもプロセスは生きている)
        return True
    except Exception:
        return True


# ===========================================================================
# モニタ座標(NSScreen.visibleFrame をWin形式に変換)
# ===========================================================================

def get_active_monitor_work_rect():
    """フォアグラウンドのウィンドウがあるモニターの作業領域を返す。

    macOS の NSScreen は左下原点なので、Y を反転して左上原点に直す。
    overlay.py が Windows 座標系(左上原点)前提でコードされているため。
    """
    try:
        from AppKit import NSScreen  # pyobjc-framework-Cocoa
    except Exception:
        return None
    try:
        screens = NSScreen.screens()
        main = NSScreen.mainScreen()
        if main is None or screens is None or len(screens) == 0:
            return None
        # メインスクリーンの高さで Y 軸を反転する
        # (NSScreen 全体は、各 screen.frame() の原点が下から測られる)
        main_frame = main.frame()
        main_h = float(main_frame.size.height)
        vf = main.visibleFrame()
        left = int(round(vf.origin.x))
        bottom_macos = float(vf.origin.y) + float(vf.size.height)
        top = int(round(main_h - bottom_macos))
        right = int(round(vf.origin.x + vf.size.width))
        bottom = int(round(top + vf.size.height))
        return (left, top, right, bottom)
    except Exception:
        return None


# ===========================================================================
# 起動直後ウォームアップ
# ===========================================================================

def warmup():
    """pyperclip と pynput の初回コストを起動時に潰す。"""
    try:
        import pyperclip
        original = pyperclip.paste()
        pyperclip.copy(original or "")
    except Exception:
        pass
    try:
        # pynput のキーボード module 初期化コストを払っておく
        from pynput import keyboard as _kb  # noqa: F401
    except Exception:
        pass


__all__ = [
    "set_project_root",
    "is_modifier_held",
    "register_hotkey_listener",
    "unregister_hotkey_listener",
    "install_global_key_hook",
    "add_emergency_reset_hotkey",
    "unhook_all_global",
    "wait_forever",
    "paste_at_cursor",
    "type_text_directly",
    "SingleInstance",
    "is_autostart_enabled",
    "toggle_autostart",
    "get_autostart_description",
    "find_no_console_python",
    "spawn_detached",
    "open_path",
    "open_system_taskbar_settings",
    "is_process_alive",
    "get_active_monitor_work_rect",
    "warmup",
]
