# -*- coding: utf-8 -*-
"""platform_compat - OS差を吸収する薄い抽象層

役割:
  Windows / macOS で挙動が違う部分(ホットキー・貼り付け・自動起動・
  単一インスタンス・モニタ座標取得・パス open など)を1ヶ所に集約し、
  呼び出し側コードはここに対してだけ依存させる。

使い方:
  from platform_compat import paste_at_cursor, SingleInstance
  paste_at_cursor()

設計方針:
  - sys.platform を見て windows.py / macos.py を自動振り分け。
  - 抽象基底クラスは使わず、関数モジュールを差し替える素朴な実装。
    (Python の Duck Typing で十分、起動時の import 数も最小)
  - 未対応 OS では起動時に分かりやすい日本語例外を出す。

旦那様が Windows ユーザーの間は windows.py が読まれる。
Mac ユーザーには macos.py が読まれる。両者は同じ関数名・同じ戻り値の
形を約束しているので、呼び出し側は OS を意識しない。
"""

import sys

_PLATFORM = sys.platform


if _PLATFORM == "win32":
    from .windows import *  # noqa: F401,F403
    from . import windows as _impl
    IS_WINDOWS = True
    IS_MACOS = False
elif _PLATFORM == "darwin":
    from .macos import *  # noqa: F401,F403
    from . import macos as _impl
    IS_WINDOWS = False
    IS_MACOS = True
else:
    raise RuntimeError(
        f"この OS({_PLATFORM})は現在サポート対象外です。"
        " Windows または macOS で実行してください。"
    )


# 呼び出し側で「今どっち?」を判定したい時に使うフラグ。
__all__ = ["IS_WINDOWS", "IS_MACOS"] + getattr(_impl, "__all__", [])
