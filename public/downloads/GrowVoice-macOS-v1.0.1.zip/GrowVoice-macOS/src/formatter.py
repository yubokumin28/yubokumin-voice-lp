# -*- coding: utf-8 -*-
"""
formatter.py - 音声入力ツール 整形エンジン (第1段)

STT(音声認識)が出したテキストを、ルールベースで以下の順に整形する:
  (1) remove_repeats      繰り返し除去
  (2) remove_fillers      フィラー除去
  (3) apply_replacements  誤変換の置換

音声・GPU に一切依存しない純粋な文字列処理。
テストCLI・性能比較ベンチ・常駐本体のすべてがこのモジュールを呼ぶ。
"""

import json
import re
from pathlib import Path


# ---------------------------------------------------------------------------
# 設定の読み込み
# ---------------------------------------------------------------------------

def load_config(config_dir):
    """config フォルダから settings / fillers / replacements / symbols を読む。

    戻り値: dict {"settings":..., "fillers":..., "replacements":..., "symbols":...}
    ファイル欠落・JSON破損時は ValueError(日本語メッセージ付き)を投げる。
    symbols.json だけは任意で、無ければ空(記号変換なし)として扱う。
    """
    config_dir = Path(config_dir)
    result = {}
    for name in ("settings", "fillers", "replacements"):
        path = config_dir / f"{name}.json"
        try:
            with open(path, encoding="utf-8") as f:
                result[name] = json.load(f)
        except FileNotFoundError:
            raise ValueError(f"設定ファイルが見つかりません: {path}")
        except json.JSONDecodeError as e:
            raise ValueError(
                f"設定ファイルの書式が壊れています: {path}\n  {e}"
            )

    # symbols.json は任意。古い環境に無くても動くよう、欠落時は空辞書にする
    sym_path = config_dir / "symbols.json"
    if sym_path.exists():
        try:
            with open(sym_path, encoding="utf-8") as f:
                result["symbols"] = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"設定ファイルの書式が壊れています: {sym_path}\n  {e}"
            )
    else:
        result["symbols"] = {}

    # 建設用語の提案リスト(任意)。enabled=true の項目だけを置換辞書に合流させる。
    # 構造は replacements.json と同じ {wrong, right} に enabled / note が増えただけ。
    ct_path = config_dir / "construction_terms.json"
    if ct_path.exists():
        try:
            with open(ct_path, encoding="utf-8") as f:
                ct_data = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"設定ファイルの書式が壊れています: {ct_path}\n  {e}"
            )
        if isinstance(ct_data, list):
            for item in ct_data:
                if not isinstance(item, dict):
                    continue
                if not item.get("enabled"):
                    continue
                wrong = item.get("wrong")
                right = item.get("right", "")
                if not wrong:
                    continue
                result["replacements"].append({"wrong": wrong, "right": right})
    return result


# ---------------------------------------------------------------------------
# (1) 繰り返し除去
# ---------------------------------------------------------------------------

# 「3〜20文字のかたまりが2回以上連続」を検出する。
# 2文字以下の反復(「どんどん」「いろいろ」等の正当な畳語)は対象外にして誤爆を防ぐ。
_REPEAT_RE = re.compile(r"(.{3,20}?)\1+")

# これらを含む反復は「間を空けた意図的な繰り返し」とみなし、圧縮しない。
# 例:「テスト。テスト。」「はい、はい、」は残す。「こんにちはこんにちは」は畳む。
_REPEAT_STOP_CHARS = "、。！？!?…\n\r 　"


def remove_repeats(text, whitelist=None):
    """連続する語の重複を1つに圧縮する(「こんにちはこんにちは」→「こんにちは」)。

    whitelist        : 正当な反復語(「だんだん」等)。これらは畳まない。
    句読点・空白を含む反復は意図的な繰り返しとみなし、そのまま残す。
    """
    whitelist = set(whitelist or [])

    def _collapse(m):
        whole = m.group(0)
        unit = m.group(1)
        # 句読点や空白を挟む反復は意図的とみなして残す(安全側)
        if any(c in unit for c in _REPEAT_STOP_CHARS):
            return whole
        # ホワイトリスト語も畳まない
        if whole in whitelist or (unit + unit) in whitelist:
            return whole
        return unit

    return _REPEAT_RE.sub(_collapse, text)


# ---------------------------------------------------------------------------
# (2) フィラー除去
# ---------------------------------------------------------------------------

def remove_fillers(text, fillers):
    """フィラー(「えー」「あー」等)を削除する。

    fillers["always"]      : どこにあっても削除
    fillers["conditional"] : 読点/句点/空白/文末の直前にある時だけ削除
                             (「あの本」のような正当用法を壊さないため)
    """
    always = fillers.get("always", [])
    conditional = fillers.get("conditional", [])

    # always: 長い語から削除(「えーっと」を先に消し「っと」残りを防ぐ)
    for w in sorted(always, key=len, reverse=True):
        if w:
            text = text.replace(w, "")

    # conditional: 直後が 、。空白 または 文末 の時だけ削除
    for w in sorted(conditional, key=len, reverse=True):
        if not w:
            continue
        esc = re.escape(w)
        text = re.sub(esc + r"(?=[、。\s])", "", text)
        text = re.sub(esc + r"$", "", text)

    return _cleanup_punct(text)


def _cleanup_punct(text):
    """フィラー削除後に残る不要な句読点・空白を整える。"""
    text = re.sub(r"、{2,}", "、", text)
    text = re.sub(r"。{2,}", "。", text)
    text = re.sub(r"、(?=。)", "", text)      # 「、。」-> 「。」
    text = re.sub(r"^[、。\s]+", "", text)     # 先頭の句読点/空白
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


# ---------------------------------------------------------------------------
# (3) 誤変換の置換辞書
# ---------------------------------------------------------------------------

def apply_replacements(text, replacements, normalize_width=True):
    """置換辞書を適用する。wrong が長いものから順に置換する。

    1) 完全一致(従来ロジック): text.replace() で wrong → right に。
    2) あいまい一致(fuzzy:true のエントリのみ): rapidfuzz で類似度判定し、
       閾値を超えたトークンを right に置換。Whisper の音声ゆらぎ吸収用。
    """
    # enabled が明示的に False の項目は適用しない(学習タブで「チェックを
    # 外した」言い換えを無効化するため)。キーが無い従来項目は True 扱い。
    rules = sorted(
        [r for r in replacements
         if isinstance(r, dict) and r.get("wrong") and r.get("enabled", True)],
        key=lambda r: len(r["wrong"]),
        reverse=True,
    )
    for r in rules:
        wrong = r["wrong"]
        right = r.get("right", "")
        text = text.replace(wrong, right)
        if normalize_width:
            alt = _swap_width(wrong)
            if alt != wrong:
                text = text.replace(alt, right)
    # 2) あいまい一致(fuzzy:true 限定。rapidfuzz が無ければスキップ)
    fuzzy_rules = [r for r in rules if r.get("fuzzy") and r.get("enabled", True)]
    if fuzzy_rules:
        text = _apply_fuzzy_replacements(text, fuzzy_rules)
    return text


def _is_kana(c):
    """ひらがな・カタカナ・長音(ー)判定。日本語は分かち書きしないため、
    fuzzy 対象トークンは「カナ連続塊」として検出する。"""
    if c in ("ー", "ー"):
        return True
    o = ord(c)
    return (0x3041 <= o <= 0x3096) or (0x30A1 <= o <= 0x30FA)


def _apply_fuzzy_replacements(text, fuzzy_rules):
    """fuzzy:true エントリに対して rapidfuzz で類似度判定して置換。

    日本語は分かち書きしないので、wrong と同じ ± 1 字長のスライディング
    ウィンドウで text を走査する。ひらがな・カタカナのみの連続でないと
    対象にしない(漢字や記号で誤爆しない)。
    """
    try:
        from rapidfuzz import fuzz
    except ImportError:
        return text

    if not fuzzy_rules:
        return text

    out = []
    i = 0
    n = len(text)
    while i < n:
        matched_len = 0
        replacement = None
        for r in fuzzy_rules:
            wrong = r["wrong"]
            right = r.get("right", "")
            threshold = r.get("fuzzy_threshold", 85)
            wl = len(wrong)
            if wl < 3:
                continue
            # wrong の長さの ±1 字を試す。長いウィンドウから先に
            # (短いウィンドウが先に低スコアでヒットして部分置換が起きるのを防ぐ)
            for w_len in (wl + 1, wl, wl - 1):
                if w_len < 3 or i + w_len > n:
                    continue
                token = text[i:i + w_len]
                # 既に正解側 / 完全一致 はスキップ(完全一致は前段で処理済み)
                if token == wrong or token == right:
                    continue
                # ひらがな・カタカナのみで構成された塊か(漢字・記号で誤爆しない)
                if not all(_is_kana(c) for c in token):
                    continue
                score = fuzz.ratio(token, wrong)
                if score >= threshold:
                    replacement = right
                    matched_len = w_len
                    break
            if matched_len:
                break
        if matched_len:
            out.append(replacement)
            i += matched_len
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def _swap_width(s):
    """半角ASCII <-> 全角ASCII を入れ替える(数字・英字の表記揺れ吸収用)。"""
    out = []
    for ch in s:
        o = ord(ch)
        if 0x21 <= o <= 0x7E:          # 半角 -> 全角
            out.append(chr(o + 0xFEE0))
        elif 0xFF01 <= o <= 0xFF5E:    # 全角 -> 半角
            out.append(chr(o - 0xFEE0))
        else:
            out.append(ch)
    return "".join(out)


# ---------------------------------------------------------------------------
# 記号変換: 音声で言った記号名(「ドット」等)を実際の記号にする
# ---------------------------------------------------------------------------

def apply_symbols(text, symbols):
    """記号名を記号に置換する(「ドット」->「.」など)。

    symbols は config/symbols.json の中身(読み -> 記号 の辞書)。
    キーが「_」で始まる項目(_comment 等の注釈)は対象外。
    長い読みから先に置換し、短い読みが先に食わないようにする。
    """
    if not symbols:
        return text
    words = sorted(
        (w for w in symbols if w and not w.startswith("_")),
        key=len,
        reverse=True,
    )
    for w in words:
        text = text.replace(w, symbols[w])
    return text


# ---------------------------------------------------------------------------
# 仕上げ: STT由来の不要な空白を整える (Round3)
# ---------------------------------------------------------------------------

# 日本語の文字(ひらがな・カタカナ・漢字・主な記号)
_JP_CHARS = "ぁ-んァ-ヶーｰ一-龯々〆〤、。！？「」『』（）・"
_INTER_JP_SPACE_RE = re.compile(rf"(?<=[{_JP_CHARS}])[ 　]+(?=[{_JP_CHARS}])")


def polish_text(text, remove_inter_japanese_spaces=True):
    """整形の最終仕上げ。STT が日本語の語間に入れがちな空白を除去する。

    英単語の前後の空白(例「New York」)は残す。
    """
    if remove_inter_japanese_spaces:
        text = _INTER_JP_SPACE_RE.sub("", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


# ---------------------------------------------------------------------------
# 仕上げ2: 疑問文に「?」を付ける
# ---------------------------------------------------------------------------

# 文末がこれらで終わる文は疑問とみなす。「とか」(列挙)は除外する。
_QUESTION_END_RE = re.compile(r"(?:(?<!と)か|かな|かね|かしら|っけ)$")


def add_question_marks(text, mark="?"):
    """文末が疑問の助詞(か・かな等)で終わる文の句点を「?」に変える。

    例:「元気ですか。」->「元気ですか?」 /「どうかな。」->「どうかな?」
    「りんごとか。」のような列挙の「とか」は対象外。
    """
    out = []
    buf = ""
    for ch in text:
        buf += ch
        if ch == "。":
            body = buf[:-1]
            if _QUESTION_END_RE.search(body):
                out.append(body + mark)
            else:
                out.append(buf)
            buf = ""
    if buf:  # 句点で終わらない末尾の断片
        if _QUESTION_END_RE.search(buf):
            out.append(buf + mark)
        else:
            out.append(buf)
    return "".join(out)


# ---------------------------------------------------------------------------
# 仕上げ3: 文中の疑問形語尾に「?」を補う
# ---------------------------------------------------------------------------
# Whisper が句点を出さなくても、疑問形の語尾を見つけたら直後に「?」を入れる。
# 「ですから」「ますから」(接続詞)は意図的に除外。
# 順序は『長いパターンを先』『短いパターンを後』に並べる。
# 正規表現の "|" は左から評価されるため、長い順に書かないと短い方が先取る。
_QUESTION_INLINE_RE = re.compile(
    r"("
    # 依頼・確認(長いもの)
    r"いただけませんでしょうか|いただけませんか|いただけますでしょうか|いただけますか|"
    r"していませんか|していますか|してませんか|してますか|"
    r"ますでしょうか|ませんでしょうか|"
    r"よろしいでしょうか|よろしいですか|"
    r"なんでしょうか|なのでしょうか|のでしょうか|でしょうか|"
    r"もらえませんか|もらえますか|"
    # 反語・確認
    r"じゃないでしょうか|じゃないですか|じゃありませんか|"
    r"ないでしょうか|ないですか|"
    # 存在・状態
    r"ありませんでしたか|ありませんか|ありますか|ありましたか|"
    r"いませんでしたか|いませんか|いますか|いましたか|"
    # 「のですか」系
    r"なんですか|なのですか|のですか|"
    # 主要パターン(短いものは末尾)
    r"ませんでしたか|ましたか|でしたか|ましょうか|ませんか|"
    r"ですか(?!ら)|ますか(?!ら)|"
    # 常体
    r"なんだろうか|だろうか|"
    # 末尾助詞
    r"かしら|かな|っけ"
    r")"
    r"(?![。、!?!?])"
)


def auto_question_marks(text, mark="?"):
    """文中の疑問形語尾の直後に「?」を挿入する。

    既に「。」「、」「?」「!」が続いていれば付与しない(重複防止)。
    「ですから」「ますから」など接続詞は除外。
    """
    if not text:
        return text
    return _QUESTION_INLINE_RE.sub(lambda m: m.group(1) + mark, text)


# ---------------------------------------------------------------------------
# 仕上げ4: 文中の終止形語尾に「。」を補う (常体・敬体 両対応)
# ---------------------------------------------------------------------------
# 旦那様の指示:「です/ます/ました/でした/ません」(敬体) と
# 「だ/だった/だと思う/思った/そうだ/考えた/考えている」等(常体) の
# どちらでも文末で「。」が付くようにする。
#
# 設計方針(誤爆回避のため2段階で処理):
#  (A) 思考動詞「と+動詞」と常体助動詞・そうだ系は **文字列の末尾のみ** マッチ
#      (中間に出ると「と思ったから」「だったので」のような接続表現で誤爆するため)
#  (B) 敬体「です/ます」系は文中もマッチ(連続文に対応するため)
#      ただし「ですか/ますか/ですね/ですから/ですが」等は除外条件で回避

# (A) 末尾アンカー(文字列の末尾) のみマッチするパターン
# 旦那様の例:「だと思う」「思った」「そうだ」「考えた」「考えている」「だった」「である」
_PERIOD_END_ANCHOR_RE = re.compile(
    r"("
    # 思考動詞「と+動詞」(長い順)
    r"と思っていませんでした|と思っていません|"
    r"と思っていました|と思っています|"
    r"と思いませんでした|と思いません|"
    r"と思いました|と思います|"
    r"と思っていた|と思っている|"
    r"と思った|と思う|"
    r"と考えていませんでした|と考えていません|"
    r"と考えていました|と考えています|"
    r"と考えませんでした|と考えません|"
    r"と考えました|と考えます|"
    r"と考えていた|と考えている|"
    r"と考えた|と考える|"
    r"と感じました|と感じます|と感じた|と感じる|"
    r"と思われました|と思われます|と思われた|と思われる|"
    r"と言えました|と言えます|と言えた|と言える|"
    # 思考動詞 - 単体(末尾限定で誤爆なし)
    r"思っていませんでした|思っていません|"
    r"思っていました|思っています|"
    r"思いませんでした|思いません|"
    r"思いました|思います|"
    r"思っていた|思っている|"
    r"思った|思う|"
    r"考えていませんでした|考えていません|"
    r"考えていました|考えています|"
    r"考えませんでした|考えません|"
    r"考えました|考えます|"
    r"考えていた|考えている|"
    r"考えた|考える|"
    r"感じました|感じます|感じた|感じる|"
    # そうだ系
    r"そうでした|そうだった|そうです|そうだ|"
    # 常体助動詞・繋辞
    r"ではありませんでした|ではありません|"
    r"ではなかった|ではない|"
    r"であった|である|"
    r"だった|だろう"
    r")$"
)

# (B) 文中マッチ可能なパターン(敬体・連続文用)
_PERIOD_INLINE_RE = re.compile(
    r"("
    # 動詞・補助動詞 (長い順)
    r"いたしませんでした|いたしました|いたしません|いたします|"
    r"お願いいたします|お願いいたしました|"
    r"お願いします|お願いしました|"
    r"いただきませんでした|いただきました|いただきません|いただきます|"
    r"いただけませんでした|いただけました|いただけません|いただけます|"
    r"失礼いたしました|失礼いたします|失礼しました|失礼します|"
    r"ておりませんでした|ておりません|ておりました|ております|"
    r"ていませんでした|ていません|ていました|ています|"
    r"してませんでした|してません|してました|してます|"
    r"ありませんでした|ありました|ありません|あります(?![かねよ])|"
    r"いませんでした|いました|いません|います(?![かねよ])|"
    r"なりませんでした|なりました|なりません|なります(?![かねよ])|"
    # 基本パターン(除外条件付き)
    r"ませんでした|ました(?![から])|でした(?![から])|ません(?![でか])|"
    r"ください(?![ね])|"
    r"でしょう(?![かねよ])|"
    r"です(?![かねよなわぞぜらけが])|"
    r"ます(?![かねよなわぞぜらが])"
    r")"
    r"(?![。、!?!?])"
)


def auto_periods(text):
    """文中の終止形語尾の直後に「。」を挿入する。常体・敬体の両方に対応。

    2段階処理:
      (A) 末尾の思考動詞・常体助動詞に「。」を付与(文字列末のみ)
      (B) 文中の敬体「です/ます」系に「。」を付与(連続文対応)

    「ですか/ますか」(疑問)/「ですね/ますね/ですよ」(余韻)/
    「ですから/ですが/ですけれど」(接続詞) は除外。
    「思う/考える/感じる」等は『と+動詞』形に限定し、かつ末尾のみ対象。
    「だ」単体は対象外(「だから/だけど」等と紛れるため)。
    """
    if not text:
        return text
    # (A) 末尾アンカー:文字列末の終止形に「。」を付ける
    text = _PERIOD_END_ANCHOR_RE.sub(lambda m: m.group(1) + "。", text)
    # (B) 文中:敬体終止形に「。」を付ける
    text = _PERIOD_INLINE_RE.sub(lambda m: m.group(1) + "。", text)
    return text


# ---------------------------------------------------------------------------
# 仕上げ4.5: 5W1H 疑問詞で始まる文の末尾を「?」化
# ---------------------------------------------------------------------------
# 旦那様の指示:「いつ〜でした」「どこで〜ですか」「誰が〜です」のように
# 5W1H で始まる文は必ず疑問。末尾を「?」にする(「。」なら「?」に置換)。
#
# 疑問詞リスト(漢字・ひらがな・派生形を網羅)
_INTERROGATIVES = [
    # 基本(漢字)
    "いつ", "どこ", "誰", "何", "なぜ", "どう",
    # 「どう」派生
    "どうして", "どうやって", "どのように", "どういう",
    "どんな", "どれ", "どっち", "どちら",
    # 数・量の疑問
    "いくつ", "いくら", "どのくらい", "どれくらい", "どのぐらい",
    # 「なん」派生(限定:代名詞「なんとなく」と区別)
    "なんで", "なんの", "なんと", "なんという",
    # 「何」派生(漢字)
    "何で", "何が", "何を", "何に", "何と", "何の",
    "何時", "何日", "何月", "何年", "何曜日",
    "何人", "何個", "何回", "何度", "何処",
    # 「いつ」派生
    "いつから", "いつまで", "いつの", "いつ頃",
    # 「どこ」派生
    "どこから", "どこまで", "どこに", "どこで", "どこの", "どこへ",
    # 「誰」派生(漢字)
    "誰が", "誰に", "誰を", "誰の", "誰と", "誰から", "誰へ",
]

# 疑問詞「風」だが疑問でない代名詞・副詞(除外リスト)
_NON_INTERROGATIVE_PREFIXES = [
    # 「か/も」付きの代名詞
    "どこか", "どこも", "いつか", "いつも",
    "だれか", "だれも", "誰か", "誰も",
    "なにか", "なにも", "何か", "何も", "なんか",
    "どれか", "どれも",
    "どちらか", "どちらも", "どっちか", "どっちも",
    # 「なん」系の副詞
    "なんとか", "なんとなく", "なんでも",
    "何でも", "何となく", "何かしら",
    # 「どう」系の副詞
    "どうも", "どうやら", "どうにか", "どうしても",
]

# 長い順にソートして先頭マッチが正しく動くようにする
_INTERROGATIVES_SORTED = sorted(_INTERROGATIVES, key=len, reverse=True)
_NON_INTERROGATIVE_SORTED = sorted(_NON_INTERROGATIVE_PREFIXES, key=len,
                                   reverse=True)


def _starts_with_interrogative(text):
    """テキストの先頭が 5W1H 疑問詞かどうかを判定する。

    代名詞・副詞(「どこか」「なんとなく」等)は False を返す。
    ただし「いつから」「どこから」のように疑問詞が代名詞より長くマッチ
    する場合は疑問詞優先(疑問詞マッチ長 ≥ 除外マッチ長 なら疑問詞)。
    """
    stripped = text.lstrip()
    if not stripped:
        return False
    # 疑問詞を長い順に試す
    for w in _INTERROGATIVES_SORTED:
        if stripped.startswith(w):
            # 同じ位置に「より長い」除外パターンが当たれば除外
            # 例:「いつかわかる」→「いつ」マッチだが除外「いつか」が長い → 除外
            # 例:「いつから始める」→「いつから」マッチで除外「いつか」より長い → 疑問詞
            for nw in _NON_INTERROGATIVE_SORTED:
                if len(nw) > len(w) and stripped.startswith(nw):
                    return False
            return True
    return False


def add_5w1h_question_marks(text, mark="?"):
    """5W1H 疑問詞で始まる文の末尾を「?」にする。

    例:
      「いつ会議でした」     → 「いつ会議でした?」
      「どこで開催ですか?」  → 既に「?」あり → 触らない
      「誰が来た」           → 「誰が来た?」
      「何でも来てください」 → 「何でも」は代名詞 → 触らない

    既存の auto_question_marks / auto_periods / add_question_marks の後に
    呼ぶこと。先に終止形が「。」化されているので、その「。」を「?」に置換。
    """
    if not text:
        return text
    # 句点・感嘆符・疑問符を区切りとして文単位に分割(区切りは保持)
    parts = re.split(r"(?<=[。!?!?])", text)
    out = []
    for part in parts:
        if _starts_with_interrogative(part):
            if part.endswith("。"):
                part = part[:-1] + mark
            elif part and part[-1] not in "?!!?":
                # 末尾が句読点でない(=最終文で句点が無いケース)
                part = part + mark
            # 既に「?」「!」があればそのまま
        out.append(part)
    return "".join(out)


# ---------------------------------------------------------------------------
# 仕上げ5: 文頭の接続詞の後に「、」を補う
# ---------------------------------------------------------------------------
# 旦那様の指示:「だから/しかし/また/だけど」のような接続詞の後に「、」を入れる。
# 文頭(文字列の先頭、または直前が「。!?」)の接続詞だけを対象にして、文中の
# 別文脈(例:「私はだから帰った」)は触らない。
_CONJUNCTIONS = [
    # 順接
    "だから", "ですから", "そのため", "なので", "それで", "そこで",
    "したがって", "よって", "すると", "すなわち", "つまり", "ゆえに",
    "それゆえ",
    # 逆接
    "しかしながら", "しかし", "けれども", "けれど", "ですけれども",
    "ですけれど", "ですが", "だけれども", "だけれど", "だけど", "だが",
    "でも", "ところが", "それでも", "それなのに", "なのに",
    "にもかかわらず", "とはいえ", "ただし",
    # 並列・添加
    "そして", "それから", "それに", "しかも", "そのうえ", "その上",
    "さらに", "加えて", "おまけに", "なお", "ちなみに", "また",
    "および", "ならびに", "かつ",
    # 対比・選択
    "一方", "他方", "または", "もしくは", "あるいは", "それとも",
    # 説明・例示
    "なぜなら", "というのは", "というのも", "たとえば", "例えば",
    "要するに", "要は",
    # 転換
    "ところで", "さて", "それでは", "そういえば",
    # 時間・順序
    "まず", "はじめに", "次に", "続いて", "その後", "最後に",
    "終わりに",
]
# 長い順にソート(「ですから」が「だから」より先に取れるように)
_CONJUNCTIONS_SORTED = sorted(_CONJUNCTIONS, key=len, reverse=True)

# 文頭判定: 文字列先頭 or 直前が「。!?\n」のいずれか
# 接続詞の直後に句読点が無ければ「、」を挿入
_CONJUNCTION_RE = re.compile(
    r"(?:(?<=^)|(?<=[。!?!?\n]))\s*("
    + "|".join(re.escape(c) for c in _CONJUNCTIONS_SORTED)
    + r")(?![、。!?!?])"
)


def add_conjunction_comma(text):
    """文頭の接続詞の直後に「、」を補う(「だから明日は」→「だから、明日は」)。

    対象は文字列の先頭 または「。!?」の直後にある接続詞のみ。
    文中の同じ語(別文脈)は触らない。既に句読点が続いていれば何もしない。
    """
    if not text:
        return text
    return _CONJUNCTION_RE.sub(lambda m: m.group(1) + "、", text)


# ---------------------------------------------------------------------------
# 引用自動検出: 「...。〇〇。と。」の〇〇を「」で囲む
# ---------------------------------------------------------------------------

# 引用末尾マーカー: 「と」+ 句読点・引用動詞・助詞の語頭。
# 例:「と。」「と、」「と思った」「と言った」「と言いました」「とのこと」「と答えた」。
# 注意:「お」始まり(とおく/とおもしろい等)は誤爆しやすいので含めない。
_CITATION_MARKER_RE = re.compile(
    r"^と(?:[。、!?！?]|思|言|聞|述|申|答|叫|呟|い[いっ]|のこと)"
)


def add_quotes_for_citations(text):
    """『...。〇〇。と。』のような構造の〇〇を自動で「」で囲む。

    例:「私はひらめいた。こうすべきだ。と。」
        → 「私はひらめいた。「こうすべきだ。」と。」

    判定: 文頭が「と+句読点/引用動詞/助詞」で始まる文(=引用末尾マーカー)の
          直前の文を引用とみなす。既に「」で始まっている直前文は触らない。
    安全側に倒し、1文ぶんだけを「」で囲む(複数文の引用には対応しない)。
    """
    if not text:
        return text
    parts = re.split(r"(?<=[。!?！?])", text)
    out = []
    for s in parts:
        head = s.lstrip()
        if (out and head and _CITATION_MARKER_RE.match(head)
                and out[-1] and not out[-1].lstrip().startswith("「")):
            prev = out[-1]
            m = re.match(r"^(\s*)(.*?)(\s*)$", prev, re.DOTALL)
            lead, body, tail = m.group(1), m.group(2), m.group(3)
            if body:
                out[-1] = f"{lead}「{body}」{tail}"
        out.append(s)
    return "".join(out)


# ---------------------------------------------------------------------------
# 自己修復: Whisper のハルシネーション(無音・雑音時の暴走)検知
# ---------------------------------------------------------------------------
# 長時間の無音や雑音だけを Whisper に渡すと、 多言語混在の意味不明な
# テキストや同一フレーズの繰り返しを出力する。 これを検出して破棄する。

# キリル文字・ハングル(日本語の音声入力ではまず出ない)
_CYRILLIC_RE = re.compile(r"[Ѐ-ӿ]")
_HANGUL_RE = re.compile(r"[가-힯]")
# 同一の短いフレーズが6回以上連続(「ハーハーハーハーハーハー」のような暴走)。
# 旧 \1{3,}(=4回)では「どんどんどんどん」(=「どん」×4)のような正当な
# 擬態語・強調まで誤爆していたため、\1{5,}(=6回)に緩めた。さらに
# repeat_whitelist で説明できる繰り返しは除外する(detect_hallucination 内)。
_REPEAT_HALLUCINATION_RE = re.compile(r"(.{1,8}?)\1{5,}")
# 「日本語の文字」と判定する範囲(ひらがな・カタカナ・漢字・基本記号)
_JP_CHAR_RE = re.compile(
    r"[぀-ヿ一-鿿　-〿A-Za-z0-9\s"
    r"!?!?,.、。「」『』()()\-_/+:;ー…]"
)


def detect_hallucination(text, repeat_whitelist=None):
    """Whisper のハルシネーション(無音時の暴走出力)を検出する。

    戻り値: (検出されたか, 理由, 破棄すべき重度か)

    破棄すべき重度(severe=True):
      1. キリル文字を含む
      2. ハングルを含む
      3. 非日本語文字(範囲外)の比率が 15% を超える
      4. 漢字の異常な羅列
      → 作業文書を壊す異物なので貼り付けを止める。

    軽度(severe=False):
      5. 同一フレーズの過剰繰り返し
      → 長文の一部であることが多く、破棄すると喋った内容が丸ごと消える。
        破棄せず、後段の remove_repeats による圧縮に委ねて挿入する。
        「どんどんどんどん」等の正当な繰り返しは repeat_whitelist で除外。
    """
    if not text or len(text) < 8:
        return (False, "", False)
    # --- 重度(破棄)---
    if _CYRILLIC_RE.search(text):
        return (True, "キリル文字を含む(Whisper のハルシネーション)", True)
    if _HANGUL_RE.search(text):
        return (True, "ハングルを含む(Whisper のハルシネーション)", True)
    non_japanese = [ch for ch in text if not _JP_CHAR_RE.match(ch)]
    if len(non_japanese) / max(len(text), 1) > 0.15:
        return (True, f"非日本語文字の比率が高い({len(non_japanese)}/{len(text)})",
                True)
    # 漢字の異常な羅列(旦那様の実例:
    # 「砲化合頤墨打減合理参戮梁壇堤掛巨頤垂頤床堤頤墜...」のような幻覚)
    try:
        from anomaly import is_garbled, garble_reason
        if is_garbled(text):
            return (True, f"漢字の異常な羅列({garble_reason(text)})", True)
    except Exception:
        pass
    # --- 軽度(破棄しない)同一フレーズの過剰繰り返し ---
    m = _REPEAT_HALLUCINATION_RE.search(text)
    if m:
        unit = m.group(1)
        wl = set(repeat_whitelist or [])
        # 「どん」×4 のように、繰り返しの単位が whitelist 語で説明できるなら
        # 正当な擬態語・強調とみなして検出しない。
        explained = (
            unit in wl
            or (unit + unit) in wl
            or any(unit and unit in w for w in wl)
        )
        if not explained:
            return (True, "同一フレーズの過剰繰り返し", False)
    return (False, "", False)


# ---------------------------------------------------------------------------
# 疑問符・句点の重複ダブり正規化(パイプライン最終段)
# ---------------------------------------------------------------------------

# 「?か?」「?か?」「?か。」のような末尾再付与パターン(中間「か」のみ対応)
_QKQ_RE = re.compile(r"[??]か[??。.]+")
# 句点と疑問符の混在(順不同)
_Q_PERIOD_RE = re.compile(r"[??][。.]+|[。.]+[??]")
# 連続疑問符
_DUPE_QUESTION_RE = re.compile(r"[??]{2,}")
# 連続句点
_DUPE_PERIOD_RE = re.compile(r"[。.]{2,}")


def normalize_punctuation(text, prefer_mark="?"):
    """疑問符・句点の重複ダブりを後始末する。AI不要・純正規表現で瞬時。

    対応パターン(旦那様の実報告ベース):
      - 「こうでしょうか?か?」 → 「こうでしょうか?」
      - 「ですか??」 → 「ですか?」
      - 「ですか?。」「ですか。?」 → 「ですか?」
      - 連続句点「。。」 → 「。」

    prefer_mark: 出力する疑問符。"?" (半角) または "?" (全角)。
    """
    if not text:
        return text
    # 1) 「?か?」「?か。」のような末尾再付与パターンを単一の疑問符に
    text = _QKQ_RE.sub(prefer_mark, text)
    # 2) 句点と疑問符の混在は疑問符優先
    text = _Q_PERIOD_RE.sub(prefer_mark, text)
    # 3) 連続疑問符を1個に
    text = _DUPE_QUESTION_RE.sub(prefer_mark, text)
    # 4) 連続句点を1個に
    text = _DUPE_PERIOD_RE.sub("。", text)
    return text


# ---------------------------------------------------------------------------
# まとめ: (1) -> (2) -> (3) -> 仕上げ の順で整形
# ---------------------------------------------------------------------------

def format_text(text, config):
    """STT出力テキストを (1)->(2)->(3) の順に整形して返す。"""
    if not text:
        return ""
    settings = config.get("settings", {})
    fillers = config.get("fillers", {})
    replacements = config.get("replacements", [])

    text = remove_repeats(
        text,
        whitelist=settings.get("repeat_whitelist", []),
    )
    text = remove_fillers(text, fillers)
    text = apply_replacements(
        text,
        replacements,
        normalize_width=settings.get("normalize_width", True),
    )
    text = apply_symbols(text, config.get("symbols", {}))
    text = polish_text(
        text,
        remove_inter_japanese_spaces=settings.get(
            "remove_inter_japanese_spaces", True
        ),
    )
    if settings.get("add_question_marks", True):
        mark = settings.get("question_mark", "?")
        # 順序が重要:
        #   1) 接続詞「、」を先に → 文の区切りができて以降の判定が安定
        #   2) 疑問形「?」を次に → 「ですか?」を確定させ「です」誤爆を防ぐ
        #   3) 終止形「。」を次に
        #   4) 末尾の「か。」→「か?」(既存ロジック)
        #   5) 5W1H 疑問詞で始まる文は末尾「?」に置換(最後)
        #   6) 重複ダブり正規化(「?か?」「??」を1個に)
        text = add_conjunction_comma(text)
        text = auto_question_marks(text, mark=mark)
        text = auto_periods(text)
        text = add_question_marks(text, mark=mark)
        text = add_5w1h_question_marks(text, mark=mark)
        text = normalize_punctuation(text, prefer_mark=mark)
    return text.strip()
