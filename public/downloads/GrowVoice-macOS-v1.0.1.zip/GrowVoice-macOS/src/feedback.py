# -*- coding: utf-8 -*-
"""feedback.py - 録音状態を知らせる通知音(自前の「ピッ」音)

【経緯】
1) winsound.Beep … 古い方式。最近のPC(ビープ用スピーカー無し)では無音。実機×。
2) システム音(PlaySound + SND_ALIAS) … 鳴るが「ポーン」と長め・大きめで好みでない。
3) 今回 … 短く小さい「ピッ」を自前で生成し、通常スピーカーから鳴らす。← これ

サイン波を一瞬だけ作って WAV としてメモリ上に持ち、winsound.PlaySound の
SND_MEMORY で鳴らす。周波数・長さ・音量を自由に決められるので「短く・小さく」
できる。追加インストール不要(Python 標準の wave / struct のみ)。

【衝突対策】
音は1本のワーカースレッド + 行列(キュー)で順番に鳴らすので、要求が重なっても
取りこぼさない。鳴らすのは専用スレッドなので録音・認識を遅らせない。

【設計方針(完了音だけ)】
録音開始音は鳴らさない(キーは自分で押すので「始まった」は分かる)。
本当に欲しいのは「話し終えて文字が入った合図」=完了音「ピッ」。
認識できなかった時だけ、少し低い「ピッ」で成功と区別する。
全体のオン/オフは settings.json の sound_feedback(設定画面「録音キー」タブ)。
"""

import io
import math
import queue
import struct
import threading
import wave

_q = queue.Queue()
_worker_started = False
_lock = threading.Lock()
_cache = {}


def _make_wav(freq, ms, volume, rate=44100):
    """短いサイン波の「ピッ」を WAV バイト列で作る。両端を軽くフェードして
    プチッというノイズを防ぐ。volume は 0.0〜1.0(小さめ推奨)。"""
    n = int(rate * ms / 1000)
    amp = 32767 * max(0.0, min(1.0, volume))
    fade = max(1, int(n * 0.12))
    frames = bytearray()
    for i in range(n):
        env = 1.0
        if i < fade:
            env = i / fade
        elif i > n - fade:
            env = (n - i) / fade
        s = int(amp * env * math.sin(2 * math.pi * freq * i / rate))
        frames += struct.pack("<h", s)
    buf = io.BytesIO()
    w = wave.open(buf, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(rate)
    w.writeframes(bytes(frames))
    w.close()
    return buf.getvalue()


def _get_wav(key, freq, ms, volume):
    if key not in _cache:
        try:
            _cache[key] = _make_wav(freq, ms, volume)
        except Exception:
            _cache[key] = None
    return _cache[key]


def _worker():
    """行列から1つずつ取り出し、順番に最後まで鳴らす(衝突しない)。"""
    while True:
        data = _q.get()
        try:
            if data:
                import winsound

                winsound.PlaySound(data, winsound.SND_MEMORY)
        except Exception:
            pass  # 音が出せない環境でも処理は止めない
        finally:
            _q.task_done()


def _ensure_worker():
    global _worker_started
    if _worker_started:
        return
    with _lock:
        if not _worker_started:
            threading.Thread(target=_worker, daemon=True).start()
            _worker_started = True


def _play_async(key, freq, ms, volume):
    """「ピッ」を行列に入れる。鳴らすのはワーカーが順番に行う。"""
    _ensure_worker()
    _q.put(_get_wav(key, freq, ms, volume))


def recording_start():
    """録音開始: 鳴らさない(キーを押す自覚があるため不要)。"""
    return


def recording_done():
    """認識完了: 短く小さい「ピッ」(成功の合図)。"""
    _play_async("done", 1000, 110, 0.18)


def error():
    """認識できず: 少し低い「ピッ」(成功と区別)。"""
    _play_async("error", 520, 140, 0.18)
