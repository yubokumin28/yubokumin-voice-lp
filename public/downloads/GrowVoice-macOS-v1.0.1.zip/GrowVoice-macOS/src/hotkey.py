# -*- coding: utf-8 -*-
"""hotkey.py - 録音ホットキーの妥当性チェック(純粋ロジック・テスト可能)

設定画面で「キーを押して登録」した時、そのキーが録音キーとして
ふさわしいかを判定する。音声・GPU・keyboard ライブラリに依存しない
純粋な関数なので、自動テストでそのまま検証できる。
"""

# 修飾キー。単体では文字を入力しないので録音キーに向く。
MODIFIER_NAMES = {
    "ctrl", "left ctrl", "right ctrl",
    "alt", "left alt", "right alt", "alt gr",
    "shift", "left shift", "right shift",
    "windows", "left windows", "right windows",
}

# 入力に不可欠なキー。録音キーにすると普段の操作ができなくなる。
ESSENTIAL_NAMES = {
    "enter", "space", "backspace", "tab", "esc", "escape",
    "delete", "up", "down", "left", "right",
    "home", "end", "page up", "page down", "insert",
}


def _is_text_key(name):
    """単体で押すと文字が入力されるキー(英数字・記号1文字)か。"""
    return len(name) == 1 and name.isprintable()


def evaluate_hotkey(names):
    """録音キー候補の妥当性を判定する。

    names : 押されたキー名のリスト(例 ["left alt"] / ["ctrl", "1"])
    戻り値: (level, message)
      level = "ok"   問題なし
            = "warn" 使えるが注意(他機能と重なる恐れ)
            = "bad"  録音キーに不向き(やめたほうがよい)
    """
    if not names:
        return ("bad", "キーを取得できませんでした。もう一度押してください。")

    norm = [str(n).lower().strip() for n in names if n]
    if not norm:
        return ("bad", "キーを取得できませんでした。もう一度押してください。")
    nset = set(norm)
    non_mods = [n for n in norm if n not in MODIFIER_NAMES]

    essential = sorted(nset & ESSENTIAL_NAMES)
    if essential:
        return ("bad",
                "「" + "・".join(essential) + "」は入力に欠かせないキーです。"
                "録音キーには別のキーを選んでください。")

    if len(norm) == 1 and _is_text_key(norm[0]):
        return ("bad",
                "「" + norm[0] + "」単体は、押すたびにその文字が入力されて"
                "誤録音します。Alt などと組み合わせてください。")

    if "right ctrl" in nset:
        return ("warn",
                "右Ctrl は Aqua Voice と同じキーです。両方を起動すると"
                "衝突します。左側のキーをおすすめします。")

    if nset & {"windows", "left windows", "right windows"}:
        return ("warn",
                "Windows キーはスタートメニューが開くことがあります。"
                "別のキーをおすすめします。")

    if "caps lock" in nset:
        return ("warn",
                "Caps Lock は大文字ロックが切り替わってしまいます。"
                "別のキーをおすすめします。")

    if not non_mods:
        # 修飾キーだけ(単体または修飾キー同士の組み合わせ)
        alt_keys = {"alt", "left alt", "right alt", "alt gr"}
        ctrl_keys = {"ctrl", "left ctrl", "right ctrl"}
        if len(norm) == 1 and norm[0] in alt_keys:
            return ("warn",
                    "Alt 単体は反応しにくいキーです。Windows がメニューバーや"
                    "アクセスキー用に押下を消費するため、音声入力で捉えられない"
                    "ことがあります。「Ctrl+Alt」のような組み合わせを推奨します。")
        if len(norm) == 1 and norm[0] in ctrl_keys:
            return ("warn",
                    "Ctrl 単体は Ctrl+C 等のショートカットと重なります。"
                    "0.3秒未満の押下は無視しますが、ショートカット操作中に"
                    "誤反応することがあります。「Ctrl+Alt」のような組み合わせ"
                    "を推奨します。")
        return ("ok", "このキーで録音キーに登録できます。")

    # 修飾キー + 通常キー の組み合わせ(例 Ctrl+1)
    if any(n in MODIFIER_NAMES for n in norm):
        return ("ok", "この組み合わせで録音キーに登録できます。")

    # 修飾キーを含まない単体キー(F9 等のファンクションキーなど)
    if len(norm) == 1:
        return ("ok", "このキーで録音キーに登録できます。")

    # 修飾キーを含まない通常キーの組み合わせ
    return ("warn",
            "Ctrl や Alt などの修飾キーを含まない組み合わせは、"
            "他のアプリの操作と重なることがあります。")


# ---------------------------------------------------------------------------
# キー名による録音キー判定 (純粋関数・テスト可能)
# ---------------------------------------------------------------------------
# スキャンコードでは左右Ctrl(同じ29)/左右Alt(同じ56)を区別できないため、
# keyboard ライブラリのフックが渡す e.name を使う。登録時も実行時も同じ
# e.name を見るので、ライブラリの命名規則がどうであれ左右が一致する。

def _normalize_name(name):
    """キー名を比較用に正規化する(小文字化・前後空白除去)。"""
    if name is None:
        return ""
    return str(name).lower().strip()


def parse_hotkey_label(label):
    """「left alt」「ctrl+1」等のラベルを正規化キー名のリストに分解する。

    label の "+" 区切り。空要素は無視。各要素を _normalize_name で正規化。
    """
    if not label:
        return []
    out = []
    for part in str(label).split("+"):
        n = _normalize_name(part)
        if n:
            out.append(n)
    return out


# 汎用Modifier名 -> 同等とみなすキー名集合。
# target に「ctrl」「alt」等の汎用名を指定すると、実機の e.name が
# 「ctrl」「left ctrl」「right ctrl」のいずれであってもマッチさせる。
# これにより keyboard ライブラリの実機差(左Altが "alt" として届く環境と
# "left alt"/"left menu" として届く環境)を吸収できる。
# 具体名(「left ctrl」等)を target に指定した場合は厳密一致のみ。
_MODIFIER_GENERIC = {
    "ctrl": {"ctrl", "left ctrl", "right ctrl"},
    "alt": {"alt", "left alt", "right alt", "alt gr",
            "left menu", "right menu"},
    "shift": {"shift", "left shift", "right shift"},
    "windows": {"windows", "left windows", "right windows"},
}


def _candidates_for(name):
    """target キー名にマッチさせる候補名の集合を返す。"""
    n = _normalize_name(name)
    return _MODIFIER_GENERIC.get(n, {n})


def hotkey_matches(target_names, held_names):
    """録音キー(target_names)が今すべて押されている(held_names)か。

    target_names : 録音キーを構成するキー名(iterable)。空なら常に False。
    held_names   : 今押されているキー名の集合(iterable)。

    汎用Modifier名(「ctrl」「alt」「shift」「windows」)は左右どちらでもマッチ。
    具体名(「left ctrl」等)は厳密一致のみ。
    """
    targets = [_normalize_name(n) for n in target_names if _normalize_name(n)]
    if not targets:
        return False
    held = {_normalize_name(n) for n in held_names if _normalize_name(n)}
    for t in targets:
        if not (_candidates_for(t) & held):
            return False
    return True


# 表示用の英語キー名 -> 日本語表記。ターミナルや設定画面の現在キー表示用。
_PRETTY_KEY_MAP = {
    "left ctrl": "左Ctrl",
    "right ctrl": "右Ctrl",
    "ctrl": "Ctrl",
    "left alt": "左Alt",
    "right alt": "右Alt",
    "alt gr": "右Alt",
    "left menu": "左Alt",
    "right menu": "右Alt",
    "alt": "Alt",
    "left shift": "左Shift",
    "right shift": "右Shift",
    "shift": "Shift",
    "left windows": "左Windows",
    "right windows": "右Windows",
    "windows": "Windows",
    "space": "スペース",
    "enter": "Enter",
    "tab": "Tab",
    "esc": "Esc",
    "escape": "Esc",
    "pause": "Pause",
    "pause break": "Pause",
    "scroll lock": "ScrollLock",
    "caps lock": "CapsLock",
}


def pretty_key_label(label):
    """「left alt」→「左Alt」、「ctrl+alt+d」→「Ctrl+Alt+D」等に変換する。

    辞書に無いキーは元の表記の各単語を頭文字大文字化して返す
    (例: "f9" -> "F9"、"1" -> "1")。表示専用なので比較には使わない。
    """
    if not label:
        return ""
    parts = []
    for raw in str(label).split("+"):
        n = _normalize_name(raw)
        if not n:
            continue
        if n in _PRETTY_KEY_MAP:
            parts.append(_PRETTY_KEY_MAP[n])
        elif len(n) == 1:
            parts.append(n.upper())
        else:
            parts.append(n[:1].upper() + n[1:])
    return "+".join(parts)
