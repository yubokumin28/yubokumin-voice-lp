# -*- coding: utf-8 -*-
"""tray.py - タスクトレイ常駐(Aqua Voice 流 / Mac対応)

Aqua Voice と同じく、タスクトレイ(Mac はメニューバー)にアイコンを常駐させ、
設定は **マウスの右クリックメニュー** から開く。キーボードホックは録音キーだけが
触るので、「設定を開くと音声入力が止まる」系の構造的衝突が消える。

本体(hotkey_app.py)から create_tray(...) を呼び、メニューのアクションは
コールバック関数で本体に通知する。アイコンは別スレッドで動くので、
keyboard.wait() / pynput Listener の常駐ループとは干渉しない。

設計上の重要ポイント:
  - 設定は Win: pythonw.exe / Mac: python(GUI 起動)でターミナル窓を出さない。
    本体プロセスのコンソール・stdio は一切継承せず DETACHED で起動。
  - アイコン画像は依存ファイルなしで Pillow で生成する。
  - OS 差は platform_compat に集約(自動起動・無窓 Python・パスを開く・
    システム設定を開く)。
"""

import datetime
import sys
import threading
from pathlib import Path

import pystray
from PIL import Image, ImageDraw

import platform_compat

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
SETTINGS_UI = SRC / "settings_ui.py"
HISTORY_PY = SRC / "history.py"
PROOFREAD_CLI = SRC / "proofread_cli.py"
LOGS_DIR = ROOT / "logs"


# ---------------------------------------------------------------------------
# アイコン生成
# ---------------------------------------------------------------------------

def _make_icon_image(size=64):
    """マイクアイコンを Pillow で生成する。

    設定画面のデザイン(クリーム+黄アクセント)に合わせ、「黄色い丸 +
    濃い茶色のマイク」にする。設定画面右上のバッジと同じ配色なので、
    トレイ・タスクバー・設定画面で見た目が統一される。
    """
    # アプリのロゴ(Grow Voice エンブレム)があれば最優先で使う
    try:
        from pathlib import Path as _Path
        _mark = _Path(__file__).resolve().parent.parent / "assets" / "icon_mark.png"
        if _mark.exists():
            return Image.open(_mark).convert("RGBA").resize(
                (size, size), Image.LANCZOS)
    except Exception:
        pass

    # --- フォールバック: 黄色マイクを描画(配色 黄 #F6C544 / 濃茶 #633806) ---
    BG = (246, 197, 68, 255)    # ACCENT(黄色)
    FG = (99, 56, 6, 255)       # ACCENT_TEXT(濃い茶色)
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # 1. 背景の丸(黄色・設定画面の丸バッジに合わせる)
    margin = 1
    draw.ellipse(
        [margin, margin, size - margin, size - margin],
        fill=BG,
    )

    # 2. マイクのカプセル(縦長の丸角四角・大きめ)
    cap_w = size * 0.40
    cap_h = size * 0.46
    cap_x = (size - cap_w) / 2
    cap_y = size * 0.14
    draw.rounded_rectangle(
        [cap_x, cap_y, cap_x + cap_w, cap_y + cap_h],
        radius=cap_w / 2,
        fill=FG,
    )

    # 3. 受け台のブラケット(U字・太め)
    br_x1 = size * 0.22
    br_x2 = size * 0.78
    br_y1 = size * 0.46
    br_y2 = size * 0.74
    draw.arc(
        [br_x1, br_y1, br_x2, br_y2],
        start=0,
        end=180,
        fill=FG,
        width=max(3, int(size * 0.08)),
    )

    # 4. スタンドの縦棒(太め)
    stand_w = max(3, int(size * 0.08))
    stand_x = size / 2
    draw.line(
        [(stand_x, size * 0.74), (stand_x, size * 0.87)],
        fill=FG,
        width=stand_w,
    )

    # 5. 底の横棒(ベース・太め)
    base_y = size * 0.87
    draw.line(
        [(size * 0.30, base_y), (size * 0.70, base_y)],
        fill=FG,
        width=stand_w,
    )

    return img


# ---------------------------------------------------------------------------
# Python の見つけ方(無窓 Python を最優先 = ターミナル窓を出さない)
# ---------------------------------------------------------------------------

def _find_pythonw():
    """ターミナル窓を出さない Python を返す(Win: pythonw.exe / Mac: venv python)。

    実体は platform_compat.find_no_console_python() に委譲。
    既存呼び出し側(hotkey_app.py)との互換のためこの名前を残す。
    """
    return platform_compat.find_no_console_python()


def _spawn_detached(python_path, script_path, *args, low_priority=False):
    """子プロセスを「完全に切り離して」起動する(親 console は継承しない)。

    OS 差(Win: CREATE_NEW_PROCESS_GROUP|DETACHED_PROCESS / Mac: start_new_session)
    は platform_compat.spawn_detached() に集約。
    既存呼び出し側との互換のためこの名前を残す。
    """
    platform_compat.spawn_detached(python_path, script_path, *args,
                                   low_priority=low_priority)


# ---------------------------------------------------------------------------
# メニューアクション
# ---------------------------------------------------------------------------

def open_settings(icon=None, item=None):
    """設定UIを起動する。ターミナル窓は出さない(無窓 Python で起動)。"""
    try:
        if getattr(sys, "frozen", False):
            # 単体exe時は exe 自身を設定モードで呼ぶ(.py も pythonw も同梱しない)
            platform_compat.spawn_app_mode("settings")
            return
        pythonw = _find_pythonw()
        if not SETTINGS_UI.exists():
            print(f" 【警告】settings_ui.py が見つかりません: {SETTINGS_UI}")
            return
        _spawn_detached(pythonw, SETTINGS_UI)
    except Exception as e:
        print(f" 【警告】設定画面の起動に失敗しました: {e}")


def open_history(icon=None, item=None):
    """今日の履歴を既定アプリで直接開く(Python の中間プロセスを通さない)。

    Win では .txt は メモ帳で、Mac では TextEdit 等の既定アプリで開く。
    今日の履歴が無ければ logs フォルダ自体を開く。
    """
    try:
        today = datetime.datetime.now().strftime("%Y%m%d")
        log_path = LOGS_DIR / f"history_{today}.txt"
        if log_path.exists():
            platform_compat.open_path(str(log_path))
        elif LOGS_DIR.exists():
            platform_compat.open_path(str(LOGS_DIR))
        else:
            print(" 履歴ファイルが見つかりません。")
    except Exception as e:
        print(f" 【警告】履歴の起動に失敗しました: {e}")


def proofread_history(icon=None, item=None):
    """今日の履歴を Ollama で推敲する(別プロセス・無窓)。完了後に結果を開く。

    リアルタイム認識には触れない裏方処理。proofread_cli.py を切り離して
    起動し、推敲し終えたら history_YYYYMMDD_refined.txt を既定アプリで開く。
    Ollama が無ければ proofread_cli 側が静かに何もしない。
    """
    try:
        if getattr(sys, "frozen", False):
            platform_compat.spawn_app_mode("proofread", "--open")
            print(" 今日の履歴を裏で推敲しています(完了したら結果を開きます)。")
            return
        pythonw = _find_pythonw()
        if not PROOFREAD_CLI.exists():
            print(f" 【警告】proofread_cli.py が見つかりません: {PROOFREAD_CLI}")
            return
        _spawn_detached(pythonw, PROOFREAD_CLI, "--open")
        print(" 今日の履歴を裏で推敲しています(完了したら結果を開きます)。")
    except Exception as e:
        print(f" 【警告】履歴の推敲起動に失敗しました: {e}")


def open_taskbar_settings(icon=None, item=None):
    """タスクバー(Mac はメニューバー)の表示設定を開く。

    旦那様がトレイアイコンを常時表示(隠さない)にしたい時に使う。
    Win 11: 設定 → 個人用設定 → タスクバー → その他のシステムトレイアイコン
    Mac  : システム設定 → コントロールセンター
    """
    try:
        platform_compat.open_system_taskbar_settings()
    except Exception as e:
        print(f" 【警告】タスクバー設定の起動に失敗しました: {e}")


# ---------------------------------------------------------------------------
# ログイン時の自動起動
# ---------------------------------------------------------------------------
# 旦那様の運用方針:「PC を起動したら音声入力ツールも自動で常駐」。
# 一度起動したら終了せず常駐し続けるので、ツールを閉じて再び開く時の
# モデル再ロード(約3秒の遅延)が原理的に起きなくなる。
#
# OS 差は platform_compat に集約:
#   Win: スタートアップに無窓起動の .vbs を置く
#   Mac: ~/Library/LaunchAgents/com.voiceinput.tool.plist + launchctl load

def is_autostart_enabled(item=None):  # noqa: ARG001
    """ログイン時の自動起動が登録されているか(チェック表示用)。"""
    try:
        return bool(platform_compat.is_autostart_enabled())
    except Exception:
        return False


def toggle_autostart(icon=None, item=None):
    """ログイン時の自動起動をオン/オフする。"""
    try:
        before = is_autostart_enabled()
        after = bool(platform_compat.toggle_autostart())
        if after and not before:
            print(" ログイン時に自動で起動するようにしました。")
        elif before and not after:
            print(" 自動起動をオフにしました。")
        if icon is not None:
            icon.update_menu()
    except Exception as e:
        print(f" 【警告】自動起動の切り替えに失敗しました: {e}")


# ---------------------------------------------------------------------------
# トレイ起動本体
# ---------------------------------------------------------------------------

def create_tray(on_reset, on_quit):
    """タスクトレイを別スレッドで起動する。本体はブロックされない。

    引数:
      on_reset : 「緊急リセット」が選ばれた時に呼ぶコールバック(引数なし)
      on_quit  : 「終了」が選ばれた時に呼ぶコールバック(引数なし)

    返り値: pystray.Icon インスタンス
            本体終了時に icon.stop() を呼ぶとトレイから消える。
    """
    def _on_reset(icon, item):
        try:
            on_reset()
        except Exception as e:
            print(f" 【警告】緊急リセットに失敗: {e}")

    def _on_quit(icon, item):
        try:
            on_quit()
        finally:
            try:
                icon.stop()
            except Exception:
                pass

    menu = pystray.Menu(
        pystray.MenuItem("設定を開く", open_settings, default=True),
        pystray.MenuItem("緊急リセット", _on_reset),
        pystray.MenuItem("履歴を見る", open_history),
        pystray.MenuItem("今日の履歴を推敲する (AI)", proofread_history),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("常時表示にする (システム設定)", open_taskbar_settings),
        pystray.MenuItem(
            "PC起動時に自動で起動する",
            toggle_autostart,
            checked=is_autostart_enabled,
        ),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("終了", _on_quit),
    )
    icon = pystray.Icon(
        "voice_input",
        _make_icon_image(),
        "音声入力ツール(右クリックでメニュー)",
        menu,
    )
    thread = threading.Thread(target=icon.run, daemon=True)
    thread.start()
    return icon
