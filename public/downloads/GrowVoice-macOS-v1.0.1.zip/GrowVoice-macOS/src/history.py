# -*- coding: utf-8 -*-
"""history.py - 文字起こし履歴の記録 (Round1)

音声入力するたびに、結果を日付別のログ(logs/history_YYYYMMDD.txt)へ追記する。
挿入に失敗してもログには残るので、テキストを失わずに後から拾える。
"""

import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = ROOT / "logs"


def append(raw, formatted, log_dir=None):
    """1回分の文字起こしを日付別ログに追記し、ファイルパスを返す。"""
    base = Path(log_dir) if log_dir else LOG_DIR
    base.mkdir(parents=True, exist_ok=True)
    now = datetime.datetime.now()
    path = base / f"history_{now:%Y%m%d}.txt"
    line = f"[{now:%H:%M:%S}] {formatted}\n"
    if raw and raw != formatted:
        line += f"    (認識の生テキスト: {raw})\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)
    return path


def today_log(log_dir=None):
    """今日の履歴ファイルのパスを返す(存在しない場合もある)。"""
    base = Path(log_dir) if log_dir else LOG_DIR
    now = datetime.datetime.now()
    return base / f"history_{now:%Y%m%d}.txt"


def append_discarded(raw, reason, log_dir=None):
    """異常検知で破棄した内容を日付別ログに残す(後から確認できるように)。

    破棄テキストは挿入されず履歴にも残らないため、何が起きたかを
    logs/discarded_YYYYMMDD.txt に時刻・理由つきで保存する。
    返り値: ファイルパス。
    """
    base = Path(log_dir) if log_dir else LOG_DIR
    base.mkdir(parents=True, exist_ok=True)
    now = datetime.datetime.now()
    path = base / f"discarded_{now:%Y%m%d}.txt"
    line = f"[{now:%H:%M:%S}] 理由: {reason}\n    破棄テキスト: {raw}\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)
    return path


def today_discarded(log_dir=None):
    """今日の破棄ログのパスを返す(存在しない場合もある)。"""
    base = Path(log_dir) if log_dir else LOG_DIR
    now = datetime.datetime.now()
    return base / f"discarded_{now:%Y%m%d}.txt"


def cleanup_old_logs(log_dir=None, days=30, latency_max_lines=10000,
                     latency_keep_lines=5000):
    """古い履歴ログを自動で消去する(起動時に1回呼ぶ想定)。

    - `history_YYYYMMDD.txt` のうち `days` 日より前のものを削除
    - `latency.csv` の行数が `latency_max_lines` を超えたら、ヘッダを残しつつ
      末尾 `latency_keep_lines` 行に切り詰める

    返り値: 削除した履歴ファイル数(統計表示用)。
    """
    base = Path(log_dir) if log_dir else LOG_DIR
    if not base.exists():
        return 0

    threshold = datetime.datetime.now() - datetime.timedelta(days=days)
    removed = 0
    for pattern, prefix in (("history_*.txt", "history_"),
                            ("discarded_*.txt", "discarded_")):
        for f in base.glob(pattern):
            try:
                stem = f.stem.replace(prefix, "")
                file_date = datetime.datetime.strptime(stem, "%Y%m%d")
                if file_date < threshold:
                    f.unlink()
                    removed += 1
            except (ValueError, OSError):
                # ファイル名が想定外 or 削除失敗は静かに無視
                pass

    # latency.csv の肥大化を抑える
    lat = base / "latency.csv"
    if lat.exists():
        try:
            with open(lat, encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) > latency_max_lines:
                header = (lines[0] if lines
                          and lines[0].lower().startswith("timestamp")
                          else None)
                keep = lines[-latency_keep_lines:]
                if header and header not in keep:
                    keep = [header] + keep
                with open(lat, "w", encoding="utf-8") as f:
                    f.writelines(keep)
        except Exception:
            pass

    return removed


def _open_today():
    """今日の履歴をメモ帳で開く(履歴を見る.bat から呼ばれる)。"""
    import subprocess

    path = today_log()
    if path.exists():
        subprocess.Popen(["notepad.exe", str(path)])
    else:
        print("今日の履歴はまだありません。")
        input("Enterキーで閉じます...")


if __name__ == "__main__":
    _open_today()
