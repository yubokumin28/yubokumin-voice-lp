# -*- coding: utf-8 -*-
"""overlay.py - 録音中ランプ(アクティブ画面の中央下にフロート表示 / Mac対応)

音声入力ツールの「今の状態」を、Aqua Voice / Google 音声入力 風の丸い
マイク+波形パネルで、入力先ディスプレイの中央下に表示する。

状態(本体 hotkey_app.py が logs/overlay_state.txt に書く):
  - idle      : 非表示(タイピングの邪魔をしない)
  - recording : 「● 音声入力中」 青 + 波形アニメ
  - busy      : 「● 認識中」     橙 + ドット
  - error     : 「● エラー」     赤 + 警告マーク
  - repair    : 「● 自動修復中」 橙 + 巡回ドット

別プロセスで動き、本体が消えたら自動終了する(ゾンビ化しない)。
モニタ座標取得・親プロセス生存判定は OS 差を platform_compat に集約。
手動なら:  python overlay.py <本体のPID>
"""

import math
import sys
import time
import tkinter as tk
from pathlib import Path

# overlay.py は subprocess として起動されるので、 sys.path に src が
# 入っていない可能性がある。 明示的に追加してから platform_compat を import。
_SRC = Path(__file__).resolve().parent
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

import platform_compat  # noqa: E402

ROOT = _SRC.parent
STATE_FILE = ROOT / "logs" / "overlay_state.txt"

# 録音/認識中がこの秒数を超えて続いたら、本体側の取りこぼしとみなして
# 強制的に待機(非表示)へ戻す保険。
STATE_STUCK_TIMEOUT_SEC = 30

# 透明にする背景キー色(この色のピクセルがウインドウから透けて消える)
KEY_COLOR = "#fe00fe"

# パネル外観(小さめ・控えめ)
W = 178
H = 38
RADIUS = 12
BOTTOM_MARGIN = 20
PANEL = "#eef1f6"        # パネル地(淡いグレー)

# 状態 -> (表示文字, アクセント色, アニメ種別)
_STYLES = {
    "recording": ("音声入力中", "#2f7fc4", "wave"),    # 青 + 波形
    "busy":      ("認識中",     "#b07d2e", "dots"),    # 橙 + ドット
    "error":     ("エラー",     "#d24343", "error"),   # 赤 + 警告
    "repair":    ("自動修復中", "#d98b2b", "repair"),  # 橙 + 巡回ドット
}


def _read_state():
    try:
        return STATE_FILE.read_text(encoding="utf-8").strip() or "idle"
    except Exception:
        return "idle"


# --- 描画ヘルパー ---------------------------------------------------------

def _round_rect(cv, x1, y1, x2, y2, r, color):
    """角丸の塗り(枠線なし)を描く。"""
    cv.create_rectangle(x1 + r, y1, x2 - r, y2, fill=color, outline=color)
    cv.create_rectangle(x1, y1 + r, x2, y2 - r, fill=color, outline=color)
    cv.create_oval(x1, y1, x1 + 2 * r, y1 + 2 * r, fill=color, outline=color)
    cv.create_oval(x2 - 2 * r, y1, x2, y1 + 2 * r, fill=color, outline=color)
    cv.create_oval(x1, y2 - 2 * r, x1 + 2 * r, y2, fill=color, outline=color)
    cv.create_oval(x2 - 2 * r, y2 - 2 * r, x2, y2, fill=color, outline=color)


def _draw_mic(cv, cx, cy, s, color):
    """小さなマイク(カプセル+受け台+スタンド)を描く。"""
    hw = s * 0.42
    top = cy - s * 0.62
    bot = cy + s * 0.06
    lw = max(2, int(s * 0.09))
    # カプセル(縦長の丸角)
    cv.create_oval(cx - hw / 2, top, cx + hw / 2, top + hw,
                   fill=color, outline=color)
    cv.create_oval(cx - hw / 2, bot - hw, cx + hw / 2, bot,
                   fill=color, outline=color)
    cv.create_rectangle(cx - hw / 2, top + hw / 2, cx + hw / 2, bot - hw / 2,
                        fill=color, outline=color)
    # 受け台(U字)
    cv.create_arc(cx - s * 0.52, cy - s * 0.28, cx + s * 0.52, cy + s * 0.42,
                  start=200, extent=140, style="arc", outline=color, width=lw)
    # スタンド + 台座
    cv.create_line(cx, cy + s * 0.42, cx, cy + s * 0.66, fill=color, width=lw)
    cv.create_line(cx - s * 0.26, cy + s * 0.66, cx + s * 0.26, cy + s * 0.66,
                   fill=color, width=lw)


def _draw_anim(cv, kind, accent, frame, x0, x1, cy):
    """状態ごとの右側アニメーション。"""
    if kind == "wave":
        n = 5
        bw = 5
        gap = (x1 - x0 - n * bw) / (n - 1)
        for i in range(n):
            x = x0 + i * (bw + gap)
            amp = 0.30 + 0.70 * abs(math.sin(frame * 0.5 + i * 0.7))
            bh = (H * 0.46) * amp
            cv.create_rectangle(x, cy - bh / 2, x + bw, cy + bh / 2,
                                fill=accent, outline=accent)
    elif kind == "dots":
        for i in range(3):
            x = x0 + 12 + i * 18
            r = 3 + 1.6 * abs(math.sin(frame * 0.4 + i))
            cv.create_oval(x - r, cy - r, x + r, cy + r,
                           fill=accent, outline=accent)
    elif kind == "repair":
        active = (frame // 2) % 3
        for i in range(3):
            x = x0 + 12 + i * 18
            if i == active:
                r = 5
                col = accent
            else:
                r = 3
                col = "#e0cb9a"
            cv.create_oval(x - r, cy - r, x + r, cy + r, fill=col, outline=col)
    elif kind == "error":
        cx = x0 + 28
        cv.create_polygon(cx, cy - 11, cx - 12, cy + 9, cx + 12, cy + 9,
                          fill=accent, outline=accent)
        cv.create_line(cx, cy - 4, cx, cy + 3, fill="white", width=2)
        cv.create_oval(cx - 1, cy + 5, cx + 1, cy + 7,
                       fill="white", outline="white")


def main():
    parent_pid = int(sys.argv[1]) if len(sys.argv) > 1 else 0

    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    try:
        root.attributes("-transparentcolor", KEY_COLOR)  # 角丸の外側を透過
    except Exception:
        pass
    root.configure(bg=KEY_COLOR)

    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    init_x = (screen_w - W) // 2
    init_y = screen_h - H - BOTTOM_MARGIN
    root.geometry(f"{W}x{H}+{init_x}+{init_y}")

    cv = tk.Canvas(root, width=W, height=H, bg=KEY_COLOR,
                   highlightthickness=0, bd=0)
    cv.pack(fill="both", expand=True)

    ui = {"frame": 0, "shown": True, "x": init_x, "y": init_y}
    last_state = {"value": None, "since": time.monotonic()}

    def _reposition():
        rect = platform_compat.get_active_monitor_work_rect()
        if rect is None:
            x = (screen_w - W) // 2
            y = screen_h - H - BOTTOM_MARGIN
        else:
            left, top, right, bottom = rect
            x = (left + right) // 2 - W // 2
            y = bottom - H - BOTTOM_MARGIN
        if x != ui["x"] or y != ui["y"]:
            root.geometry(f"{W}x{H}+{x}+{y}")
            ui["x"] = x
            ui["y"] = y

    def tick():
        if not platform_compat.is_process_alive(parent_pid):
            root.destroy()
            return
        state = _read_state()
        # 録音/認識が長時間続いたら待機へ戻す保険
        now = time.monotonic()
        if state != last_state["value"]:
            last_state["value"] = state
            last_state["since"] = now
        elif (state in ("recording", "busy")
                and now - last_state["since"] > STATE_STUCK_TIMEOUT_SEC):
            state = "idle"
            last_state["value"] = "idle"

        if state not in _STYLES:  # idle 等 → 隠す
            if ui["shown"]:
                root.withdraw()
                ui["shown"] = False
            root.after(150, tick)
            return

        if not ui["shown"]:
            root.deiconify()
            try:
                root.attributes("-topmost", True)
            except Exception:
                pass
            ui["shown"] = True
        _reposition()

        label, accent, anim = _STYLES[state]
        ui["frame"] += 1
        cv.delete("all")
        _round_rect(cv, 2, 2, W - 2, H - 2, RADIUS, PANEL)
        _draw_mic(cv, 19, H / 2, 16, accent)
        cv.create_text(36, H / 2, text=label, anchor="w", fill=accent,
                       font=("Yu Gothic UI", 10, "bold"))
        _draw_anim(cv, anim, accent, ui["frame"], 108, W - 10, H / 2)
        root.after(120, tick)

    tick()
    root.mainloop()


if __name__ == "__main__":
    main()
