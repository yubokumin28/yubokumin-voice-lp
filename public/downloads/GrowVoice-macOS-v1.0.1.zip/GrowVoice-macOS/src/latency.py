# -*- coding: utf-8 -*-
"""latency.py - 段階別の処理時間を計測する (Step1で追加)

喋り終わってから出力までの各処理の所要時間を測り、画面表示とCSV記録を行う。
改善の効果を数字で追えるようにするための仕組み。
"""

import csv
import datetime
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LOG_PATH = ROOT / "logs" / "latency.csv"


class Stopwatch:
    """名前付きの区間時間を計測する簡易ストップウォッチ。"""

    def __init__(self):
        self._start = time.perf_counter()
        self._last = self._start
        self.laps = []  # [(名前, 秒), ...]

    def lap(self, name):
        """直前の lap からの経過時間を name の区間として記録する。"""
        now = time.perf_counter()
        self.laps.append((name, now - self._last))
        self._last = now

    def total(self):
        """計測開始からの合計秒数。"""
        return time.perf_counter() - self._start

    def summary(self):
        """画面表示用の1行サマリー。"""
        parts = " / ".join(f"{n} {d:.2f}秒" for n, d in self.laps)
        return f"{parts} / 合計 {self.total():.2f}秒"

    def log(self, log_path=None):
        """1行を CSV に追記する(改善の推移を後から確認できる)。"""
        path = Path(log_path) if log_path else LOG_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        is_new = not path.exists()
        with open(path, "a", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            if is_new:
                writer.writerow(["日時"] + [n for n, _ in self.laps] + ["合計"])
            writer.writerow(
                [datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
                + [f"{d:.3f}" for _, d in self.laps]
                + [f"{self.total():.3f}"]
            )
