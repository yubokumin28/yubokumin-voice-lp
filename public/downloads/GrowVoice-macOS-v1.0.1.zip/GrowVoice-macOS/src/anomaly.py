# -*- coding: utf-8 -*-
"""anomaly.py - 認識結果の文字化け検出

faster-whisper は低品質オーディオ・無音・極端に短い録音などで
「ノイズから漢字の羅列を幻覚する」ことがある。 そのままカーソル位置に
貼り付けると旦那様の作業文書が壊れるため、 貼り付け前に検出する。

代表的な症状(旦那様の実例):
  「砲化合頤墨打減合理参戮梁壇堤掛巨頤垂頤床堤頤墜海草梅蹼上頤虫菁壁維」
  → ひらがな率がほぼゼロ / 異常に珍しい漢字が連続する。

判定ロジックは保守的(誤検出ゼロ重視)。 通常の日本語テキスト・建設用語の
専門文書・英数記号が混じった文 などは絶対に通すこと。
"""

import unicodedata

# よく出る「幻覚漢字」のホワイトリスト。 これらが密集していたら強い文字化けシグナル。
# (旦那様の実例とインターネット上の whisper hallucination 報告から抽出)
HALLUCINATION_KANJI = set(
    "頤垂蕁蝅甩痰蹼貽虫菁墜壁裂梁壇蹲廷甩墨戮戌剽糀薈簒鼇齧饗驟鬪鬱"
    "髑髏髏髑鴿鵠鸚鵡蠅蠱蠱蟲蟲蛞蛻蛟螢蟒蜻蜉蜂"
)


def _classify(char):
    """1文字を 'hira' / 'kata' / 'kanji' / 'ascii' / 'other' に分類する。"""
    if '぀' <= char <= 'ゟ':
        return 'hira'
    if '゠' <= char <= 'ヿ':
        return 'kata'
    if '一' <= char <= '鿿':
        return 'kanji'
    if char.isascii() and (char.isalnum() or char in ' .,!?-'):
        return 'ascii'
    if char in '、。「」『』()()!?・…':
        return 'punct'
    return 'other'


def is_garbled(text):
    """text が文字化け(認識ハルシネーション)疑いなら True を返す。

    判定基準(いずれかを満たすと True):
      1. 文字数 8以上で、 漢字率 70% 超 かつ ひらがな率 10% 未満
      2. 文字数 8以上で、 幻覚漢字ホワイトリストの文字を3文字以上含む
      3. 文字数 6以上で、 ひらがな・カタカナ・ASCII がゼロ(漢字と記号のみ)
    """
    if not text or len(text) < 6:
        return False

    counts = {'hira': 0, 'kata': 0, 'kanji': 0, 'ascii': 0, 'punct': 0, 'other': 0}
    hallucination_hits = 0
    for c in text:
        counts[_classify(c)] += 1
        if c in HALLUCINATION_KANJI:
            hallucination_hits += 1

    total_letters = counts['hira'] + counts['kata'] + counts['kanji'] + counts['ascii']
    if total_letters < 5:
        return False

    # 基準3: 文字と記号だけで「漢字+記号」しかない(ひら/カタ/ASCII がゼロ)
    if counts['hira'] == 0 and counts['kata'] == 0 and counts['ascii'] == 0 and counts['kanji'] >= 6:
        return True

    # 基準1: 漢字率と ひらがな率
    kanji_rate = counts['kanji'] / total_letters
    hira_rate = counts['hira'] / total_letters
    if len(text) >= 8 and kanji_rate > 0.7 and hira_rate < 0.10:
        return True

    # 基準2: 幻覚漢字ホワイトリスト
    if len(text) >= 8 and hallucination_hits >= 3:
        return True

    return False


def garble_reason(text):
    """is_garbled が True を返した時、 理由を短い日本語文字列で返す。

    ログ表示用。 旦那様が後で原因を切り分けられるように残す。
    """
    if not text or len(text) < 6:
        return ""
    counts = {'hira': 0, 'kata': 0, 'kanji': 0, 'ascii': 0, 'punct': 0, 'other': 0}
    hallucination_hits = 0
    for c in text:
        counts[_classify(c)] += 1
        if c in HALLUCINATION_KANJI:
            hallucination_hits += 1
    parts = []
    total = counts['hira'] + counts['kata'] + counts['kanji'] + counts['ascii']
    if total > 0:
        parts.append(f"漢字{int(counts['kanji']/total*100)}%")
        parts.append(f"ひら{int(counts['hira']/total*100)}%")
    if hallucination_hits:
        parts.append(f"幻覚漢字{hallucination_hits}個")
    return " / ".join(parts)
