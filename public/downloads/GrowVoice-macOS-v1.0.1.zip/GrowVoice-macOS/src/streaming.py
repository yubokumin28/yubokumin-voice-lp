# -*- coding: utf-8 -*-
"""streaming.py - 擬似ストリーミング認識 (Step2)

faster-whisper は本来ストリーミング非対応。そこで「録音中に裏で先行認識」する。

考え方(HANDOFF 5章「待ち時間を喋っている時間の裏に隠す」):
  - 録音中、別スレッドが一定間隔で「ここまでの音声」を認識する。
  - ただし喋っている最中の末尾は途中で言葉が変わり得るので、末尾の数秒
    (safety_tail)は確定させず保留する。それより前のセグメントだけを確定する。
  - 確定したテキスト片は on_text コールバックで即座に渡す。常駐本体はそれを
    整形してカーソルに挿入するので、喋っている裏で文字が出続ける(Aqua方式)。
  - 喋り終わったら、未確定の末尾だけを認識して on_text で渡す。
  - 結果、喋り終わってから走る認識は「末尾の数秒分」だけになり待ち時間が縮む。

このファイルは2層に分かれている:
  - StreamingTranscriber : 確定ロジックの本体(音声配列とセグメントだけで動く。
                           GPU・マイク不要なので自動テストできる)
  - StreamingSession     : マイク録音 + ワーカースレッドの土台(実機専用)
"""

import threading

import numpy as np

SAMPLE_RATE = 16000


class StreamingTranscriber:
    """確定ロジックの本体。録音中は process_chunk、解放後は finalize を呼ぶ。

    process_chunk / finalize はどちらも「今回新たに確定したテキスト片」を返す。
    返り値を順につなぐと全文になる。confirmed_text には全文が積まれていく。
    """

    def __init__(
        self,
        transcriber,
        sample_rate=SAMPLE_RATE,
        chunk_interval=1.0,
        safety_tail_sec=0.6,
        min_new_sec=1.5,
    ):
        self.transcriber = transcriber
        self.sample_rate = sample_rate
        self.chunk_interval = chunk_interval  # 何秒ごとに裏で先行認識するか
        self.safety_tail_sec = safety_tail_sec  # 末尾の保留時間(確定させない長さ)
        self.min_new_sec = min_new_sec  # 未確定分がこれ未満なら先行認識をスキップ
        self.confirmed_text = ""
        self.confirmed_samples = 0  # 先頭から何サンプルまで確定済みか

    def reset(self):
        """次の録音に備えて確定状態を初期化する。"""
        self.confirmed_text = ""
        self.confirmed_samples = 0

    def process_chunk(self, full_audio):
        """録音中に呼ぶ。確定できたテキスト片を返す(無ければ空文字)。

        full_audio は録音開始からの全音声(16kHz float32)。
        末尾 safety_tail_sec より前のセグメント/単語を確定する。

        確定戦略:
          1. セグメントの end が cutoff より前 -> そのセグメント全体を確定
          2. cutoff にまたがるセグメントは、 単語タイムスタンプがあれば
             cutoff より前で終わる単語までを確定(句点なしの長文対策)
          3. 単語タイムスタンプが無ければ、 そのセグメントは確定しない
             (旧バージョンの faster-whisper 互換)
        """
        portion = full_audio[self.confirmed_samples:]
        dur = len(portion) / self.sample_rate
        if dur < self.min_new_sec:
            return ""  # 未確定分がまだ短い。確定できるものが無い
        # 単語単位の確定を可能にするため word_timestamps を要求する。
        # transcribe_raw が word_timestamps を受け取らない旧シグネチャでも
        # 動くようにフォールバックする。
        try:
            segments = self.transcriber.transcribe_raw(
                portion, word_timestamps=True
            )
        except TypeError:
            segments = self.transcriber.transcribe_raw(portion)
        cutoff = dur - self.safety_tail_sec  # この時刻より前で終わるものだけ確定
        delta_parts = []
        advance_sec = 0.0
        for seg in segments:
            if seg.end <= cutoff:
                # セグメント全体が安全域 -> 丸ごと確定
                delta_parts.append(seg.text)
                advance_sec = seg.end
                continue
            # 安全域にまたがるセグメント。 単語単位で詰められるなら詰める
            words = getattr(seg, "words", None)
            if words:
                kept_words = []
                last_word_end = advance_sec
                for w in words:
                    if w.end <= cutoff:
                        kept_words.append(w.word)
                        last_word_end = w.end
                    else:
                        break
                if kept_words:
                    delta_parts.append("".join(kept_words))
                    advance_sec = last_word_end
            # cutoff を跨いだ時点で以降のセグメントも cutoff より後 -> 打ち切り
            break
        if not delta_parts:
            return ""
        delta = "".join(delta_parts)
        self.confirmed_text += delta
        self.confirmed_samples += int(advance_sec * self.sample_rate)
        return delta

    def finalize(self, full_audio):
        """解放後に呼ぶ。未確定の末尾を認識し、その末尾テキスト片を返す。"""
        portion = full_audio[self.confirmed_samples:]
        if len(portion) > 0:
            segments = self.transcriber.transcribe_raw(portion)
            tail = "".join(s.text for s in segments)
        else:
            tail = ""
        self.confirmed_text += tail
        self.confirmed_samples = len(full_audio)
        return tail


class StreamingSession:
    """マイク録音とワーカースレッドを束ねる。start() で録音開始、stop() で全文を返す。

    on_text(テキスト片) を渡すと、確定したテキスト片を喋っている裏で順次通知する。
    常駐本体はそれを整形して即挿入する(Aqua方式の「喋りながら順次挿入」)。

    settings の "streaming" が false の時は先行認識をせず、従来通り
    解放後に一括認識する(既存の動きを壊さないための切替)。
    """

    def __init__(self, transcriber, settings, on_text=None):
        self.sample_rate = SAMPLE_RATE
        # 擬似ストリーミングは既定 OFF。短い発話では「録音中の先行認識」と
        # 「解放後の末尾認識」の境界で語頭が二重確定し(例: 心心配/急急/ブブ)、
        # 文頭付近のどもりや崩れの原因になる。短発話中心の用途では一括認識の
        # 方が安定するため既定を False にする(settings.json で true に変更可)。
        self.enabled = settings.get("streaming", False)
        self.on_text = on_text
        self.streamer = StreamingTranscriber(
            transcriber,
            sample_rate=self.sample_rate,
            chunk_interval=float(settings.get("stream_chunk_sec", 1.0)),
            safety_tail_sec=float(settings.get("stream_safety_tail_sec", 0.6)),
        )
        self._frames = []
        self._stream = None
        self._worker = None
        self._stop_flag = threading.Event()
        # --- 常時マイク + プリロール(文頭の取りこぼし対策) -------------
        # 従来はキー押下のたびに InputStream を開いていたが、デバイスが開く
        # までの 100〜300ms の音声(=話し始め)が失われ、文頭の誤認識が
        # 多発していた。マイクを開きっぱなしにし、待機中は直近 preroll_sec
        # だけをリングバッファに保持。録音開始はフラグ操作だけになるので
        # 開始遅延ゼロ + 押す直前の音もプリロールとして含められる。
        # settings.json の mic_always_on:false で従来方式に戻せる。
        self.preroll_sec = float(settings.get("preroll_sec", 0.25))
        self._persistent_wanted = bool(settings.get("mic_always_on", True))
        self._pstream = None       # 常時オープンの InputStream
        self._recording = False    # True の間だけ _frames に蓄積
        self._ring = []            # 待機中の直近音声(プリロール用)
        self._ring_samples = 0
        # 直近の stop() 呼び出しの内訳秒数。原因切り分け用に hotkey_app.py が読む。
        # キー: "teardown" (録音停止+ワーカー合流) / "transcribe" (本体の認識)
        self.last_metrics = {"teardown": 0.0, "transcribe": 0.0}

    def open_mic(self):
        """マイクを常時オープンにする(起動時に1回呼ぶ)。

        成功すると以降の録音開始/停止はフラグ操作だけになり、
        PortAudio のストリーム開閉が押下時に発生しない。
        失敗時は False を返し、従来の「押下時に開く」方式で動き続ける。
        """
        if not self._persistent_wanted or self._pstream is not None:
            return self._pstream is not None
        try:
            import sounddevice as sd

            self._pstream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype="float32",
                callback=self._callback,
            )
            self._pstream.start()
            return True
        except Exception as e:
            print(f" 【情報】常時マイクを開けないため従来方式で動きます: {e}")
            self._pstream = None
            return False

    def close_mic(self):
        """常時マイクを閉じる(終了時用。失敗しても無視)。"""
        if self._pstream is not None:
            try:
                self._pstream.stop()
                self._pstream.close()
            except Exception:
                pass
            self._pstream = None

    def start(self):
        """録音を開始する。streaming 有効時は裏で先行認識スレッドも動かす。"""
        self.streamer.reset()
        self._stop_flag.clear()
        if self._pstream is not None:
            # 常時マイク: 押す直前 preroll_sec の音声を先頭に含めて録音開始。
            # ストリームの開閉なし(フラグだけ)なので開始遅延ゼロ。
            self._frames = self._ring[:]
            self._recording = True
        else:
            # フォールバック: 従来どおり押下時にストリームを開く
            import sounddevice as sd

            self._frames = []
            self._stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype="float32",
                callback=self._callback,
            )
            self._stream.start()
        if self.enabled:
            self._worker = threading.Thread(target=self._loop, daemon=True)
            self._worker.start()

    def _callback(self, indata, frames, time_info, status):
        if self._recording or self._pstream is None:
            self._frames.append(indata.copy())
            return
        # 待機中(常時マイク): 直近 preroll_sec だけ保持し、古い分は捨てる。
        # どこにも保存しない使い捨てバッファ(プライバシー面でも溜めない)。
        self._ring.append(indata.copy())
        self._ring_samples += len(indata)
        limit = int(self.preroll_sec * self.sample_rate)
        while self._ring and self._ring_samples - len(self._ring[0]) >= limit:
            self._ring_samples -= len(self._ring[0])
            self._ring.pop(0)

    def _snapshot(self):
        """現時点までの全音声を1次元配列で取り出す(録音中でも安全に呼べる)。"""
        frames = self._frames[:]  # リストのスナップショット(list の append はGILで安全)
        if not frames:
            return np.zeros(0, dtype="float32")
        return np.concatenate(frames, axis=0).flatten().astype("float32")

    def _loop(self):
        """ワーカースレッド。一定間隔で先行認識し、確定分を on_text で通知する。"""
        while not self._stop_flag.is_set():
            if self._stop_flag.wait(self.streamer.chunk_interval):
                break  # 解放された。途中の余計な認識はせず抜ける
            try:
                delta = self.streamer.process_chunk(self._snapshot())
                if delta and self.on_text:
                    self.on_text(delta)
            except Exception as e:
                # 先行認識は「おまけ」。失敗しても finalize が全部を拾うので止めない
                print(f" 【警告】裏での先行認識に失敗(無視して継続): {e}")

    def _teardown(self):
        """録音を止める(認識・挿入はしない共通処理)。

        常時マイク使用時はフラグを下ろすだけ(マイク自体は開いたまま)。
        リングバッファも空にして、今回の録音音声が次回のプリロールに
        混ざらないようにする。
        """
        self._recording = False
        self._ring = []
        self._ring_samples = 0
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            finally:
                self._stream = None
        # ワーカーを止める。モデルの同時使用を避けるため必ず合流する
        self._stop_flag.set()
        if self._worker is not None:
            self._worker.join()
            self._worker = None

    def cancel(self):
        """録音を破棄して停止する。認識も挿入もしない。

        最低押し込み時間に満たない短い押下(Ctrl+C 等のショートカット操作)で
        誤って録音が走った時に、何も出力せず後始末だけする用途。
        """
        self._teardown()

    def stop(self):
        """録音を停止し、認識済みの全文テキストを返す。音が短すぎる時は空文字。

        未挿入の末尾テキスト片は、この中で on_text により通知する。
        所要時間の内訳は self.last_metrics に "teardown" と "transcribe" で
        書き出す(原因切り分け用)。
        """
        import time as _time

        t0 = _time.perf_counter()
        self._teardown()
        t1 = _time.perf_counter()
        audio = self._snapshot()
        if audio.size < 1600:  # 0.1秒未満の誤爆は無視
            self.last_metrics = {"teardown": t1 - t0, "transcribe": 0.0}
            return ""
        if self.enabled:
            tail = self.streamer.finalize(audio)
            if tail and self.on_text:
                self.on_text(tail)
            t2 = _time.perf_counter()
            self.last_metrics = {"teardown": t1 - t0, "transcribe": t2 - t1}
            return self.streamer.confirmed_text.strip()
        # streaming 無効: 従来通り、解放後に全体を一括認識する
        segments = self.streamer.transcriber.transcribe_raw(audio)
        whole = "".join(s.text for s in segments).strip()
        if whole and self.on_text:
            self.on_text(whole)
        t2 = _time.perf_counter()
        self.last_metrics = {"teardown": t1 - t0, "transcribe": t2 - t1}
        return whole
