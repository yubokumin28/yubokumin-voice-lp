# -*- coding: utf-8 -*-
"""dict_editor.py - 誤変換の辞書追加ウィンドウ (Ctrl+Alt+D)

「間違って出た言葉」「本当はこう」の2欄を入力して保存すると、
config/replacements.json に追記される。次の音声入力から反映される。
保存前に .bak を自動作成する。
"""

import json
import shutil
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

ROOT = Path(__file__).resolve().parent.parent
REPL = ROOT / "config" / "replacements.json"


def load_rules():
    try:
        data = json.loads(REPL.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_rules(rules):
    if REPL.exists():
        shutil.copy(REPL, REPL.with_name("replacements.json.bak"))
    REPL.write_text(
        json.dumps(rules, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main():
    root = tk.Tk()
    root.title("誤変換を辞書に登録")
    root.geometry("440x230")
    root.resizable(False, False)

    tk.Label(root, text="誤変換された言葉を、正しい表記に登録します。",
             pady=8).pack()

    tk.Label(root, text="間違って出た言葉").pack(anchor="w", padx=24)
    e_wrong = tk.Entry(root, width=46)
    e_wrong.pack(padx=24, pady=(0, 8))

    tk.Label(root, text="本当はこう(正しい表記)").pack(anchor="w", padx=24)
    e_right = tk.Entry(root, width=46)
    e_right.pack(padx=24, pady=(0, 8))

    def on_save():
        wrong = e_wrong.get().strip()
        right = e_right.get().strip()
        if not wrong or not right:
            messagebox.showwarning("未入力", "両方の欄を入力してください。")
            return
        rules = load_rules()
        rules.append({"wrong": wrong, "right": right})
        try:
            save_rules(rules)
        except Exception as e:
            messagebox.showerror("保存失敗", f"辞書の保存に失敗しました:\n{e}")
            return
        messagebox.showinfo(
            "登録しました",
            f"「{wrong}」 → 「{right}」 を登録しました。\n"
            f"次の音声入力から自動で反映されます。",
        )
        root.destroy()

    tk.Button(root, text="登録する", width=16, command=on_save).pack(pady=12)
    e_wrong.focus()
    root.bind("<Return>", lambda _e: on_save())
    root.mainloop()


if __name__ == "__main__":
    main()
