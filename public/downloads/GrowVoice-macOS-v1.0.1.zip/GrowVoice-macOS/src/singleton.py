# -*- coding: utf-8 -*-
"""singleton.py - 二重起動防止 (Round5 / Mac対応)

音声入力ツールが同時に2つ起動すると、ホットキーの取り合いや
プロセスの溜まり込み(Aqua Voice で起きたゾンビプロセス問題と同種)が
発生する。OS ごとの単一インスタンス制御を 1 ヶ所に集約した
`platform_compat.SingleInstance` を再エクスポートするだけの薄い層。

OS ごとの実装:
  - Windows: 名前付きミューテックス(CreateMutexW)。
              プロセス終了時に Windows が自動で解放するので、
              強制終了しても次回の起動を妨げない。
  - macOS  : ~/Library/Caches/voice_input_tool.lock を fcntl.flock で排他ロック。

呼び出し側の使い方は変わらない:
    from singleton import SingleInstance
    s = SingleInstance()
    if s.already_running: ...
    s.release()
"""

from platform_compat import SingleInstance  # noqa: F401

__all__ = ["SingleInstance"]
