#!/bin/bash
# 音声入力ツール 初回セットアップ (macOS)
# - venv 作成
# - 依存パッケージ install
# - 他の .command すべてに実行権限付与
# - Ollama 導入確認 + 最適モデルの自動 pull (tools/ensure_ollama.py)
# - 詳細マニュアルは ../manual.html を参照

set -u
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

echo "============================================================"
echo "  音声入力ツール 初回セットアップ (macOS)"
echo "============================================================"
echo
echo "場所: $APP_ROOT"
echo

# --- 1. Python 確認 ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ python3 が見つかりません。"
  echo "   Homebrew で 'brew install python' か、https://www.python.org/downloads/macos/ からインストールしてください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi
PY_VER="$(python3 -c 'import sys;print(".".join(map(str,sys.version_info[:2])))')"
echo "✅ python3 が見つかりました (${PY_VER})"
echo

# --- 2. venv 作成 ---
if [ ! -x "$APP_ROOT/.venv/bin/python" ]; then
  echo "専用 .venv を作成しています..."
  python3 -m venv "$APP_ROOT/.venv"
fi
PY="$APP_ROOT/.venv/bin/python"
echo "✅ venv: $PY"
echo

# --- 3. pip install ---
echo "依存パッケージをインストールしています (初回は数分かかります)..."
"$PY" -m pip install --upgrade pip
"$PY" -m pip install -r "$APP_ROOT/requirements.txt"
echo

# --- 4. _mac/*.command に実行権限を付与 ---
echo "_mac/ 内の .command に実行権限を付与しています..."
chmod +x "$APP_ROOT/_mac/"*.command 2>/dev/null || true
echo

# --- 5. Ollama 導入 + 最適モデル取得 ---
echo "Ollama の導入状況を確認しています..."
# 失敗してもセットアップ自体は通す (Ollama は任意機能)
"$PY" "$APP_ROOT/tools/ensure_ollama.py" || true
echo

# --- 6. マイクとアクセシビリティの権限案内 ---
echo "============================================================"
echo "  ⚠ 初回起動時に macOS から権限ダイアログが出ます"
echo "============================================================"
echo "  ・マイク: 「許可」を押してください"
echo "  ・アクセシビリティ: System Settings > プライバシーとセキュリティ"
echo "    > アクセシビリティ で 'Terminal' (または起動した Python) を追加してください"
echo "  詳細は manual.html の「困ったとき」を参照。"
echo
echo "============================================================"
echo "  ✅ セットアップが完了しました"
echo "============================================================"
echo "  次は '_mac/音声入力を起動.command' をダブルクリックしてください。"
echo
read -r -p "Enter キーで終了 " _
