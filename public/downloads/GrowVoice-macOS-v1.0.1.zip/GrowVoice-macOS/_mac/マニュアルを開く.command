#!/bin/bash
# manual.html を既定ブラウザで開く (macOS)
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

MAN="$APP_ROOT/manual.html"
if [ ! -f "$MAN" ]; then
  echo "⚠ manual.html がまだありません (Step 7 で作成予定)。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi

open "$MAN"
