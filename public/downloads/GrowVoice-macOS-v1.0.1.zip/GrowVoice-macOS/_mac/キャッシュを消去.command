#!/bin/bash
# 入力履歴と遅延ログを削除 (macOS)
# Win 版「キャッシュを消去.bat」と同等。logs/history_*.txt と logs/latency.csv が対象。
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"
LOG_DIR="$APP_ROOT/logs"

count=0
total=0
if [ -d "$LOG_DIR" ]; then
  for f in "$LOG_DIR"/history_*.txt; do
    [ -e "$f" ] || continue
    sz=$(stat -f%z "$f" 2>/dev/null || echo 0)
    total=$((total + sz))
    rm -f "$f"
    count=$((count + 1))
  done
  [ -e "$LOG_DIR/latency.csv" ] && rm -f "$LOG_DIR/latency.csv"
fi

echo "✅ 履歴ファイル ${count} 件・約 $((total/1024)) KB を削除しました。"
echo
echo "(この後、ツールを再起動するとさらにスッキリします)"
echo
read -r -p "Enter キーで終了 " _
