#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_release.py  —  Grow Voice 配布ZIPのワンコマンド作成 + 版番号一括反映

使い方(プロジェクト直下から):
    python tools/build_release.py 1.0.1
    python tools/build_release.py            # VERSION の現在値で作り直し

これ1本がやること:
  1. 指定バージョンを VERSION / LP /download / manual.html に反映
  2. git archive HEAD でクリーン書き出し(コミット済みファイルのみ)
     → 学習辞書・logs・個人 settings は未コミット/gitignore なので絶対に入らない
  3. OS別に剪定して配布ツリーを生成
       Windows: _mac/ を除外、settings.json は HEAD のまま(device=cuda)
       Mac:     ルートの *.bat / *.vbs を除外、settings.json を device=cpu / int8 に変換
  4. Python zipfile で「/」区切りZIPを生成(PowerShell Compress-Archive は Mac で壊れるので不使用)
  5. LP の public/downloads に GrowVoice-Windows-vX.zip / GrowVoice-macOS-vX.zip を設置

注意: Compress-Archive は使わない。zipfile のみ。
"""
from __future__ import annotations
import argparse
import io
import json
import re
import shutil
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent          # voice-input-tool リポジトリ直下
DEFAULT_LP = ROOT.parent / "260621_voice-product"      # 製品LP(公開リポジトリ)

WIN_NAME = "GrowVoice-Windows"
MAC_NAME = "GrowVoice-macOS"

# 配布物に入れない開発・テスト用の資産(Windows/Mac 共通で剪定)
DEV_EXCLUDE_DIRS = {".claude", ".github", "_progress", "benchmark", "tests"}
DEV_EXCLUDE_FILES = {
    ".gitignore", "CLAUDE.md",
    "AIセットアップ指示.md", "開発メモ(旧・参考).md",
}


def prune_dev(dest: Path) -> None:
    """開発・テスト用ファイルを配布ツリーから除去(エンドユーザーに不要)。"""
    for name in DEV_EXCLUDE_DIRS:
        d = dest / name
        if d.exists():
            shutil.rmtree(d)
    for name in DEV_EXCLUDE_FILES:
        f = dest / name
        if f.exists():
            f.unlink()
    # バックアップファイルはどこにあっても除去
    for bak in dest.rglob("*.bak"):
        bak.unlink()


# ---- Windows 配布フォルダの整理 -------------------------------------------
# エンドユーザーに見せるのは「マニュアル + 2 つの bat」だけ。
# プログラム本体は _app/ にまとめて隠し、迷わないようにする。

WIN_MANUAL_NAME = "① はじめに(マニュアル).html"
WIN_LAUNCH_NAME = "② 音声入力を起動.bat"
WIN_SETTINGS_NAME = "③ 設定を開く.bat"

# _app に入れたあと削除する旧スクリプト・重複ドキュメント
WIN_DROP_IN_APP = {
    "アップデート.bat", "キャッシュを消去.bat", "セットアップ.bat",
    "マイク確認.bat", "マニュアルを開く.bat", "履歴を見る.bat",
    "管理者で自動起動を設定.bat", "音声入力を起動.bat", "設定を開く.bat",
    "start_voiceinput.vbs", "README.md", "手順書.md", "manual.html",
}

# 初回だけ自動準備して常駐起動(2 回目以降は窓なし)。cp932 で出力する。
WIN_LAUNCH_BAT = (
    "@echo off\r\n"
    "chcp 932 >nul\r\n"
    "setlocal\r\n"
    'cd /d "%~dp0_app"\r\n'
    "set PYTHONUTF8=1\r\n"
    "\r\n"
    'if exist ".venv\\Scripts\\pythonw.exe" goto launch\r\n'
    "\r\n"
    "echo ============================================================\r\n"
    "echo   音声入力ツール  初回の準備をしています\r\n"
    "echo   (数分かかります。終わるまでこの窓を閉じないでください)\r\n"
    "echo ============================================================\r\n"
    "echo.\r\n"
    "where python >nul 2>nul\r\n"
    "if errorlevel 1 (\r\n"
    "  echo [エラー] Python が見つかりません。\r\n"
    "  echo マニュアルの「(1) Python を入れる」を先に済ませてください。\r\n"
    "  echo.\r\n"
    "  pause\r\n"
    "  exit /b 1\r\n"
    ")\r\n"
    'python -m venv ".venv"\r\n'
    '".venv\\Scripts\\python.exe" -m pip install --upgrade pip\r\n'
    '".venv\\Scripts\\python.exe" -m pip install -r requirements.txt\r\n'
    '".venv\\Scripts\\python.exe" src\\check_gpu.py\r\n'
    "echo.\r\n"
    "echo 準備が完了しました。音声入力を起動します。\r\n"
    "timeout /t 2 >nul\r\n"
    "\r\n"
    ":launch\r\n"
    'start "" ".venv\\Scripts\\pythonw.exe" src\\hotkey_app.py\r\n'
)

WIN_SETTINGS_BAT = (
    "@echo off\r\n"
    "chcp 932 >nul\r\n"
    "setlocal\r\n"
    'cd /d "%~dp0_app"\r\n'
    "set PYTHONUTF8=1\r\n"
    'if not exist ".venv\\Scripts\\pythonw.exe" (\r\n'
    "  echo まだ準備ができていません。\r\n"
    "  echo 先に「② 音声入力を起動.bat」を一度ダブルクリックしてください。\r\n"
    "  echo.\r\n"
    "  pause\r\n"
    "  exit /b 1\r\n"
    ")\r\n"
    'start "" ".venv\\Scripts\\pythonw.exe" src\\settings_ui.py\r\n'
)


def shape_windows_dist(dest: Path) -> None:
    """Windows 配布ツリーを「マニュアル + bat2 本 + _app/」に再構成する。"""
    app = dest / "_app"
    app.mkdir(exist_ok=True)
    # ルート直下のもの(_app 以外)を全部 _app へ退避
    for child in list(dest.iterdir()):
        if child == app:
            continue
        shutil.move(str(child), str(app / child.name))

    # マニュアルだけ取り出して、先頭に来る分かりやすい名前でルートへ
    src_manual = app / "manual.html"
    if src_manual.exists():
        shutil.copy2(src_manual, dest / WIN_MANUAL_NAME)

    # 旧スクリプト・重複ドキュメントは _app から除去(本体だけ残す)
    for name in WIN_DROP_IN_APP:
        f = app / name
        if f.exists():
            f.unlink()

    # 残すのは「設定を開く」と「窓なし起動(初回は自動準備)」の 2 本だけ
    (dest / WIN_LAUNCH_NAME).write_text(WIN_LAUNCH_BAT, encoding="cp932")
    (dest / WIN_SETTINGS_NAME).write_text(WIN_SETTINGS_BAT, encoding="cp932")


def run_git_archive(staging: Path) -> None:
    """git archive HEAD の中身を staging に展開(追跡ファイルのみ=個人データ混入なし)。"""
    proc = subprocess.run(
        ["git", "archive", "HEAD"],
        cwd=str(ROOT), stdout=subprocess.PIPE, check=True,
    )
    with tarfile.open(fileobj=io.BytesIO(proc.stdout)) as tar:
        tar.extractall(str(staging))


def read_current_version() -> str:
    return (ROOT / "VERSION").read_text(encoding="utf-8").strip()


def bump_version(new_ver: str, old_ver: str, lp: Path) -> list[str]:
    """VERSION / LP /download / manual.html の版表記を new_ver に置換。変更点リストを返す。"""
    changes: list[str] = []

    vfile = ROOT / "VERSION"
    if vfile.read_text(encoding="utf-8").strip() != new_ver:
        vfile.write_text(new_ver + "\n", encoding="utf-8")
        changes.append(f"VERSION → {new_ver}")

    targets = [
        lp / "app" / "download" / "page.tsx",
        ROOT / "manual.html",
    ]
    for f in targets:
        if not f.exists():
            continue
        text = f.read_text(encoding="utf-8")
        updated = text
        # ファイル名 GrowVoice-*-vX.Y.Z.zip
        updated = updated.replace(f"-v{old_ver}.zip", f"-v{new_ver}.zip")
        # 見出しの「v1.0.0」表記(・ v1.0.0 / vX.Y.Z 単独)
        updated = re.sub(rf"\bv{re.escape(old_ver)}\b", f"v{new_ver}", updated)
        if updated != text:
            f.write_text(updated, encoding="utf-8")
            changes.append(f"{f.name} の版表記を {old_ver} → {new_ver}")
    return changes


def make_tree(staging: Path, work: Path, top: str, is_mac: bool) -> Path:
    """staging から OS別ツリーを work/top に生成して返す。"""
    dest = work / top
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(staging, dest)

    prune_dev(dest)

    if is_mac:
        # Windows 専用スクリプトを除外
        for p in list(dest.glob("*.bat")) + list(dest.glob("*.vbs")):
            p.unlink()
        # マニュアルの既定OS表示を Mac に(ソースは win 既定)
        mf = dest / "manual.html"
        if mf.exists():
            t = mf.read_text(encoding="utf-8")
            mf.write_text(t.replace('data-os="win"', 'data-os="mac"', 1),
                          encoding="utf-8")
        # settings.json を Mac 既定(cpu / int8)へ変換
        sf = dest / "config" / "settings.json"
        if sf.exists():
            s = json.loads(sf.read_text(encoding="utf-8"))
            s["device"] = "cpu"
            s["compute_type"] = "int8"
            sf.write_text(
                json.dumps(s, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
    else:
        # Windows 版は Mac 専用フォルダを除外
        mac_dir = dest / "_mac"
        if mac_dir.exists():
            shutil.rmtree(mac_dir)
        # マニュアル + bat2本 + _app/ の3点構成へ整理
        shape_windows_dist(dest)
    return dest


def zip_tree(tree: Path, top: str, out_zip: Path) -> int:
    """tree を「/」区切りで zip 化。エントリ数を返す。"""
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    if out_zip.exists():
        out_zip.unlink()
    count = 0
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(tree.rglob("*")):
            if path.is_file():
                arc = f"{top}/" + path.relative_to(tree).as_posix()
                zf.write(path, arc)
                count += 1
    return count


def main() -> int:
    ap = argparse.ArgumentParser(description="Grow Voice 配布ZIPビルダー")
    ap.add_argument("version", nargs="?", help="新バージョン(省略時は VERSION の現在値で作り直し)")
    ap.add_argument("--lp", default=str(DEFAULT_LP), help="製品LPのパス")
    args = ap.parse_args()

    lp = Path(args.lp)
    old_ver = read_current_version()
    new_ver = args.version or old_ver

    print("=" * 60)
    print(f"  Grow Voice 配布ビルド   {old_ver} -> {new_ver}")
    print("=" * 60)

    # 1) 版番号反映
    if new_ver != old_ver:
        for c in bump_version(new_ver, old_ver, lp):
            print(f"  [版] {c}")
    else:
        print("  [版] 据え置き(作り直しのみ)")

    work = ROOT / ".release_build"
    if work.exists():
        shutil.rmtree(work)
    staging = work / "_staging"
    staging.mkdir(parents=True)

    # 2) クリーン書き出し
    run_git_archive(staging)
    print("  [取] git archive HEAD で追跡ファイルのみ書き出し")

    downloads = lp / "public" / "downloads"
    results = []
    for top, is_mac in ((WIN_NAME, False), (MAC_NAME, True)):
        tree = make_tree(staging, work, top, is_mac)
        out_zip = downloads / f"{top}-v{new_ver}.zip"
        n = zip_tree(tree, top, out_zip)
        size_kb = out_zip.stat().st_size / 1024
        results.append((out_zip.name, n, size_kb))
        print(f"  [包] {out_zip.name}  ({n}ファイル / {size_kb:.0f}KB)")

    shutil.rmtree(work)

    print("-" * 60)
    print("  完了。次の手順:")
    print("   1) LP を確認 → 公開(git push origin main → Vercel 自動デプロイ)")
    print("   2) 実DLして解凍 → セットアップ → 起動 を確認")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
