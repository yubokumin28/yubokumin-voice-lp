# -*- coding: utf-8 -*-
"""pick_ollama_model.py - spec から最適な Ollama モデルを選び 1 行で返す。

入力:
  - detect_spec.py の JSON(STDIN から渡されるか、引数で与えるか、または
    本スクリプト内で detect_spec.detect() を直接呼ぶ)。

出力(STDOUT、1 行):
  {
    "model": "gemma2:9b",
    "approx_size_gb": 5.4,
    "reason": "Mac Apple Silicon・RAM 16GB 以上",
    "spec_summary": "darwin / arm64 / RAM 16GB / Apple M2"
  }

選定ルール(計画書のテーブルどおり):
  | マシン条件                                | 既定モデル   | 概算サイズ |
  |-------------------------------------------|------------|-----------|
  | Mac Apple Silicon・RAM 16GB+              | gemma2:9b  | 5.4 GB    |
  | Mac Apple Silicon・RAM 8〜16GB            | gemma2:2b  | 1.6 GB    |
  | Mac Intel・RAM 16GB+                      | gemma2:2b  | 1.6 GB    |
  | Mac Intel・RAM 8GB                        | phi3:mini  | 2.3 GB    |
  | Win + NVIDIA GPU (VRAM 8GB+, CUDA)        | gemma2:9b  | 5.4 GB    |
  | Win + NVIDIA GPU (VRAM 4〜8GB, CUDA)      | gemma2:2b  | 1.6 GB    |
  | Win CPU のみ・RAM 16GB+                    | gemma2:2b  | 1.6 GB    |
  | Win CPU のみ・RAM 8GB                      | phi3:mini  | 2.3 GB    |
  | それ以外(取得失敗時の安全側)             | phi3:mini  | 2.3 GB    |

設計方針:
  - 数値が欠落しても落ちずに「安全側に小さいモデル」へ倒す。
  - 旦那様(Win + RTX 5060 Ti 16GB)で実行したときは gemma2:9b を選ぶこと。
"""

import json
import sys
from pathlib import Path

# 同一フォルダの detect_spec.py を直接 import できるようにする
sys.path.insert(0, str(Path(__file__).resolve().parent))


# 概算サイズは ollama のレジストリ公開値(2026 年現在)。
# テザリングのユーザーに DL 量を事前提示するために添える。
MODEL_SIZES_GB = {
    "gemma2:9b": 5.4,
    "gemma2:2b": 1.6,
    "phi3:mini": 2.3,
}


def pick(spec: dict) -> dict:
    os_ = (spec or {}).get("os") or ""
    arch = (spec or {}).get("arch") or ""
    ram = (spec or {}).get("ram_gb") or 0
    vram = (spec or {}).get("gpu_vram_gb") or 0
    cuda = bool((spec or {}).get("cuda_available"))
    apple_silicon = bool((spec or {}).get("apple_silicon")) or arch in ("arm64", "aarch64")

    if os_ == "darwin":
        if apple_silicon:
            if ram >= 16:
                model, reason = "gemma2:9b", "Mac Apple Silicon・RAM 16GB 以上"
            elif ram >= 8:
                model, reason = "gemma2:2b", "Mac Apple Silicon・RAM 8〜16GB"
            else:
                model, reason = "phi3:mini", "Mac Apple Silicon・RAM 8GB 未満(最軽量へ)"
        else:
            if ram >= 16:
                model, reason = "gemma2:2b", "Mac Intel・RAM 16GB 以上"
            else:
                model, reason = "phi3:mini", "Mac Intel・RAM 8GB"
    elif os_ == "windows":
        if cuda and vram >= 8:
            model, reason = "gemma2:9b", "Win + NVIDIA GPU (VRAM 8GB 以上)"
        elif cuda and vram >= 4:
            model, reason = "gemma2:2b", "Win + NVIDIA GPU (VRAM 4〜8GB)"
        elif ram >= 16:
            model, reason = "gemma2:2b", "Win CPU のみ・RAM 16GB 以上"
        else:
            model, reason = "phi3:mini", "Win CPU のみ・RAM 8GB"
    else:
        model, reason = "phi3:mini", "OS 不明のため安全側で最軽量を選択"

    cpu = (spec or {}).get("cpu") or "?"
    spec_summary = f"{os_ or '?'} / {arch or '?'} / RAM {ram}GB / {cpu}"
    if vram:
        spec_summary += f" / VRAM {vram}GB"
    if cuda:
        spec_summary += " / CUDA"

    return {
        "model": model,
        "approx_size_gb": MODEL_SIZES_GB.get(model, 2.0),
        "reason": reason,
        "spec_summary": spec_summary,
    }


def _load_spec() -> dict:
    # 引数で JSON ファイルパスが与えられたらそれを読む
    if len(sys.argv) >= 2:
        p = Path(sys.argv[1])
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    # STDIN にデータがあれば読む
    if not sys.stdin.isatty():
        try:
            txt = sys.stdin.read().strip()
            if txt:
                return json.loads(txt)
        except Exception:
            pass
    # フォールバック: 同梱の detect_spec を直接呼ぶ
    import detect_spec  # type: ignore
    return detect_spec.detect()


def main():
    spec = _load_spec()
    result = pick(spec)
    json.dump(result, sys.stdout, ensure_ascii=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
