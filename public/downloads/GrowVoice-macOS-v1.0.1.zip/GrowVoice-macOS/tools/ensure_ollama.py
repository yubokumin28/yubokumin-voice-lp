# -*- coding: utf-8 -*-
"""ensure_ollama.py - Ollama の導入確認 + 起動確認 + モデル取得を 1 本でやる。

役割:
  1. ollama コマンドが PATH にあるか確認(未導入なら DL ページを案内・ブラウザ自動オープン)
  2. http://localhost:11434/api/tags への接続で「Ollama 本体が起動中か」確認
  3. 最適モデル(pick_ollama_model.py の出力)が未取得なら `ollama pull` を実行
     その前に「これから ○○ GB を取得します。続けますか?」を確認
     (テザリングのユーザーの通信量うっかり消費を防止)
  4. config/settings.json の ollama_model を最適モデルで更新(他キー保護)

両 OS:
  - Mac: 公式 DL = https://ollama.com/download/mac、`open <url>` でブラウザ起動
  - Win: 公式 DL = https://ollama.com/download/windows、`start <url>` 相当を webbrowser で
  - Linux も一応 https://ollama.com/download/linux に倒すが、第一弾配布対象外

CLI:
  python tools/ensure_ollama.py                # 対話あり(既定)
  python tools/ensure_ollama.py --yes          # 確認スキップ(自動化用)
  python tools/ensure_ollama.py --no-pull      # PATH 確認と接続確認だけ
  python tools/ensure_ollama.py --skip-config  # settings.json を書き換えない
"""

import json
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from urllib import error as urlerror
from urllib import request as urlrequest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))


DOWNLOAD_URLS = {
    "win32": "https://ollama.com/download/windows",
    "darwin": "https://ollama.com/download/mac",
    "linux": "https://ollama.com/download/linux",
}

# DL 量がこの GB を超えるときは必ず確認プロンプトを挟む。
# 旦那様のテザリング配慮で 0.5 GB に設定(計画書の「>500MB 級」と同期)。
DL_CONFIRM_THRESHOLD_GB = 0.5


def _print(msg: str):
    print(msg, flush=True)


def _has(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _open_download_page():
    url = DOWNLOAD_URLS.get(sys.platform, "https://ollama.com/download")
    _print(f"  Ollama がインストールされていません。下記からインストールしてください:")
    _print(f"    {url}")
    try:
        webbrowser.open(url)
        _print("  既定のブラウザでダウンロードページを開きました。")
    except Exception:
        pass


def _api_reachable(timeout=2.0) -> bool:
    try:
        with urlrequest.urlopen("http://localhost:11434/api/tags", timeout=timeout) as r:
            return r.status == 200
    except urlerror.URLError:
        return False
    except Exception:
        return False


def _wait_for_api(seconds: int = 6) -> bool:
    for _ in range(seconds):
        if _api_reachable(timeout=1.0):
            return True
        time.sleep(1)
    return False


def _list_installed_models() -> list:
    try:
        with urlrequest.urlopen("http://localhost:11434/api/tags", timeout=3.0) as r:
            data = json.loads(r.read().decode("utf-8"))
        return [m.get("name", "") for m in (data.get("models") or [])]
    except Exception:
        return []


def _confirm(prompt: str, assume_yes: bool) -> bool:
    if assume_yes:
        return True
    if not sys.stdin.isatty():
        # 対話できない場合は安全側 = No(うっかり巨大 DL を踏まない)
        _print(f"  {prompt} [非対話モードのため中止しました。--yes を付けると自動承認]")
        return False
    try:
        ans = input(f"  {prompt} [Enter で続行 / n で中止]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return ans in ("", "y", "yes")


def _pull(model: str) -> bool:
    _print(f"  ollama pull {model} を実行します(初回は数分〜十数分かかります)...")
    try:
        ret = subprocess.run(["ollama", "pull", model], check=False)
        ok = ret.returncode == 0
        if ok:
            _print(f"  -> モデル取得 OK: {model}")
        else:
            _print(f"  -> モデル取得に失敗しました(終了コード {ret.returncode})。")
        return ok
    except Exception as e:
        _print(f"  -> モデル取得中にエラー: {e}")
        return False


def _update_settings(model: str):
    p = ROOT / "config" / "settings.json"
    try:
        data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        data = {}
    data["ollama_model"] = model
    # その他キーは保護
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    _print(f"  config/settings.json の ollama_model を {model} に更新しました。")


def main():
    args = sys.argv[1:]
    assume_yes = "--yes" in args
    no_pull = "--no-pull" in args
    skip_config = "--skip-config" in args

    _print("== Ollama セットアップ確認 ==")

    # 1) ollama コマンド有無
    if not _has("ollama"):
        _open_download_page()
        _print("  インストール後、もう一度このスクリプトを実行してください。")
        sys.exit(2)
    _print("  ollama コマンドが見つかりました。")

    # 2) サーバ起動確認
    if not _api_reachable():
        _print("  http://localhost:11434 に接続できませんでした。Ollama 本体を起動してください:")
        if sys.platform == "darwin":
            _print("    → Launchpad で Ollama.app を起動(メニューバーにラマアイコンが出ます)")
        elif sys.platform == "win32":
            _print("    → スタートメニューから Ollama を起動(タスクトレイにラマアイコンが出ます)")
        else:
            _print("    → `ollama serve` を別ターミナルで起動")
        _print("  6 秒待機して再確認します...")
        if not _wait_for_api(6):
            _print("  まだ起動を確認できません。起動後にもう一度実行してください。")
            sys.exit(3)
    _print("  Ollama サーバに接続できました。")

    # 3) 最適モデルを選定
    try:
        import detect_spec  # type: ignore
        import pick_ollama_model  # type: ignore
        spec = detect_spec.detect()
        pick = pick_ollama_model.pick(spec)
    except Exception as e:
        _print(f"  spec 検出に失敗しました: {e}")
        sys.exit(4)

    model = pick["model"]
    size_gb = pick["approx_size_gb"]
    _print(f"  推奨モデル: {model}({pick['reason']} / 約 {size_gb} GB)")
    _print(f"    spec: {pick['spec_summary']}")

    if no_pull:
        _print("  --no-pull のためモデル取得はスキップします。")
        return

    # 4) 既存モデルチェック
    installed = _list_installed_models()
    already = any(name == model or name.startswith(model + ":") or name.startswith(model.split(":")[0] + ":") and name == model for name in installed)
    # 厳密に一致するタグだけを「あり」とする
    already = model in installed
    if already:
        _print(f"  {model} は既に取得済みです。")
    else:
        # 5) DL 確認(>= 閾値 のときだけ確認)
        if size_gb >= DL_CONFIRM_THRESHOLD_GB:
            ok = _confirm(
                f"これから {model}(約 {size_gb} GB)をダウンロードします。続行しますか?",
                assume_yes,
            )
            if not ok:
                _print("  ユーザーが中止しました。モデル取得はスキップします。")
                if not skip_config:
                    # 設定は更新せず、現状維持
                    pass
                sys.exit(5)
        if not _pull(model):
            sys.exit(6)

    # 6) settings.json 更新
    if not skip_config:
        _update_settings(model)

    _print("== 完了 ==")


if __name__ == "__main__":
    main()
