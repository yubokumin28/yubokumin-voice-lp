# -*- mode: python ; coding: utf-8 -*-
"""Grow Voice 単体exe ビルド定義(onedir / CPU 割り切り)。

過去の頓挫点:
  - faster-whisper / ctranslate2 / onnxruntime / av のネイティブ DLL が
    exe に入りきらず DLL load failed。
  -> onedir + collect_all で動的ライブラリを丸ごと同梱して回避する。
"""
import os
from PyInstaller.utils.hooks import collect_all, collect_submodules

# SPECPATH は PyInstaller がこの .spec のあるフォルダ(build_exe)を注入する
ROOT = os.path.dirname(SPECPATH)
SRC = os.path.join(ROOT, "src")

datas = []
binaries = []
hiddenimports = []

# ネイティブ DLL を持つ依存は丸ごと取り込む(DLL load failed 回避の本丸)
for pkg in ("faster_whisper", "ctranslate2", "onnxruntime", "av",
            "customtkinter", "pystray", "sounddevice"):
    d, b, h = collect_all(pkg)
    datas += d
    binaries += b
    hiddenimports += h

# src 配下の自作モジュール(遅延 import されるものを取りこぼさない)
src_modules = [
    "hotkey_app", "transcriber", "recorder", "inserter", "streaming",
    "overlay", "settings_ui", "proofread_cli", "tray", "singleton",
    "history", "learning", "feedback", "anomaly", "hotkey", "punctuate",
    "formatter", "mic_check",
]
hiddenimports += src_modules
hiddenimports += collect_submodules("platform_compat")

# 注: assets / config は _internal ではなく exe の隣(ROOT)に置く必要があるため
# ここでは同梱せず、ビルド後の package_release.py で exe の隣にコピーする。

a = Analysis(
    [os.path.join(ROOT, "build_exe", "grow_voice.py")],
    pathex=[SRC],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        # CPU 割り切り: GPU(CUDA)系を明示除外してサイズ爆発を防ぐ
        "torch", "nvidia", "triton",
    ],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="GrowVoice",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,  # 配布版は窓なし常駐(ログは logs/app.log に残る)。
    icon=os.path.join(ROOT, "assets", "voice_input.ico"),
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="GrowVoice",
)
