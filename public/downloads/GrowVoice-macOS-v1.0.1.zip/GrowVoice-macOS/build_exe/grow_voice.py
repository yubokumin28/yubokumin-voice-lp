# -*- coding: utf-8 -*-
"""grow_voice.py - 単体exe 用の入口(ディスパッチャ)。

1つの exe を引数で役割切り替えして起動する。
  (引数なし)          : 常駐本体(hotkey_app)
  --gv-mode overlay PID : 録音中ランプ
  --gv-mode settings    : 設定画面
  --gv-mode proofread … : 履歴の推敲
これにより pythonw.exe や *.py を同梱せず、exe 自身を子プロセスとして呼べる。
"""
import sys
from pathlib import Path


def _setup_path():
    # 開発実行時は ../src を import パスに足す。
    # frozen(exe)時は src モジュールがトップレベルに同梱されるので不要。
    if not getattr(sys, "frozen", False):
        src = Path(__file__).resolve().parent.parent / "src"
        sys.path.insert(0, str(src))


def main():
    _setup_path()
    argv = sys.argv[1:]
    mode = None
    if argv and argv[0] == "--gv-mode":
        mode = argv[1]
        # 後続モジュールが自分の argv を読めるよう詰め直す
        sys.argv = [sys.argv[0]] + argv[2:]

    if mode == "overlay":
        import overlay
        return overlay.main()
    if mode == "settings":
        import settings_ui
        return settings_ui.main()
    if mode == "proofread":
        import proofread_cli
        return proofread_cli.main(sys.argv[1:])

    import hotkey_app
    return hotkey_app.main()


if __name__ == "__main__":
    sys.exit(main())
