# -*- coding: utf-8 -*-
"""package_release.py - ビルド後の dist/GrowVoice/ に実行時データを配置する。

PyInstaller が作る dist/GrowVoice/ の中身(exe + _internal)に対し、
exe の隣へ assets/ と config/ をコピーする。アプリは ROOT(=exe のある
フォルダ)直下の config/ assets/ を読むため、ここに置くことで単体で動く。

config はビルド機(旦那様)の現行設定をそのまま同梱する。第三者配布時の
個人情報の除去は別手順(public_distribution)で行う前提。
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST_APP = ROOT / "build_exe" / "dist" / "GrowVoice"


def _copytree(src: Path, dst: Path):
    if not src.exists():
        print(f"  [skip] {src} が無い")
        return
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    print(f"  [copy] {src.name}/ -> {dst}")


def main():
    if not DIST_APP.exists():
        print(f"【エラー】先にビルドしてください: {DIST_APP} が無い")
        return 1
    print(f"配置先: {DIST_APP}")
    # アイコン・アバター類
    _copytree(ROOT / "assets", DIST_APP / "assets")
    # 設定・辞書(現行をそのまま)。logs は実行時に自動生成。
    _copytree(ROOT / "config", DIST_APP / "config")
    (DIST_APP / "logs").mkdir(exist_ok=True)
    print("完了。dist/GrowVoice/GrowVoice.exe をダブルクリックで起動できます。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
