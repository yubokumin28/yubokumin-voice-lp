# -*- coding: utf-8 -*-
"""learning_judge.py - 育つAI 第3段(学習候補のAI仕分け)

learning.py が集めた誤変換候補を Ollama に1件ずつ見せ、
「どの文に出ても機械的に置き換えてよい聞き間違いか」を判定させる。

  approve → 辞書へ登録(確定)
  reject  → 却下(二度と提示しない)
  hold    → 学習タブに残して旦那様が判断

既存の学習由来ルール(origin=learning)も同じ物差しで1回だけ点検し、
reject のものは削除せず無効化(enabled=False)する(辞書タブで戻せる)。

設計方針:
  - Ollama に届かない・答えが読めない時は何も変えない(安全側)。
  - 判定済みの候補・ルールには印を付け、同じものを二度聞かない。
  - settings.json の learning_ai_judge:false で全面無効化。
"""

import json
import re
import urllib.request

_PROMPT = """あなたは日本語の音声入力ツールの辞書係です。
音声認識の結果に出た「誤」を、推敲AIが「正」に直しました。
これを辞書に登録すると、今後どんな文の中に「誤」の文字列が出ても、文脈を見ずに必ず「正」へ置き換えます。

登録してよい(approve)のは、次の3つをすべて満たす時だけです。
1. 「誤」が、音の似た聞き間違い・漢字の変換ミス・英単語や固有名詞の表記ミスである
   (例: コンクルート→コンクリート、ギットハブ→GitHub、チャットジーピーテ→ChatGPT)
2. 「誤」の文字列が、正しい日本語や他の単語の一部としてはまず出てこない
3. 「正」は「誤」を正しく書き直しただけで、助詞や語尾を足したり、言い回しや意味を変えたりしていない

次のどれかに当たれば却下(reject)です。
- 言い回し・敬語・語尾・文体を変えただけ(例: 思います→考えます、1回→一度)
- 意味や内容が変わっている
- 「誤」が普通の日本語や他の単語の一部として正しく出てくる(例: している→の。「プロイ」は「デプロイ」の一部)
- 「正」に助詞(を・は・が等)が足されている
- 「正」そのものが誤字になっている

1か所でも迷う点があれば保留(hold)にしてください。

誤: 「{wrong}」
正: 「{right}」
実際に使われた文: {examples}

JSONだけで答えてください。
{{"verdict": "approve" か "reject" か "hold", "reason": "日本語で25字以内"}}"""

_VERDICTS = ("approve", "reject", "hold")


def _call_ollama_json(prompt, settings, timeout):
    """Ollama に JSON モードで1回問い合わせ、dict を返す。"""
    base = settings.get("ollama_url", "http://localhost:11434").rstrip("/")
    payload = {
        "model": settings.get("ollama_model", "gemma4:latest"),
        "prompt": prompt,
        "stream": False,
        "format": "json",
        "options": {"temperature": 0},
        "keep_alive": settings.get("ollama_keep_alive", "5m"),
    }
    req = urllib.request.Request(
        base + "/api/generate",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    text = (result.get("response") or "").strip()
    m = re.search(r"\{.*\}", text, re.S)
    return json.loads(m.group(0) if m else text)


def judge_pair(wrong, right, examples, settings, timeout=60.0):
    """1組を判定し (verdict, reason) を返す。読めない時は (None, 理由)。"""
    ex = " / ".join(examples[:3]) if examples else "(例文なし)"
    prompt = _PROMPT.format(wrong=wrong, right=right, examples=ex)
    try:
        data = _call_ollama_json(prompt, settings, timeout)
    except Exception as e:
        return None, f"Ollama失敗: {e}"
    verdict = str(data.get("verdict", "")).strip().lower()
    if verdict not in _VERDICTS:
        return None, f"判定が読めない: {data}"
    return verdict, str(data.get("reason", ""))[:60]


def _enabled(settings):
    return (settings.get("ollama_enabled", True)
            and settings.get("learning_ai_judge", True))


def judge_pending(candidates, settings, corpus="", limit=30):
    """未判定の pending 候補を仕分ける。返り値: {verdict: 件数}。

    approve の候補は status を pending のまま ai_verdict="approve" にしておき、
    実際の辞書登録は learning._auto_register が行う(書き込み失敗時の保護)。
    reject は status="rejected" にする。hold は印だけ付けて pending に残す。

    実測(2026-10-22・50件): reject は16件すべて正しかったが、approve は30件中4件が
    正しい語を壊す置き換えだった(例: プロイ→ポイ は「デプロイ」を壊す)。
    そこで approve でも、推敲後の文(corpus)に「誤」がそのまま残っている語は
    正しい用法がありうるとみなして hold に落とす。
    """
    counts = {}
    if not _enabled(settings):
        return counts
    done = 0
    for c in candidates:
        if c.get("status") != "pending" or c.get("ai_verdict"):
            continue
        if done >= limit:
            break
        verdict, reason = judge_pair(
            c.get("wrong", ""), c.get("right", ""),
            c.get("examples", []), settings)
        done += 1
        if verdict is None:
            break  # Ollama が不調なら今回は打ち切り(次回やり直す)
        if verdict == "approve" and corpus and c.get("wrong", "") in corpus:
            verdict, reason = "hold", "推敲後の文にも同じ語が出る"
        c["ai_verdict"] = verdict
        c["ai_reason"] = reason
        if verdict == "reject":
            c["status"] = "rejected"
            c["ai_rejected"] = True
        counts[verdict] = counts.get(verdict, 0) + 1
    return counts


def audit_learned_rules(rules, settings, limit=30):
    """辞書の学習由来ルールのうち未点検のものを点検する。

    reject → enabled=False(削除はしない)。返り値: (点検した件数, 無効化した件数)。
    rules はその場で書き換える(保存は呼び出し側)。
    """
    if not _enabled(settings):
        return 0, 0
    disabled = 0
    done = 0
    for rule in rules:
        if not (isinstance(rule, dict) and rule.get("origin") == "learning"):
            continue
        if rule.get("ai_checked"):
            continue
        if done >= limit:
            break
        verdict, reason = judge_pair(
            rule.get("wrong", ""), rule.get("right", ""), [], settings)
        done += 1
        if verdict is None:
            break
        rule["ai_checked"] = verdict
        rule["ai_reason"] = reason
        if verdict == "reject" and rule.get("enabled", True):
            rule["enabled"] = False
            rule["ai_disabled"] = True
            disabled += 1
    return done, disabled
