#!/bin/bash
# Grow Voice 設定画面 (macOS)
cd "$(dirname "$0")/_app" || exit 1
export PYTHONUTF8=1
if [ ! -f ".venv/.setup_done" ]; then
  echo "まだ準備ができていません。"
  echo "先に「② 音声入力を起動.command」を一度開いてください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi
nohup ".venv/bin/python" "src/settings_ui.py" >/dev/null 2>&1 &
disown $! 2>/dev/null || true
sleep 1
