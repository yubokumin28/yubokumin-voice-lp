# -*- coding: utf-8 -*-
"""updater.py - GitHub Releases の最新 ZIP を取得して差分上書きする自動アップデータ。

役割:
  - リポジトリ直下の VERSION ファイルと GitHub Releases の最新タグを比較
  - 新しければ release zipball を DL → 一時ディレクトリで展開 →
    退避してから shutil.copytree(dirs_exist_ok=True) で上書き
  - 設定・履歴・venv は触らない(保護リスト)
  - 失敗時はロールバック

保護対象(置換対象外):
  config/, logs/, .venv/, .git/, _backup/, *.bak, _progress/

更新リポジトリ URL は config/settings.json の `update_repo` キーから読む。
例: "update_repo": "https://github.com/<owner>/<repo>"

CLI:
  python tools/updater.py                 # 確認あり、最新ならアップデート実行
  python tools/updater.py --check         # 比較だけして 0/1 で返す
  python tools/updater.py --yes           # 確認スキップ
  python tools/updater.py --repo URL      # 設定を上書きして URL 指定

両 OS:
  - shutil/urllib/zipfile のみ使用、外部依存なし
  - Win/Mac いずれもファイルパス操作は pathlib で統一
"""

import argparse
import json
import os
import shutil
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from urllib import error as urlerror
from urllib import request as urlrequest

ROOT = Path(__file__).resolve().parent.parent

# 「アップデートで触らない」相対パス。先頭一致で比較する。
PROTECTED_DIRS = (
    "config",
    "logs",
    ".venv",
    ".git",
    "_backup",
    "_progress",
)
PROTECTED_SUFFIXES = (".bak",)


def _print(msg: str):
    print(msg, flush=True)


def _read_version() -> str:
    p = ROOT / "VERSION"
    if p.exists():
        v = p.read_text(encoding="utf-8").strip()
        if v:
            return v
    return "0.0.0"


def _read_repo_url() -> str:
    p = ROOT / "config" / "settings.json"
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return (data.get("update_repo") or "").strip()
    except Exception:
        return ""


def _parse_owner_repo(url: str) -> tuple:
    # https://github.com/<owner>/<repo>(末尾 .git や / は無視)
    if not url:
        return None, None
    s = url.rstrip("/")
    if s.endswith(".git"):
        s = s[:-4]
    parts = s.split("/")
    if len(parts) < 2:
        return None, None
    return parts[-2], parts[-1]


def _semver_tuple(s: str) -> tuple:
    s = (s or "").lstrip("v").strip()
    parts = []
    for chunk in s.split(".")[:3]:
        try:
            parts.append(int("".join(ch for ch in chunk if ch.isdigit()) or "0"))
        except Exception:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _fetch_latest_release(owner: str, repo: str) -> dict:
    api = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"
    req = urlrequest.Request(api, headers={"User-Agent": "voice-input-updater"})
    with urlrequest.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def _pick_zip_asset(release: dict, owner: str, repo: str) -> tuple:
    """(zip_url, tag) を返す。release assets に zip があれば優先、無ければ zipball_url。"""
    tag = (release.get("tag_name") or "").strip()
    # Release には Windows 用と Mac 用の 2 つの ZIP が並ぶ。先頭の ZIP を
    # 取ると別 OS の中身で上書きしてしまうので、自分の OS 名を含む物を優先する。
    want = "macos" if sys.platform == "darwin" else "windows"
    zips = []
    for a in release.get("assets", []):
        name = (a.get("name") or "").lower()
        url = a.get("browser_download_url")
        if name.endswith(".zip") and url:
            zips.append((name, url))
    for name, url in zips:
        if want in name:
            return url, tag
    if zips:
        return zips[0][1], tag
    return release.get("zipball_url"), tag


def _download(url: str, dest: Path):
    _print(f"  DL: {url}")
    req = urlrequest.Request(url, headers={"User-Agent": "voice-input-updater"})
    with urlrequest.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)


def _extract(zip_path: Path, dest_dir: Path) -> Path:
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(dest_dir)
    # GitHub の zipball は <owner>-<repo>-<sha>/ のトップ 1 層を持つので剥がす
    entries = [p for p in dest_dir.iterdir() if not p.name.startswith(".")]
    root = dest_dir
    if len(entries) == 1 and entries[0].is_dir():
        root = entries[0]
    # 配布 ZIP は「①〜④ + _app/」の形で、本体は _app の中にある。
    # 本体(ROOT)に重ねるのは _app の中身なので、そこを起点にする
    # (そのまま重ねると _app/_app/ の二重フォルダになる)。
    app = root / "_app"
    if (app / "VERSION").exists():
        return app
    return root


def _is_protected(rel: Path) -> bool:
    parts = rel.parts
    if not parts:
        return True  # ルートそのものはスキップ
    if parts[0] in PROTECTED_DIRS:
        return True
    if rel.suffix in PROTECTED_SUFFIXES:
        return True
    return False


def _backup_targets(src_root: Path) -> Path:
    """これから上書きされるファイルだけを _backup/<日時>/ にコピー。"""
    ts = time.strftime("%Y%m%d_%H%M%S")
    bdir = ROOT / "_backup" / ts
    bdir.mkdir(parents=True, exist_ok=True)
    for src in src_root.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(src_root)
        if _is_protected(rel):
            continue
        dst_existing = ROOT / rel
        if dst_existing.exists():
            bpath = bdir / rel
            bpath.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst_existing, bpath)
    return bdir


def _overlay(src_root: Path):
    """src_root の中身を ROOT に上書き。保護対象はスキップ。"""
    for src in src_root.rglob("*"):
        rel = src.relative_to(src_root)
        if _is_protected(rel):
            continue
        dst = ROOT / rel
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def _rollback(backup_dir: Path):
    if not backup_dir.exists():
        return
    for src in backup_dir.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(backup_dir)
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _confirm(prompt: str, assume_yes: bool) -> bool:
    if assume_yes:
        return True
    if not sys.stdin.isatty():
        _print(f"  {prompt} [非対話モードのため中止しました。--yes で自動承認]")
        return False
    try:
        ans = input(f"  {prompt} [Enter で続行 / n で中止]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return ans in ("", "y", "yes")


def _venv_python() -> str:
    """ROOT 配下の venv の python を返す。無ければ現在の python。"""
    if sys.platform == "win32":
        cand = ROOT / ".venv" / "Scripts" / "python.exe"
    else:
        cand = ROOT / ".venv" / "bin" / "python"
    if cand.exists():
        return str(cand)
    return sys.executable


def _pip_upgrade_requirements():
    req = ROOT / "requirements.txt"
    if not req.exists():
        return
    py = _venv_python()
    _print("  pip install --upgrade -r requirements.txt(差分のみ更新)...")
    try:
        import subprocess as sp
        sp.run([py, "-m", "pip", "install", "--upgrade", "-r", str(req)], check=False)
        # Mac の Moonshine は requirements.txt から外してある(macOS 15 以降 +
        # Apple Silicon 専用の部品しか無いため)。入れられる Mac なら別に入れ、
        # 入らない Mac は失敗しても Whisper で動くので黙って進む。
        if sys.platform == "darwin":
            sp.run([py, "-m", "pip", "install", "--upgrade",
                    "moonshine-voice>=0.1.5"], check=False)
    except Exception as e:
        _print(f"  ⚠ pip install に失敗: {e}(本体ファイルは更新済みです)")


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--check", action="store_true", help="比較だけして終了")
    ap.add_argument("--yes", action="store_true", help="確認を省略して実行")
    ap.add_argument("--repo", type=str, default="", help="リポジトリ URL を一時上書き")
    args = ap.parse_args()

    current = _read_version()
    _print(f"== アップデートチェック ==")
    _print(f"  現在のバージョン: v{current}")

    repo_url = args.repo or _read_repo_url()
    if not repo_url:
        _print("  config/settings.json の update_repo が未設定です。")
        _print("  例) {\"update_repo\": \"https://github.com/<owner>/<repo>\"}")
        sys.exit(2)

    owner, repo = _parse_owner_repo(repo_url)
    if not owner or not repo:
        _print(f"  リポジトリ URL の解析に失敗: {repo_url}")
        sys.exit(2)

    try:
        release = _fetch_latest_release(owner, repo)
    except urlerror.HTTPError as e:
        _print(f"  GitHub API エラー: HTTP {e.code}(リリースが未公開かもしれません)")
        sys.exit(3)
    except Exception as e:
        _print(f"  GitHub API への接続に失敗: {e}")
        sys.exit(3)

    zip_url, tag = _pick_zip_asset(release, owner, repo)
    if not zip_url or not tag:
        _print("  最新リリースに zip がありません。")
        sys.exit(3)

    latest_clean = tag.lstrip("v")
    _print(f"  最新リリース: v{latest_clean}")

    if _semver_tuple(current) >= _semver_tuple(tag):
        _print("  既に最新です。アップデート不要。")
        return

    if args.check:
        _print("  新しいバージョンがあります(--check のため終了)。")
        sys.exit(1)

    if not _confirm(f"v{current} → v{latest_clean} にアップデートします。続行しますか?", args.yes):
        _print("  ユーザーが中止しました。")
        sys.exit(4)

    with tempfile.TemporaryDirectory() as tdir:
        tdir_p = Path(tdir)
        zip_path = tdir_p / "release.zip"
        try:
            _download(zip_url, zip_path)
        except Exception as e:
            _print(f"  DL に失敗: {e}")
            sys.exit(5)

        extract_dir = tdir_p / "ext"
        extract_dir.mkdir(parents=True, exist_ok=True)
        try:
            src_root = _extract(zip_path, extract_dir)
        except Exception as e:
            _print(f"  展開に失敗: {e}")
            sys.exit(5)

        _print("  既存ファイルをバックアップしています...")
        backup_dir = _backup_targets(src_root)
        _print(f"  バックアップ先: {backup_dir}")

        _print("  ファイルを上書きしています(config / logs / .venv は保護)...")
        try:
            _overlay(src_root)
        except Exception as e:
            _print(f"  上書き中にエラー: {e}。ロールバックします。")
            _rollback(backup_dir)
            sys.exit(6)

    _pip_upgrade_requirements()
    _print(f"✅ v{latest_clean} にアップデートしました。アプリを再起動してください。")


if __name__ == "__main__":
    main()
