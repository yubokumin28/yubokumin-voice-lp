# -*- coding: utf-8 -*-
"""moonshine_engine.py - GPU 無し PC 向けの新エンジン(Moonshine v2 日本語)。

Whisper は入力を必ず 30 秒枠に引き伸ばして encoder を回すため、CPU では
短い発話でも固定ロスが乗る(i7-10710U 実測: small 3.0 秒 / base 0.9 秒)。
Moonshine は「話している間に少しずつ処理」できるので、キーを離してから
文字が出るまでの待ちがほぼ 0 になる(2026-09-21 実測: 0.02〜0.14 秒)。
精度も同条件で Whisper small より良かった(CER 4.8% vs 10.6%)。

使い方(transcriber.create_transcriber が settings の engine を見て選ぶ):
  - 一括認識:   transcribe(audio) / transcribe_raw(audio)  … Whisper と同じ顔
  - 生ストリーム: begin_stream() → feed(chunk)… → end_stream() = 全文
                  (StreamingSession が録音中に feed を呼び、離した時に end)

ライセンス(2026-09-21 確認, Moonshine AI Community License):
  年間売上 100 万ドル未満なら無料で使用・配布できる(非商用は登録不要、
  商用は moonshine.ai/community-license で登録)。配布物には
  NOTICE_moonshine.txt(ライセンス写し + 帰属表示)を同梱し、
  「Powered by Moonshine AI」をどこかに表示する必要がある。

依存: pip install moonshine-voice  (Windows / macOS / Linux の wheel あり)
初回起動時に日本語モデル(約 117MB)を自動ダウンロードする。
"""

import time

MODEL_LANGUAGE = "ja"
MODEL_DOWNLOAD_MB = 117  # small-streaming-ja(量子化)の実測サイズ


class _Segment:
    """faster-whisper のセグメント互換(.text / .start / .end / .words)。"""

    def __init__(self, text, start, end):
        self.text = text
        self.start = start
        self.end = end
        self.words = None


def is_available():
    """moonshine-voice が import できるか(未導入なら Whisper に落とす)。"""
    try:
        import moonshine_voice  # noqa: F401

        return True
    except Exception:
        return False


def model_is_cached():
    """日本語モデルがダウンロード済みか(初回案内の要否判定に使う)。"""
    try:
        from pathlib import Path

        import moonshine_voice as mv

        # get_model_for_language はキャッシュ済みならダウンロードしない。
        # 未取得なら通信が走るので、先にキャッシュ側だけ覗く。
        root = Path(mv.get_assets_path()).parent
        hits = list(root.rglob("small-streaming-ja"))
        if hits:
            return any(p.rglob("encoder.ort") for p in hits)
        # 置き場が版で変わった時の保険: ユーザーキャッシュを広めに探す
        import platformdirs

        cache = Path(platformdirs.user_cache_dir("moonshine_voice"))
        return any(cache.rglob("small-streaming-ja"))
    except Exception:
        return False


class MoonshineTranscriber:
    """Moonshine 日本語モデルのラッパー。Transcriber と同じ属性を持つ。

    device / cpu_fallback_reason / model_size は hotkey_app.py が表示に
    使うので、Whisper 版と同じ名前で持っておく。
    """

    engine = "moonshine"

    def __init__(self, settings):
        import moonshine_voice as mv

        self.model_size = "moonshine-ja"
        self.device = "cpu"
        self.cpu_fallback_reason = None
        self.language = MODEL_LANGUAGE
        # 録音中に何秒ぶん溜まったら裏で認識を進めるか。小さいほど
        # 離した時の残り作業が減るが CPU を細かく使う。0.5 が公式既定。
        self.update_interval = float(settings.get("moonshine_update_sec", 0.5))
        self._stream = None

        t0 = time.perf_counter()
        path, arch = mv.get_model_for_language(MODEL_LANGUAGE)
        self.model = mv.Transcriber(model_path=path, model_arch=arch)
        self.load_sec = time.perf_counter() - t0

    # ---------------------------------------------------------- 一括認識
    def transcribe_raw(self, audio, word_timestamps=False):
        """numpy float32(16kHz) を一括認識し、セグメントのリストを返す。

        擬似ストリーミング(StreamingTranscriber)や検証コマンドから呼ばれる
        互換経路。本番のキー押下中は begin_stream/feed/end_stream の方が速い。
        """
        if audio is None or getattr(audio, "size", 0) == 0:
            return []
        result = self.model.transcribe_without_streaming(
            _to_list(audio), 16000
        )
        return _lines_to_segments(result)

    def transcribe(self, audio):
        return "".join(s.text for s in self.transcribe_raw(audio)).strip()

    def warmup(self):
        """起動直後の初回だけ遅いのを防ぐ。合成音を 1 秒ぶん通す。"""
        try:
            import numpy as np

            n = 16000
            t = np.arange(n, dtype="float32") / 16000.0
            tone = (0.1 * np.sin(2 * np.pi * 440.0 * t)).astype("float32")
            self.transcribe_raw(tone)
        except Exception:
            pass

    # ---------------------------------------------------------- 生ストリーム
    def begin_stream(self):
        """録音開始時に呼ぶ。以後 feed() で音を渡す。"""
        self.abort_stream()
        self._stream = self.model.create_stream(
            update_interval=self.update_interval
        )
        self._stream.start()

    def feed(self, chunk):
        """録音中の音声片(numpy float32, 16kHz)を渡す。裏で少しずつ認識する。"""
        if self._stream is None or chunk is None or len(chunk) == 0:
            return
        self._stream.add_audio(_to_list(chunk), 16000)

    def end_stream(self):
        """録音終了時に呼ぶ。残りを認識して全文を返す。"""
        if self._stream is None:
            return ""
        try:
            result = self._stream.stop()
            return "".join(
                line.text for line in getattr(result, "lines", []) or []
            ).strip()
        finally:
            self._close_stream()

    def abort_stream(self):
        """録音を破棄する時に呼ぶ(認識結果は捨てる)。"""
        if self._stream is None:
            return
        try:
            self._stream.stop()
        except Exception:
            pass
        self._close_stream()

    def _close_stream(self):
        try:
            self._stream.close()
        except Exception:
            pass
        self._stream = None


def _to_list(audio):
    """numpy 配列を moonshine が受ける float のリストにする。"""
    try:
        return audio.astype("float32").flatten().tolist()
    except AttributeError:
        return list(audio)


def _lines_to_segments(result):
    segs = []
    for line in getattr(result, "lines", []) or []:
        start = float(getattr(line, "start_time", 0.0) or 0.0)
        dur = float(getattr(line, "duration", 0.0) or 0.0)
        segs.append(_Segment(line.text, start, start + dur))
    return segs
