# -*- coding: utf-8 -*-
"""punctuate_rule.py - ルールベースの句読点付与(ノートパソコン版)

GPU版は Ollama(gemma)に句読点を打たせていた。ノート版はローカルLLMを
持たないため、辞書とパターンだけで「、」「。」を補う。

設計の考え方:
  - **足すのは「、」と「。」だけ**。1文字も書き換えない・消さない。
    最後に「句読点を除いた中身が元と一致するか」で検算し、
    一致しなければ元のテキストをそのまま返す(GPU版と同じ安全弁)。
  - **迷ったら打たない**。誤って打った読点は読みにくさとして残るが、
    打たなかった読点は「元のまま」でしかない。過少側に倒す。
  - 判定は文字列一致のみ。形態素解析も機械学習も使わないので、
    処理時間は1発話あたり1ミリ秒未満。CPUにもメモリにも影響しない。

無効化: settings.json の "punct_rule": false
"""

import re

# ---------------------------------------------------------------------------
# 句点「。」を打つ語尾
# ---------------------------------------------------------------------------
# 文中に出てきても句点を打ってよい語尾(照合は長いものから行う)。
SENTENCE_ENDINGS = sorted([
    "ませんでした", "でしょうか", "ましょうか", "ませんか",
    "ましょう", "でしょう",
    "ました", "ません", "でした",
    "できます", "あります", "ください", "下さい",
    "です", "ます",
    "だった", "である", "だろう",
], key=len, reverse=True)

# 文字列の**末尾**にある時だけ句点を打つ語尾。
# 「今日はですね現場に行きました」のように、これらは文の途中の言い淀みとして
# 非常によく現れる。文中で句点を打つと「今日はですね。現場に…」と誤って
# 文が割れる(2026-08-02 実演で発覚したため分離した)。
WEAK_ENDINGS = sorted([
    "ましたね", "ましたよ", "ですね", "ですよ", "ますね", "ますよ",
], key=len, reverse=True)

# 上の語尾の直後にこれが続く時は、文がまだ続いているので句点を打たない。
CONTINUATIONS = (
    "が", "けど", "けれど", "けれども", "ので", "のに", "から", "ため",
    "し", "と", "か", "ね", "よ", "な", "って", "たら", "なら", "ば",
    "でも", "ものの", "ながら", "つつ",
    "、", "。", "」", "』", ")", "）", "?", "?", "!", "!",
)

# ---------------------------------------------------------------------------
# 読点「、」を打つ接続表現
# ---------------------------------------------------------------------------
# 「が」単体は主語の助詞(私が行く)と紛らわしいので入れない。
# 必ず2文字以上の、接続だと確定できる形だけを対象にする。
CONNECTIVES = [
    "ましたが", "ませんが", "でしたが", "ですが", "ますが", "だったが",
    "ますので", "ですので", "ますから", "ですから",
    "ましたので", "ましたから",
    "けれども", "けれど", "ですけど", "ますけど",
    "だけれども", "ですが",
]

# 文頭に来たら直後に読点を打つ接続詞
HEAD_CONJUNCTIONS = [
    "しかしながら", "したがって", "そのため", "ところが", "とはいえ",
    "しかし", "ただし", "つまり", "そして", "それから", "その後",
    "また", "なので", "ですので", "ですから", "さらに", "ちなみに",
    "まず", "次に", "最後に", "例えば", "たとえば",
]

_MARKS = re.compile(r"[、。\s]")


def _strip_marks(text):
    """検算用に、句読点と空白を除いた文字列を返す。"""
    return _MARKS.sub("", text)


def _starts_with_any(text, pos, candidates):
    for c in candidates:
        if text.startswith(c, pos):
            return c
    return None


def _add_periods(text):
    """文末らしい語尾のうしろに「。」を補う。"""
    out = []
    i = 0
    n = len(text)
    while i < n:
        out.append(text[i])
        pos = i + 1
        # 末尾でだけ効く語尾(「〜ですね」)を先に見る
        weak = None
        for end in WEAK_ENDINGS:
            if pos - len(end) >= 0 and text.startswith(end, pos - len(end)):
                weak = end
                break
        if weak:
            if pos >= n:
                out.append("。")
            i += 1
            continue

        matched = None
        for end in SENTENCE_ENDINGS:
            if pos - len(end) >= 0 and text.startswith(end, pos - len(end)):
                matched = end
                break
        if matched:
            if pos >= n:
                # 文字列の末尾 -> 句点で締める
                out.append("。")
            else:
                nxt = _starts_with_any(text, pos, CONTINUATIONS)
                if nxt is None:
                    out.append("。")
        i += 1
    return "".join(out)


def _add_commas(text):
    """接続表現のうしろに「、」を補う。"""
    # 1) 文中の接続表現
    for conn in sorted(CONNECTIVES, key=len, reverse=True):
        text = re.sub(
            "(" + re.escape(conn) + ")(?![、。])",
            r"\1、",
            text,
        )
    # 2) 文頭(または句点直後)の接続詞
    for conj in sorted(HEAD_CONJUNCTIONS, key=len, reverse=True):
        text = re.sub(
            r"(^|。)(" + re.escape(conj) + r")(?![、。])",
            r"\1\2、",
            text,
        )
    return text


def _tidy(text):
    """打ちすぎ・重複を掃除する。"""
    text = re.sub(r"、{2,}", "、", text)
    text = re.sub(r"。{2,}", "。", text)
    text = re.sub(r"、。", "。", text)
    text = re.sub(r"。、", "。", text)
    # 「、」のすぐ後に「。」相当の閉じが来るケースを整える
    text = re.sub(r"、(?=[」』)）])", "", text)
    return text


def add_punctuation(text, settings=None):
    """テキストに句読点を補って返す。危険と判断したら元のまま返す。

    settings:
      punct_rule            : False で無効(既定 True)
      punct_rule_min_len    : この文字数未満の発話には打たない(既定 12)
    """
    settings = settings or {}
    if not settings.get("punct_rule", True):
        return text
    if not text:
        return text

    min_len = int(settings.get("punct_rule_min_len", 12))
    if len(_strip_marks(text)) < min_len:
        # 短い発話(「はい」「了解です」)に句点を足すと、かえって鬱陶しい。
        return text

    # すでに旦那様自身が句読点を打っている(または辞書で入っている)なら
    # 手を出さない。密度が 4% を超えていたら「打たれている」とみなす。
    marks = len(text) - len(_strip_marks(text))
    if len(text) > 0 and marks / len(text) > 0.04:
        return text

    try:
        result = _tidy(_add_commas(_add_periods(text)))
    except Exception:
        return text

    # 検算: 句読点以外が1文字でも変わっていたら採用しない
    if _strip_marks(result) != _strip_marks(text):
        return text
    return result
