# -*- coding: utf-8 -*-
"""overlay.py - 録音中ランプ(アクティブ画面の中央下にフロート表示 / Mac対応)

音声入力ツールの「今の状態」を、公式サイト(LP)の波形 UI と同じ見た目の
小さなパネルで、入力先ディスプレイの中央下に表示する(2026-09-22 統一)。
左に「● ラベル」の丸ピル、右に黄→ターコイズのグラデーションの棒。

状態(本体 hotkey_app.py が logs/overlay_state.txt に書く):
  - idle      : 非表示(タイピングの邪魔をしない)
  - recording : 「● 聞いています」 珊瑚色 + 波形が揺れる
  - busy      : 「● 認識中」       橙     + 波が左から右へ流れる
  - error     : 「● エラー」       赤     + 棒が短く止まる
  - repair    : 「● 自動修復中」   橙     + 1 本ずつ順に光る

別プロセスで動き、本体が消えたら自動終了する(ゾンビ化しない)。
モニタ座標取得・親プロセス生存判定は OS 差を platform_compat に集約。
手動なら:  python overlay.py <本体のPID>
"""

import math
import sys
import time
import tkinter as tk
from pathlib import Path

# overlay.py は subprocess として起動されるので、 sys.path に src が
# 入っていない可能性がある。 明示的に追加してから platform_compat を import。
_SRC = Path(__file__).resolve().parent
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

import platform_compat  # noqa: E402

ROOT = _SRC.parent
STATE_FILE = ROOT / "logs" / "overlay_state.txt"

# 録音/認識中がこの秒数を超えて続いたら、本体側の取りこぼしとみなして
# 強制的に待機(非表示)へ戻す保険。
STATE_STUCK_TIMEOUT_SEC = 30

# 透明にする背景キー色(この色のピクセルがウインドウから透けて消える)
KEY_COLOR = "#fe00fe"

# パネル外観(小さめ・控えめ。旦那様指示で旧ランプに近い大きさに戻した)
W = 256
H = 46
RADIUS = 14
BOTTOM_MARGIN = 20
PANEL = "#fbfcfd"         # 白に近い地(LP のカードと同じ)
PANEL_EDGE = "#e3e9ee"    # 縁取り(白い画面の上でも輪郭が分かる)

# ピル(左)と棒(右)の寸法
PILL_X = 9
PILL_W = 112
PILL_H = 24
BARS = 18
BAR_W = 3
BAR_GAP = 3
WAVE_H = 26               # 棒の最大の高さ

# 状態 -> (ラベル, ピル地, ピル文字, 棒の色 3 段(上・中・下), アニメ種別)
_STYLES = {
    "recording": ("聞いています", "#fff0ec", "#d6432f",
                  ((255, 200, 87), (40, 189, 184), (13, 126, 135)), "wave"),
    "busy":      ("認識中", "#fff4e3", "#a05a12",
                  ((255, 200, 87), (245, 158, 66), (196, 108, 30)), "flow"),
    "repair":    ("自動修復中", "#fff4e3", "#a05a12",
                  ((255, 200, 87), (245, 158, 66), (196, 108, 30)), "scan"),
    "error":     ("エラー", "#ffecec", "#b42323",
                  ((255, 150, 140), (226, 80, 70), (170, 40, 35)), "flat"),
}

_GRAD_STEPS = 6


def _lerp(c1, c2, t):
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))


def _hex(c):
    return "#%02x%02x%02x" % c


def _gradient(top, mid, bot):
    """上→中→下の 3 色から、棒 1 本ぶんの段ごとの色を作る。"""
    cols = []
    for k in range(_GRAD_STEPS):
        t = k / (_GRAD_STEPS - 1)
        if t < 0.55:
            cols.append(_hex(_lerp(top, mid, t / 0.55)))
        else:
            cols.append(_hex(_lerp(mid, bot, (t - 0.55) / 0.45)))
    return cols


_GRADS = {k: _gradient(*v[3]) for k, v in _STYLES.items()}

# LP と同じ「中央が高い + ゆらぎ」の基準高さ(0.22..1.0)
_BASE = []
for _i in range(BARS):
    _center = 1 - abs(_i - (BARS - 1) / 2) / ((BARS - 1) / 2)
    _wobble = (math.sin(_i * 1.7) + math.sin(_i * 0.6) + 2) / 4
    _BASE.append(0.22 + _center * 0.5 + _wobble * 0.28)


def _read_state():
    try:
        return STATE_FILE.read_text(encoding="utf-8").strip() or "idle"
    except Exception:
        return "idle"


# --- 描画ヘルパー ---------------------------------------------------------

def _round_rect(cv, x1, y1, x2, y2, r, color, outline=None):
    """角丸の塗りを描く(outline を渡すと 1px の縁取り付き)。"""
    o = outline or color
    cv.create_rectangle(x1 + r, y1, x2 - r, y2, fill=color, outline=color)
    cv.create_rectangle(x1, y1 + r, x2, y2 - r, fill=color, outline=color)
    for cx, cy in ((x1, y1), (x2 - 2 * r, y1), (x1, y2 - 2 * r),
                   (x2 - 2 * r, y2 - 2 * r)):
        cv.create_oval(cx, cy, cx + 2 * r, cy + 2 * r, fill=color, outline=color)
    if outline:
        cv.create_line(x1 + r, y1, x2 - r, y1, fill=o)
        cv.create_line(x1 + r, y2, x2 - r, y2, fill=o)
        cv.create_line(x1, y1 + r, x1, y2 - r, fill=o)
        cv.create_line(x2, y1 + r, x2, y2 - r, fill=o)
        for cx, cy, s in ((x1, y1, 90), (x2 - 2 * r, y1, 0),
                          (x1, y2 - 2 * r, 180), (x2 - 2 * r, y2 - 2 * r, 270)):
            cv.create_arc(cx, cy, cx + 2 * r, cy + 2 * r, start=s, extent=90,
                          style="arc", outline=o)


def _draw_bar(cv, cols, x, cy, w, h):
    """段ごとに色を変えた縦グラデーションの棒(両端は丸)。"""
    h = max(h, 3)
    top = cy - h / 2
    seg = h / _GRAD_STEPS
    for k, col in enumerate(cols):
        y1 = top + k * seg
        cv.create_rectangle(x, y1, x + w, y1 + seg + 0.6, fill=col, outline=col)
    cv.create_oval(x, top - w / 2, x + w, top + w / 2, fill=cols[0], outline=cols[0])
    cv.create_oval(x, top + h - w / 2, x + w, top + h + w / 2,
                   fill=cols[-1], outline=cols[-1])


def _bar_heights(kind, frame):
    """状態ごとの棒の高さ(0..1)を BARS 本ぶん返す。"""
    out = []
    for i, base in enumerate(_BASE):
        if kind == "wave":          # 録音中: 各棒が別々の周期で揺れる
            phase = frame * (0.42 + (i % 6) * 0.05) + (i % 9) * 0.6
            amp = 0.28 + 0.72 * (0.5 + 0.5 * math.sin(phase))
            out.append(min(1.0, base * amp * 1.15))
        elif kind == "flow":        # 認識中: 山が左から右へ流れる
            amp = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(i * 0.7 - frame * 0.45))
            out.append(min(1.0, 0.35 + 0.65 * amp * (0.6 + 0.4 * base)))
        elif kind == "scan":        # 自動修復中: 1 本ずつ順に高くなる
            active = (frame // 2) % BARS
            d = min(abs(i - active), BARS - abs(i - active))
            out.append(1.0 if d == 0 else (0.55 if d == 1 else 0.28))
        else:                       # エラー: 短く止まる
            out.append(0.32)
    return out


def _draw_panel(cv, state, frame):
    label, pill_bg, pill_fg, _cols, kind = _STYLES[state]
    cols = _GRADS[state]
    _round_rect(cv, 1, 1, W - 1, H - 1, RADIUS, PANEL, outline=PANEL_EDGE)
    # 左: ピル「● ラベル」(録音中だけ点が明滅)
    py = (H - PILL_H) / 2
    _round_rect(cv, PILL_X, py, PILL_X + PILL_W, py + PILL_H, PILL_H / 2, pill_bg)
    if kind == "wave":
        blink = 0.55 + 0.45 * abs(math.sin(frame * 0.35))
        dot = _hex(_lerp((255, 240, 236), (255, 107, 87), blink))
    else:
        dot = pill_fg
    cv.create_oval(PILL_X + 11, py + 8, PILL_X + 19, py + 16, fill=dot, outline=dot)
    cv.create_text(PILL_X + 25, py + PILL_H / 2, text=label, anchor="w",
                   fill=pill_fg, font=("Yu Gothic UI", 9, "bold"))
    # 右: 棒
    total = BARS * BAR_W + (BARS - 1) * BAR_GAP
    x0 = PILL_X + PILL_W + ((W - PILL_X - PILL_W) - total) / 2
    cy = H / 2
    for i, hh in enumerate(_bar_heights(kind, frame)):
        _draw_bar(cv, cols, x0 + i * (BAR_W + BAR_GAP), cy, BAR_W, WAVE_H * hh)


def main():
    parent_pid = int(sys.argv[1]) if len(sys.argv) > 1 else 0

    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    try:
        root.attributes("-transparentcolor", KEY_COLOR)  # 角丸の外側を透過
    except Exception:
        pass
    root.configure(bg=KEY_COLOR)

    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    init_x = (screen_w - W) // 2
    init_y = screen_h - H - BOTTOM_MARGIN
    root.geometry(f"{W}x{H}+{init_x}+{init_y}")

    cv = tk.Canvas(root, width=W, height=H, bg=KEY_COLOR,
                   highlightthickness=0, bd=0)
    cv.pack(fill="both", expand=True)

    ui = {"frame": 0, "shown": True, "x": init_x, "y": init_y}
    last_state = {"value": None, "since": time.monotonic()}

    def _reposition():
        rect = platform_compat.get_active_monitor_work_rect()
        if rect is None:
            x = (screen_w - W) // 2
            y = screen_h - H - BOTTOM_MARGIN
        else:
            left, top, right, bottom = rect
            x = (left + right) // 2 - W // 2
            y = bottom - H - BOTTOM_MARGIN
        if x != ui["x"] or y != ui["y"]:
            root.geometry(f"{W}x{H}+{x}+{y}")
            ui["x"] = x
            ui["y"] = y

    def tick():
        if not platform_compat.is_process_alive(parent_pid):
            root.destroy()
            return
        state = _read_state()
        # 録音/認識が長時間続いたら待機へ戻す保険
        now = time.monotonic()
        if state != last_state["value"]:
            last_state["value"] = state
            last_state["since"] = now
        elif (state in ("recording", "busy")
                and now - last_state["since"] > STATE_STUCK_TIMEOUT_SEC):
            state = "idle"
            last_state["value"] = "idle"

        if state not in _STYLES:  # idle 等 → 隠す
            if ui["shown"]:
                root.withdraw()
                ui["shown"] = False
            root.after(150, tick)
            return

        if not ui["shown"]:
            root.deiconify()
            try:
                root.attributes("-topmost", True)
            except Exception:
                pass
            ui["shown"] = True
        _reposition()

        ui["frame"] += 1
        cv.delete("all")
        _draw_panel(cv, state, ui["frame"])
        root.after(110, tick)

    tick()
    root.mainloop()


if __name__ == "__main__":
    main()
