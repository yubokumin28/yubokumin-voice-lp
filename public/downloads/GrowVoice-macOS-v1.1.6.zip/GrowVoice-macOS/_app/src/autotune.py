# -*- coding: utf-8 -*-
"""autotune.py - このパソコンに合った設定を自動で決める(2026-08-02 追加)

これを入れた理由:
  以前は「ノートPC用」「デスクトップ用」と配布物を分けようとしていたが、
  利用者に「自分のPCにGPUがあるか」を判断させるのは無理がある。
  配布物は Windows / Mac の2つに戻し、**中身が自分で判断する**方式にした。

決めるもの:
  model_size / compute_type / device / beam_size / cpu_threads /
  mic_always_on / warmup

判断の材料:
  1. GPU(CUDA)が実際に使えるか  ← 設定値ではなく実物を見る
  2. 搭載メモリ
  3. 論理コア数

settings.json の performance_mode で切り替わる。
  "auto"    : 下の判定表どおり(既定)
  "light"   : 一番軽い設定に固定(古いノートPC向け)
  "quality" : 一番精度の高い設定に固定(余裕のあるPC向け)
  "manual"  : 何もしない。settings.json に書いた値をそのまま使う
"""

import os
import subprocess
import sys


# ---------------------------------------------------------------------------
# 実測
# ---------------------------------------------------------------------------

def total_memory_gb():
    """搭載メモリ(GB)。分からない時は 8 を返す(安全側)。"""
    try:
        if sys.platform == "win32":
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            return round(stat.ullTotalPhys / (1024 ** 3), 1)
        out = subprocess.run(["sysctl", "-n", "hw.memsize"],
                             capture_output=True, text=True, timeout=5)
        return round(int(out.stdout.strip()) / (1024 ** 3), 1)
    except Exception:
        return 8.0


def cpu_cores():
    try:
        return os.cpu_count() or 4
    except Exception:
        return 4


def cuda_available():
    """CUDA が「実際に」使えるか。設定値ではなく実物を見る。

    2段階で見る。ここを手抜きすると誤判定する(2026-08-02 実測で発覚):
      ① GPU が刺さっているか(ctranslate2 が数えられるか)
      ② **推論に必要な cuBLAS の DLL が本当に読めるか**

    ①だけだと、GPU は積んでいるが DLL が無い配布版の exe でも「使える」と
    判定してしまい、起動のたびに CUDA 初期化に失敗して CPU に落ちる分だけ
    待たされる。②まで見て初めて正しい。
    """
    try:
        import ctranslate2

        if ctranslate2.get_cuda_device_count() <= 0:
            return False
    except Exception:
        return False

    if sys.platform != "win32":
        return False

    # pip で入れた nvidia-* の DLL は site-packages 配下にあり、Windows の
    # 標準の探索パスからは見つからない。transcriber と同じ準備をしてから探す。
    try:
        import transcriber

        transcriber._prepare_cuda_dll_paths()
    except Exception:
        pass

    try:
        import ctypes

        for name in ("cublas64_12.dll", "cublas64_11.dll"):
            try:
                ctypes.CDLL(name)
                return True
            except OSError:
                continue
    except Exception:
        pass
    return False


def apple_silicon():
    """Apple Silicon(M1 以降)かどうか。

    判定に使うためではなく、起動ログに出して利用者が自分のMacを
    把握できるようにするために持つ。Rosetta 経由の Python では
    platform.machine() が x86_64 を返すので、sysctl も見る。
    """
    if sys.platform != "darwin":
        return False
    try:
        import platform

        if platform.machine() == "arm64":
            return True
        out = subprocess.run(["sysctl", "-n", "hw.optional.arm64"],
                             capture_output=True, text=True, timeout=5)
        return out.stdout.strip() == "1"
    except Exception:
        return False


def is_on_battery():
    """バッテリー駆動中なら True。電源に繋がっていれば False。

    ノートPC で電池のときは、より軽い設定に倒すために使う。
    """
    if sys.platform == "darwin":
        # MacBook で電池駆動のときも1段軽くする。デスクトップ(Mac mini /
        # Studio / Pro)では常に 'AC Power' が返るので False になる。
        try:
            out = subprocess.run(["pmset", "-g", "batt"],
                                 capture_output=True, text=True, timeout=5)
            return "Battery Power" in out.stdout
        except Exception:
            return False
    if sys.platform != "win32":
        return False
    try:
        import ctypes

        class SYSTEM_POWER_STATUS(ctypes.Structure):
            _fields_ = [
                ("ACLineStatus", ctypes.c_byte),
                ("BatteryFlag", ctypes.c_byte),
                ("BatteryLifePercent", ctypes.c_byte),
                ("SystemStatusFlag", ctypes.c_byte),
                ("BatteryLifeTime", ctypes.c_ulong),
                ("BatteryFullLifeTime", ctypes.c_ulong),
            ]

        status = SYSTEM_POWER_STATUS()
        if not ctypes.windll.kernel32.GetSystemPowerStatus(
                ctypes.byref(status)):
            return False
        # ACLineStatus: 0=バッテリー, 1=電源接続, 255=不明
        return status.ACLineStatus == 0
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 判定
# ---------------------------------------------------------------------------

# 上から順に「これに当てはまれば採用」。最後は必ず当たる。
# download_mb は初回だけ必要な取得量の目安(利用者に事前に伝えるため)。
PROFILES = {
    "gpu": {
        "label": "GPU高速",
        "engine": "whisper",
        "model_size": "large-v3-turbo",
        "device": "cuda",
        "compute_type": "float16",
        "beam_size": 3,
        "cpu_threads": 0,
        "mic_always_on": True,
        "warmup": True,
        "download_mb": 1500,
    },
    "quality": {
        "label": "精度優先",
        "engine": "whisper",
        "model_size": "medium",
        "device": "cpu",
        "compute_type": "int8",
        "beam_size": 2,
        "cpu_threads": 0,
        "mic_always_on": True,
        "warmup": True,
        "download_mb": 1500,
    },
    # GPU 無しの 2 プロファイルは Moonshine 日本語エンジンを使う(2026-09-21)。
    # 同じ音声で Whisper small より精度が良く(CER 4.8% vs 10.6%)、話している
    # 間に処理するのでキーを離してからの待ちが 0.02〜0.14 秒(small は 3〜8 秒)。
    # 初回取得も 117MB で済む。moonshine-voice が無い環境では apply() が
    # 自動で Whisper(model_size の値)に戻す。
    "balanced": {
        "label": "標準",
        "engine": "moonshine",
        "model_size": "small",
        "device": "cpu",
        "compute_type": "int8",
        "beam_size": 1,
        "cpu_threads": 0,
        "mic_always_on": False,
        "warmup": True,
        "download_mb": 464,
    },
    "light": {
        "label": "軽さ優先",
        "engine": "moonshine",
        "model_size": "base",
        "device": "cpu",
        "compute_type": "int8",
        "beam_size": 1,
        "cpu_threads": 2,
        "mic_always_on": False,
        "warmup": False,
        "download_mb": 141,
    },
}


def model_is_cached(model_size):
    """このモデルが既に取得済みか(初回ダウンロードの案内を出すかの判断)。"""
    try:
        hub = os.path.join(os.path.expanduser("~"), ".cache",
                           "huggingface", "hub")
        if not os.path.isdir(hub):
            return False
        for name in os.listdir(hub):
            if name.endswith("faster-whisper-" + model_size):
                return True
        return False
    except Exception:
        return False


def collect_facts():
    """判断の材料になる実測値をひとまとめにする。

    2箇所で同じ辞書を組み立てていたのを1つにした。片方だけ項目を
    足して食い違う事故を防ぐため。
    """
    return {
        "cuda": cuda_available(),
        "memory_gb": total_memory_gb(),
        "cores": cpu_cores(),
        "battery": is_on_battery(),
        "apple_silicon": apple_silicon(),
    }


def detect_profile():
    """このPCに合うプロファイル名と、判断に使った実測値を返す。"""
    facts = collect_facts()

    if facts["cuda"]:
        return "gpu", facts
    # 注: quality(medium)は**自動では選ばない**(2026-08-02 実測で方針変更)。
    # medium は初回に約1.5GB のダウンロードが走り、配布物として体験が悪い。
    #   「ダウンロードして起動したのに、いつまでも使えない」= 離脱要因。
    # GPU が無いPCで medium を選ぶと、取得も認識も両方遅いという一番つらい
    # 状態になる。small(約464MB)で実用十分であることは検証済み。
    # 精度を上げたい人は performance_mode を "quality" にすれば使える
    # (=待つと決めた人だけが待つ)。
    if facts["memory_gb"] >= 7.0 and facts["cores"] >= 4:
        return "balanced", facts
    return "light", facts


def apply(settings):
    """settings を書き換えて、使ったプロファイル情報を返す。

    settings.json に利用者が自分で書いた値は尊重する
    (performance_mode を "manual" にした場合は何もしない)。
    """
    mode = str(settings.get("performance_mode", "auto")).lower()
    if mode == "manual":
        return {"mode": "manual", "profile": None, "facts": {}, "applied": {}}

    if mode in PROFILES:
        name, facts = mode, collect_facts()
    else:
        name, facts = detect_profile()

    profile = dict(PROFILES[name])
    label = profile.pop("label")
    download_mb = profile.pop("download_mb", 0)

    # バッテリー駆動中は1段だけ軽くする(電源に繋げば次回の起動で戻る)
    if facts.get("battery") and name in ("quality", "balanced"):
        profile["warmup"] = False
        profile["mic_always_on"] = False

    # Moonshine が入っていない環境(旧セットアップ・main の GPU 機)では Whisper へ
    if profile.get("engine") == "moonshine":
        try:
            import moonshine_engine

            if not moonshine_engine.is_available():
                profile["engine"] = "whisper"
        except Exception:
            profile["engine"] = "whisper"

    for key, value in profile.items():
        settings[key] = value

    if profile.get("engine") == "moonshine":
        import moonshine_engine

        download_mb = moonshine_engine.MODEL_DOWNLOAD_MB
        need_download = not moonshine_engine.model_is_cached()
    else:
        need_download = not model_is_cached(profile["model_size"])

    return {"mode": mode, "profile": name, "label": label,
            "facts": facts, "applied": profile,
            "download_mb": download_mb,
            "need_download": need_download}


def describe(result):
    """起動ログに1行で出す説明文を組み立てる。"""
    if result.get("mode") == "manual":
        return "動作モード: 手動(settings.json の値をそのまま使います)"
    f = result.get("facts", {})
    a = result.get("applied", {})
    batt = " / バッテリー駆動" if f.get("battery") else ""
    # Mac の GPU(Metal)は音声認識エンジン(ctranslate2)が対応していない。
    # ここで「GPUなし」と出すと壊れていると誤解されるので、チップ名を出す。
    if sys.platform == "darwin":
        chip = " / Apple Silicon" if f.get("apple_silicon") else " / Intel Mac"
    else:
        chip = " / GPU" + ("あり" if f.get("cuda") else "なし")
    if a.get("engine") == "moonshine":
        model_desc = "Moonshine 日本語(話している間に認識) / cpu"
    else:
        model_desc = "%s / %s / beam %s" % (
            a.get("model_size"), a.get("device"), a.get("beam_size"))
    text = (
        "動作モード: %s(このPCを実測: メモリ%.0fGB / %dコア%s%s)\n"
        "  → モデル %s"
        % (result.get("label", "?"), f.get("memory_gb", 0), f.get("cores", 0),
           chip, batt, model_desc)
    )
    # 初回だけ数百MBの取得が走る。黙って待たせると「固まった」と誤解される。
    if result.get("need_download") and result.get("download_mb"):
        text += (
            "\n  ※ 初回のみ音声認識モデル(約%d MB)を取得します。"
            "回線しだいで数分かかります。" % result["download_mb"]
        )
    return text


if __name__ == "__main__":
    s = {}
    r = apply(s)
    print(describe(r))
    for k in sorted(r["applied"]):
        print("  %-16s = %s" % (k, r["applied"][k]))
