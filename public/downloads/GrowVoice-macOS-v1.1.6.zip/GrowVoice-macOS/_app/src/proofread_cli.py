# -*- coding: utf-8 -*-
"""proofread_cli.py - 今日の履歴を Ollama で推敲する(裏方・非リアルタイム)

トレイ「今日の履歴を推敲する (AI)」と、 ツール終了時に、 別プロセスとして
無窓で呼ばれる。 本番のリアルタイム認識には一切影響しない(速度を守る)。
Ollama が無い・落ちている時は静かに何もしない(安全側)。

使い方:
    pythonw proofread_cli.py          # 新しい行だけ推敲(自動実行・軽い)
    pythonw proofread_cli.py --full   # 今日の全行をやり直す(お手本の育ちを反映)
    pythonw proofread_cli.py --open   # 全行やり直し + 結果をメモ帳で開く(手動)
"""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import history  # noqa: E402
from punctuate import (  # noqa: E402
    proofread_history_file, warmup_proofread, unload_model,
    count_pending_lines,
)

SETTINGS_PATH = ROOT / "config" / "settings.json"


def _load_settings():
    """設定だけ直接読む(fillers 等は推敲に不要なので load_config は使わない)。"""
    try:
        return json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _mark_proofread_done():
    """自動推敲スケジューラ向けに「今日推敲した」印を settings に残す。

    read-modify-write で他のキーを壊さない。一時ファイル経由で原子的に置換。
    """
    import datetime
    try:
        s = _load_settings()
        s["last_proofread_date"] = f"{datetime.datetime.now():%Y%m%d}"
        tmp = SETTINGS_PATH.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(s, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")
        tmp.replace(SETTINGS_PATH)
    except Exception:
        pass


def _ollama_json(settings, path, timeout=5.0):
    import urllib.request
    base = settings.get("ollama_url", "http://localhost:11434").rstrip("/")
    with urllib.request.urlopen(base + path, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _has_nvidia_gpu():
    import shutil
    import subprocess
    exe = shutil.which("nvidia-smi")
    if not exe:
        return False
    try:
        r = subprocess.run([exe, "-L"], capture_output=True, text=True,
                           timeout=10,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        return r.returncode == 0 and "GPU" in (r.stdout or "")
    except Exception:
        return False


def _ollama_model_on_cpu(settings):
    """推敲モデルが「GPU に 1 バイトも載らず CPU で動いている」なら True。"""
    try:
        ps = _ollama_json(settings, "/api/ps")
    except Exception:
        return False
    want = settings.get("ollama_model", "gemma4:latest")
    for m in ps.get("models", []):
        if m.get("name") == want or m.get("model") == want:
            return int(m.get("size", 0)) > 0 and int(m.get("size_vram", 0)) == 0
    return False


def _restart_ollama(settings):
    """Ollama を落として起こし直し、API が戻るまで待つ(最長 40 秒)。"""
    import subprocess
    import time
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    for name in ("ollama app.exe", "ollama.exe"):
        try:
            subprocess.run(["taskkill", "/F", "/IM", name], capture_output=True,
                           timeout=15, creationflags=flags)
        except Exception:
            pass
    time.sleep(3)
    try:
        import platform_compat
        platform_compat.ensure_ollama_running(
            settings.get("ollama_url", "http://localhost:11434"))
    except Exception:
        return False
    for _ in range(40):
        time.sleep(1)
        try:
            _ollama_json(settings, "/api/tags", timeout=2.0)
            return True
        except Exception:
            continue
    return False


def _ensure_ollama_on_gpu(settings):
    """Ollama が GPU を見失って CPU で動いていたら、1 回だけ起こし直す。

    2026-09-11 実測: Ollama の自動更新(0.33.3→0.34.0)で再起動した直後に
    GPU の検出に失敗し、以後ずっと CPU(15 tok/s)で推敲していた。 1 行 30 秒の
    上限に掛かって「推敲AIを使えない」扱いになり、自己改善が丸1日止まっていた。
    Ollama を起こし直すだけで GPU に戻る(94 tok/s)ので、ここで自己修復する。
    """
    if sys.platform != "win32" or not _ollama_model_on_cpu(settings):
        return
    if not _has_nvidia_gpu():
        return  # GPU の無い PC では CPU が正常
    import datetime
    import punctuate
    ok = _restart_ollama(settings)
    if ok:
        punctuate._available = True
        warmup_proofread(settings)
        ok = not _ollama_model_on_cpu(settings)
    try:
        log = ROOT / "logs" / "proofread_repair.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8") as f:
            f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} "
                    f"Ollama が CPU で動いていたため起こし直し: "
                    f"{'GPU に復帰' if ok else '復帰できず(CPU のまま)'}\n")
    except Exception:
        pass


def main(argv):
    open_after = "--open" in argv
    # 手動実行(トレイ・--full)は上限なしで全部やり直す。 自動実行は差分だけ。
    full = open_after or "--full" in argv
    settings = _load_settings()
    # AI設定タブの親スイッチ OFF(Ollama を使わない)なら何もしない(2026-09-21)。
    # 手動の「今すぐ推敲する」でも同じ。使う時はスイッチを ON にしてもらう。
    if not settings.get("ollama_enabled", True):
        print("推敲AI(Ollama)は OFF 設定です。AI設定タブのスイッチを ON にすると使えます。")
        return 0
    src_path = history.today_log()
    if not src_path.exists():
        return 0
    # 新しい行が無ければ Ollama を起こさずに終わる(常駐中の空回りを防ぐ)。
    if not full and count_pending_lines(src_path, settings) == 0:
        return 0
    warmup_proofread(settings)
    # 自己修復: GPU を見失った Ollama(CPU 動作)なら起こし直してから推敲する。
    _ensure_ollama_on_gpu(settings)
    out_path = proofread_history_file(src_path, settings, full=full)
    if out_path:
        # 育つAI第2段: 推敲結果から誤変換ペア候補を抽出して蓄積する。
        # 純Python処理(Ollama不要)。失敗しても推敲結果は守る(安全側)。
        try:
            import learning
            learning.update_from_refined(src_path, out_path)
        except Exception:
            pass
        _mark_proofread_done()
    # バッチ完了後、モデルをメモリから降ろして PC を軽く保つ。
    unload_model(settings)
    if open_after and out_path and Path(out_path).exists():
        try:
            os.startfile(str(out_path))
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
