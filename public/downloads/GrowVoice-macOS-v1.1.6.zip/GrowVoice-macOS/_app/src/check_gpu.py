# -*- coding: utf-8 -*-
"""check_gpu.py - このPCを実測し、本番で使うモデルを先に取得する
(セットアップ.bat から実行)

セットアップの最後に走らせておくことで、本番の初回起動でいきなり数百MBの
ダウンロードが始まって「固まった」ように見える状態を防ぐ。

2026-08-27 (laptop ブランチ) の修正:
  以前は settings.json の model_size をそのまま読んでいた。この値は GPU 機
  向けの large-v3-turbo なので、GPU の無いノートPCでも約1.5GB を取りに行き、
  しかも本体は起動時に autotune で small に落とすため、その1.5GBは一度も
  使われなかった。取得と認識の両方で損をしていた。
  ここでも autotune を通し、本体とまったく同じモデルを取得するようにした。
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    print("このパソコンを実測して、使う音声認識モデルを決めます。")

    try:
        settings = json.loads(
            (ROOT / "config" / "settings.json").read_text(encoding="utf-8")
        )
    except Exception:
        settings = {}

    sys.path.insert(0, str(ROOT / "src"))

    # 本体(hotkey_app)の起動時とまったく同じ判定をここでも通す。
    # これを飛ばすと「セットアップで落としたモデル」と「本番で使うモデル」が
    # 食い違い、初回起動でもう一度ダウンロードが走る。
    try:
        import autotune

        print(autotune.describe(autotune.apply(settings)))
    except Exception as e:
        print(f"  自動判定を飛ばしました({e})。settings.json の値をそのまま使います。")

    model_size = settings.get("model_size", "small")

    try:
        from transcriber import create_transcriber
    except ImportError:
        print("  faster-whisper が未インストールです。セットアップが未完了です。")
        return

    if settings.get("engine") == "moonshine":
        print("  Moonshine 日本語モデルを準備します。初回は約117MBの取得で"
              "少し待ちます...")
    else:
        print(f"  {model_size} を準備します。初回はダウンロードで数分かかります...")
    transcriber = create_transcriber(settings)

    if getattr(transcriber, "engine", "") == "moonshine":
        print("  -> OK: Moonshine 日本語エンジン(CPU)を使います。")
        print("     GPU の無いパソコン向けの新エンジンです。話している間に")
        print("     認識を進めるので、キーを離した直後に文字が出ます。")
        return
    if transcriber.device == "cuda":
        print(f"  -> OK: GPU(CUDA)で {model_size} が使えます。")
    else:
        print(f"  -> OK: CPUで {model_size} を使います。")
        print("     GPUの無いパソコンでは、これが正常な構成です。")
        print("     故障ではありません。そのままお使いいただけます。")
        if getattr(transcriber, "cpu_fallback_reason", None):
            print(f"     (判定の根拠: {transcriber.cpu_fallback_reason})")


if __name__ == "__main__":
    main()
