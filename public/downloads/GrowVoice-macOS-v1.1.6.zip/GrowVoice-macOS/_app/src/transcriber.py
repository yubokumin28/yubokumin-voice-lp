# -*- coding: utf-8 -*-
"""transcriber.py - faster-whisper による音声認識 (第2段)

速度のための設定:
  - beam_size      : 1(貪欲探索)で高速。精度を上げたい時だけ 2〜5 にする。
  - compute_type   : float16(GPU)。
  - vad_filter     : 無音区間を除いて認識を速く・正確に。
  - hotwords       : 認識を効かせたい固有名詞のヒント(誤変換を元から減らす)。

GPU(CUDA)初期化は、モデル初回ダウンロード時の Windows のリンク権限エラー等で
たまたま失敗することがある。その場合 CPU だと約10倍遅くなるため、
(Step1) CUDA を一度リトライし、それでも駄目な時だけ CPU に落として警告する。
"""

import os
import sys
import threading
import time

# モデルDLの安定化: hf-xet 経由のダウンロードが 0KB のまま止まる事象がある
# (2026-07-24 導入レビュー)。既定で従来のHTTP方式に固定する。
# 利用者が環境変数で明示指定していればそちらを尊重する(setdefault)。
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")


def _prepare_cuda_dll_paths():
    """pip 導入の nvidia-*(cublas/cudnn 等)の DLL を探索パスに加える。

    ctranslate2 は cublas64_12.dll 等を Windows の標準探索パスから探すが、
    pip 導入分は site-packages/nvidia/*/bin にあり見つからず
    「cublas64_12.dll not found」で落ちる(2026-07-24 導入レビュー)。
    DLL のコピー配置ではなく os.add_dll_directory + PATH 追加で解決する。
    """
    if sys.platform != "win32":
        return
    try:
        import importlib.util
        from pathlib import Path

        spec = importlib.util.find_spec("nvidia")
        if spec is None or not spec.submodule_search_locations:
            return
        for base in spec.submodule_search_locations:
            for bin_dir in Path(base).glob("*/bin"):
                try:
                    os.add_dll_directory(str(bin_dir))
                    os.environ["PATH"] = (
                        str(bin_dir) + os.pathsep + os.environ.get("PATH", "")
                    )
                except Exception:
                    pass
    except Exception:
        pass


def _build_model(model_size, device, compute_type):
    """WhisperModel を1つ生成する。"""
    _prepare_cuda_dll_paths()
    from faster_whisper import WhisperModel

    return WhisperModel(model_size, device=device, compute_type=compute_type)


class Transcriber:
    """faster-whisper のラッパー。モデルは1度だけロードして使い回す。"""

    def __init__(self, settings):
        model_size = settings.get("model_size", "large-v3-turbo")
        device = settings.get("device", "cuda")
        compute_type = settings.get("compute_type", "float16")
        self.language = settings.get("language", "ja")
        self.beam_size = int(settings.get("beam_size", 1))
        self.vad_filter = settings.get("vad_filter", True)
        self.hotwords = (settings.get("hotwords", "") or "").strip() or None
        # 認識スパイク対策(旦那様の症状: 短い発話でもたまに3〜8秒かかる)
        # 無音区間で whisper が悩んでハルシネーション抑制ループを回す
        # のを止める設定。 0 にすれば無効化できる。
        self.hallucination_silence_threshold = float(
            settings.get("hallucination_silence_threshold", 2.0)
        )
        # 「無音」と判定する閾値。 大きいほど無音判定が出やすくなる(早く切れる)。
        # 既定 0.6 → 0.7 でわずかに早めに切る。
        self.no_speech_threshold = float(
            settings.get("no_speech_threshold", 0.7)
        )

        self.device = None
        self.cpu_fallback_reason = None
        self.model = None
        self.model_size = model_size
        # GPU認識が「認識中」のまま無応答になった時、CPU(int8)へ自動で
        # 切り替えるまでの秒数(2026-07-24 導入レビュー: GPUハング対策)。
        # settings.json の gpu_hang_timeout_sec で調整、0 で無効化。
        self.gpu_hang_timeout_sec = float(
            settings.get("gpu_hang_timeout_sec", 90)
        )
        self._fallback_lock = threading.Lock()
        self._gain_notice_shown = False

        if device == "cpu":
            self.model = _build_model(model_size, "cpu", "int8")
            self.device = "cpu"
            return

        # CUDA を最大2回試す(初回DLのリンクエラー等は2回目で通ることが多い)
        last_error = None
        for attempt in range(2):
            try:
                self.model = _build_model(model_size, "cuda", compute_type)
                self.device = "cuda"
                return
            except Exception as e:
                last_error = e
                if attempt == 0:
                    print("GPU初期化に失敗。モデル取得を確認して再試行します...")
                    time.sleep(1.0)

        # 2回とも失敗 -> CPU にフォールバック(遅いので理由を残す)。
        # ※ Mac でも本パスを通る: macOS では faster-whisper の CUDA は無いので
        #   _build_model("cuda", ...) が例外を返し、 ここで CPU(int8)に落ちる。
        #   第一弾 Mac 配布は CPU 限定(Metal 加速は版差が大きく検証不可)。
        self.cpu_fallback_reason = str(last_error)
        self.model = _build_model(model_size, "cpu", "int8")
        self.device = "cpu"

    def transcribe_raw(self, audio, word_timestamps=False):
        """numpy float32 配列を認識し、セグメントのリストを返す。

        各セグメントは .text / .start / .end(秒)を持つ。
        word_timestamps=True を渡すと各セグメントに .words(.word/.start/.end)
        も付く。 ストリーミング(Step2)で「句点なしの長文」でも単語単位で
        確定を進めるために使う。

        ストリーミング(Step2)が「どこまで確定したか」を時刻で判断するために使う。

        スパイク対策パラメータ(faster-whisper v1.0+):
          - hallucination_silence_threshold: 無音区間でハルシネーション抑制
            ループを最大何秒まで粘らせるか。 これを超えると即 break する。
          - no_speech_threshold: 無音と判定する確率閾値。 大きいほど早く切る。
        """
        kwargs = dict(
            language=self.language,
            beam_size=self.beam_size,
            vad_filter=self.vad_filter,
            condition_on_previous_text=False,  # 繰り返しループを防ぎ高速化
            hotwords=self.hotwords,
            no_speech_threshold=self.no_speech_threshold,
            word_timestamps=word_timestamps,
        )
        # hallucination_silence_threshold は faster-whisper v1.0+ のみ。
        # 古いバージョンでも動くように、 サポートされていない時は無視する。
        if self.hallucination_silence_threshold > 0:
            kwargs["hallucination_silence_threshold"] = (
                self.hallucination_silence_threshold
            )
        audio = self._autogain(audio)

        def _run():
            k = dict(kwargs)
            try:
                segments, _info = self.model.transcribe(audio, **k)
                return list(segments)
            except TypeError:
                # 旧バージョンの faster-whisper: 新パラメータを除いて再試行
                k.pop("hallucination_silence_threshold", None)
                k.pop("no_speech_threshold", None)
                k.pop("word_timestamps", None)
                segments, _info = self.model.transcribe(audio, **k)
                return list(segments)

        return self._run_guarded(_run)

    def _autogain(self, audio):
        """入力が小さすぎる時だけ増幅する(マイク音量/ブースト不足の救済)。

        マイクの入力レベルが低い環境では RMS が極端に小さく、認識精度が
        大きく落ちる(2026-07-24 導入レビュー: RMS≈0.00002 で無反応)。
        完全無音(ハルシネーション防止スキップ対象)は呼び出し側で弾かれる
        前提で、ここでは「小さいが音はある」波形だけを底上げする。
        """
        try:
            import numpy as np

            if audio is None or getattr(audio, "size", 0) == 0:
                return audio
            rms = float(np.sqrt(np.mean(audio ** 2)))
            if 1e-6 < rms < 0.01:
                gain = min(30.0, 0.05 / rms)
                audio = np.clip(audio * gain, -1.0, 1.0).astype("float32")
                if not self._gain_notice_shown:
                    self._gain_notice_shown = True
                    print(f" 音量自動補正: マイク入力が小さいため {gain:.1f}倍に"
                          f"増幅しました(RMS={rms:.5f})。")
                    print("   Windows の設定でマイク音量(入力レベル)を上げると"
                          "さらに安定します。")
            return audio
        except Exception:
            return audio

    def _run_guarded(self, fn):
        """GPU 推論をタイムアウト監視付きで実行する。

        GPU(cuda)で「認識中」のままハングする環境がある(2026-07-24 導入
        レビュー)。ハングした CUDA 呼び出しは中断できないため、監視スレッド
        方式で待ち、時間切れならそのスレッドを見捨てて CPU(int8) モデルを
        作り直し、以後は CPU で動き続ける(自動フォールバック)。
        """
        if self.device != "cuda" or self.gpu_hang_timeout_sec <= 0:
            return fn()
        result = {}
        done = threading.Event()

        def _worker():
            try:
                result["value"] = fn()
            except Exception as e:
                result["error"] = e
            finally:
                done.set()

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        if not done.wait(self.gpu_hang_timeout_sec):
            print(" " + "!" * 50)
            print(f" !!  GPU認識が {self.gpu_hang_timeout_sec:.0f}秒 応答しない"
                  "ため、CPU(int8) に自動で切り替えます。")
            print(" !!  以後の認識は遅くなります。改善しない場合は PC 再起動か")
            print(" !!  settings.json の device を \"cpu\" にしてください。")
            print(" " + "!" * 50)
            with self._fallback_lock:
                if self.device == "cuda":
                    self.cpu_fallback_reason = (
                        f"GPU推論が{self.gpu_hang_timeout_sec:.0f}秒無応答"
                        "(ハング検出)"
                    )
                    self.model = _build_model(self.model_size, "cpu", "int8")
                    self.device = "cpu"
            return fn()  # CPU モデルで再実行
        if "error" in result:
            raise result["error"]
        return result.get("value")

    def transcribe(self, audio):
        """numpy float32 配列(16kHz モノラル)を日本語テキストに変換する。"""
        return "".join(seg.text for seg in self.transcribe_raw(audio)).strip()

    def warmup(self):
        """起動時に合成音で1回走らせ、初回認識のもたつきを無くす。

        無音(zeros)だと VAD が「音声なし」と判定して decoder 経路をスキップ
        してしまい、本番音声で初めて cuDNN の autotune や decoder のJITが走る。
        そこで VAD を通る程度の合成音(sineトーン+微小ノイズ)を渡して、
        encoder + decoder の両方を確実に温める。
        Whisper は内部で 30秒に padding するため、 短い合成音でも本番と
        同じテンソル形状になり、 cuDNN のカーネルは一度で温まる。
        """
        try:
            import numpy as np

            sample_rate = 16000
            duration_sec = 2.0
            n = int(sample_rate * duration_sec)
            t = np.arange(n, dtype="float32") / sample_rate
            # 440Hz の sine + 微小ノイズで「音声らしさ」を出して VAD を通す
            tone = 0.1 * np.sin(2 * np.pi * 440.0 * t)
            noise = 0.005 * np.random.randn(n).astype("float32")
            audio = (tone + noise).astype("float32")
            # transcribe_raw 経由にすることで、warmup 中の GPU ハングも
            # _run_guarded の監視にかかり、CPU へ自動フォールバックできる。
            self.transcribe_raw(audio)
        except Exception:
            pass


def create_transcriber(settings):
    """settings の engine を見て認識エンジンを1つ作る(起動時の入口)。

      engine: "whisper"(既定) … faster-whisper。GPU があればこちら。
              "moonshine"       … Moonshine 日本語(GPU 無し PC 向け、
                                   話している間に処理するので待ちがほぼ 0)。
    moonshine を指定しても moonshine-voice が未導入なら、理由を出して
    Whisper に落とす(配布先で壊れないようにするため)。
    """
    engine = str(settings.get("engine", "whisper") or "whisper").lower()
    if engine == "moonshine":
        try:
            from moonshine_engine import MoonshineTranscriber

            return MoonshineTranscriber(settings)
        except Exception as e:
            print(f" 【注意】Moonshine エンジンを使えないため Whisper に切り替えます"
                  f"({e})")
    return Transcriber(settings)
