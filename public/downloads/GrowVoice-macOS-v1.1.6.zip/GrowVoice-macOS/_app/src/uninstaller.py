# -*- coding: utf-8 -*-
"""uninstaller.py - アンインストール機能(Windows / macOS 共通)

設計の考え方(2026-08-02):
  別の実行ファイル(アンインストール.exe / .command)を配るのをやめ、
  **本体アプリ自身にこの機能を持たせた**。理由:
    - macOS では .command に実行権限が必要で、zip 経由だと落ちやすい。
      アプリの中から呼べばその問題が消える。
    - OS ごとに別々の消し方を作らずに済む(このファイル1本で両対応)。
    - 配布物が減る。

呼ばれ方は3通り。どれも同じ run() に来る。
  1. タスクトレイ(メニューバー)の「アンインストール」
  2. Windows の「設定 → アプリ」からの削除
     (初回起動時に register_in_windows_apps() で自分を登録している)
  3. 開発中: python src/uninstaller.py

安全のため、GUI で必ず確認を取る。答えが「はい」以外なら一切消さない。
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

APP_LABEL = "Grow Voice"
REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\GrowVoice"
STARTUP_VBS_NAME = "音声入力ツール_自動起動.vbs"
SHORTCUT_NAMES = (
    "音声入力ツール.lnk",
    "Grow Voice.lnk",
)
MAC_LAUNCH_AGENT = "com.voiceinput.tool.plist"
MAC_LOCK_NAME = "voice_input_tool.lock"

IS_WIN = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"


# ---------------------------------------------------------------------------
# 場所
# ---------------------------------------------------------------------------

def app_root():
    """配布物のルート(exe / .app が置かれているフォルダ)。"""
    if getattr(sys, "frozen", False):
        exe = Path(sys.executable).resolve()
        if IS_MAC:
            # .../GrowVoice.app/Contents/MacOS/GrowVoice -> .app の親
            for parent in exe.parents:
                if parent.suffix == ".app":
                    return parent.parent
        return exe.parent
    return Path(__file__).resolve().parent.parent


def _home():
    return Path(os.path.expanduser("~"))


def _hf_hub():
    return _home() / ".cache" / "huggingface" / "hub"


def _ollama_dir():
    return _home() / ".ollama"


def _startup_vbs():
    return (Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows"
            / "Start Menu" / "Programs" / "Startup" / STARTUP_VBS_NAME)


def _mac_launch_agent():
    return _home() / "Library" / "LaunchAgents" / MAC_LAUNCH_AGENT


def _mac_lock():
    return _home() / "Library" / "Caches" / MAC_LOCK_NAME


def _dir_size_mb(path):
    total = 0
    try:
        for p in path.rglob("*"):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except Exception:
                    pass
    except Exception:
        pass
    return round(total / (1024 * 1024))


def find_model_caches():
    """認識モデルのキャッシュ一覧を返す。[(Path, MB), ...]"""
    hub = _hf_hub()
    out = []
    if hub.exists():
        try:
            for d in hub.iterdir():
                if d.is_dir() and "faster-whisper" in d.name:
                    out.append((d, _dir_size_mb(d)))
        except Exception:
            pass
    return out


# ---------------------------------------------------------------------------
# Windows の「アプリと機能」への自己登録
# ---------------------------------------------------------------------------

def register_in_windows_apps():
    """自分を Windows の「設定 → アプリ」に登録する(HKCU なので管理者不要)。

    インストーラを作らずに「アプリと機能から削除できる」を実現するための仕掛け。
    exe で動いている時だけ登録する(開発中の python 実行では登録しない)。
    失敗しても本体の動作には影響させない。
    """
    if not IS_WIN or not getattr(sys, "frozen", False):
        return False
    try:
        import winreg

        root = app_root()
        exe = str(Path(sys.executable).resolve())
        version = "1.0.0"
        vfile = root / "VERSION"
        if vfile.exists():
            try:
                version = vfile.read_text(encoding="utf-8").strip() or version
            except Exception:
                pass

        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_KEY) as key:
            winreg.SetValueEx(key, "DisplayName", 0, winreg.REG_SZ, APP_LABEL)
            winreg.SetValueEx(key, "DisplayVersion", 0, winreg.REG_SZ, version)
            winreg.SetValueEx(key, "Publisher", 0, winreg.REG_SZ, "Yubokumin Lab")
            winreg.SetValueEx(key, "DisplayIcon", 0, winreg.REG_SZ, exe)
            winreg.SetValueEx(key, "InstallLocation", 0, winreg.REG_SZ, str(root))
            winreg.SetValueEx(key, "UninstallString", 0, winreg.REG_SZ,
                              f'"{exe}" --gv-mode uninstall')
            winreg.SetValueEx(key, "NoModify", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(key, "NoRepair", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(key, "EstimatedSize", 0, winreg.REG_DWORD,
                              max(1, _dir_size_mb(root) * 1024))
        return True
    except Exception:
        return False


def unregister_from_windows_apps():
    """「アプリと機能」の登録を消す。"""
    if not IS_WIN:
        return False
    try:
        import winreg

        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, REG_KEY)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 個々の後始末
# ---------------------------------------------------------------------------

def stop_running(exclude_self=True):
    """常駐しているツールを止める。自分自身は残す(後始末の続きがあるため)。"""
    me = os.getpid()
    stopped = 0
    if IS_WIN:
        for name in ("GrowVoice.exe", "音声入力ツール.exe"):
            try:
                subprocess.run(["taskkill", "/F", "/IM", name, "/FI",
                                f"PID ne {me}" if exclude_self else "PID ge 0"],
                               capture_output=True, text=True)
                stopped += 1
            except Exception:
                pass
    else:
        for pattern in ("GrowVoice", "hotkey_app.py"):
            try:
                subprocess.run(["pkill", "-f", pattern], capture_output=True)
                stopped += 1
            except Exception:
                pass
    return stopped


def remove_autostart():
    """ログイン時の自動起動を解除する。"""
    try:
        if IS_WIN:
            p = _startup_vbs()
            if p.exists():
                p.unlink()
                return True
            return False
        agent = _mac_launch_agent()
        if agent.exists():
            subprocess.run(["launchctl", "unload", str(agent)],
                           capture_output=True)
            agent.unlink()
            return True
        return False
    except Exception:
        return False


def remove_shortcuts():
    """デスクトップのショートカット / ロックファイルを消す。"""
    removed = 0
    if IS_WIN:
        desktop = _home() / "Desktop"
        for name in SHORTCUT_NAMES:
            p = desktop / name
            if p.exists():
                try:
                    p.unlink()
                    removed += 1
                except Exception:
                    pass
    else:
        lock = _mac_lock()
        if lock.exists():
            try:
                lock.unlink()
                removed += 1
            except Exception:
                pass
    return removed


def remove_model_caches():
    """認識モデルのキャッシュを消す。消した件数を返す。"""
    n = 0
    for path, _mb in find_model_caches():
        try:
            shutil.rmtree(path)
            n += 1
        except Exception:
            pass
    return n


def schedule_self_delete(root):
    """自分が入っているフォルダを、終了後に消す予約を入れる。

    実行中のプログラムは自分の居るフォルダを消せないため、別プロセスに
    「数秒待ってから消す」よう頼んでおく。ここで作る一時ファイルは
    利用者の目に触れない場所(TEMP)に置き、実行後に自分自身も消える。
    """
    root = str(Path(root).resolve())
    try:
        if IS_WIN:
            import tempfile

            bat = Path(tempfile.gettempdir()) / "growvoice_cleanup.bat"
            # ASCII のみ(cmd.exe は CP932 固定のため日本語を書かない)
            bat.write_text(
                "@echo off\r\n"
                "ping 127.0.0.1 -n 6 > nul\r\n"
                f'rmdir /s /q "{root}"\r\n'
                'del "%~f0"\r\n',
                encoding="ascii",
            )
            subprocess.Popen(
                ["cmd", "/c", str(bat)],
                creationflags=(getattr(subprocess, "CREATE_NO_WINDOW", 0)
                               | getattr(subprocess, "DETACHED_PROCESS", 0)),
            )
            return True
        subprocess.Popen(
            ["/bin/sh", "-c", f'sleep 5; rm -rf "{root}"'],
            start_new_session=True,
        )
        return True
    except Exception:
        return False


def open_folder(path):
    try:
        if IS_WIN:
            os.startfile(str(path))  # noqa: S606
        elif IS_MAC:
            subprocess.Popen(["open", str(path)])
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 画面(確認ダイアログ)
# ---------------------------------------------------------------------------

def _dialogs():
    """tkinter の messagebox を用意する。使えない環境では None を返す。

    本体は窓なし(コンソールなし)で動くため、print では利用者に何も届かない。
    確認は必ずダイアログで取る。
    """
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        return root, messagebox
    except Exception:
        return None, None


def run():
    """アンインストールを実行する。戻り値: 実際に消したら True。"""
    root_dir = app_root()
    tkroot, mb = _dialogs()
    if mb is None:
        # 画面が出せない環境(ほぼ無い)では、安全のため何もしない
        print("アンインストール画面を表示できませんでした。中止します。")
        return False

    try:
        caches = find_model_caches()
        cache_mb = sum(mb_ for _p, mb_ in caches)

        msg = (
            f"{APP_LABEL} をこのパソコンから削除します。\n\n"
            "・常駐しているツールを終了します\n"
            "・ログイン時の自動起動を解除します\n"
            "・ショートカットを削除します\n"
            f"・プログラム本体を削除します\n    {root_dir}\n\n"
            "設定・辞書・履歴も一緒に消えます。\n"
            "よろしいですか?"
        )
        if not mb.askyesno("アンインストール", msg, icon="warning"):
            return False

        delete_cache = False
        if caches:
            delete_cache = mb.askyesno(
                "音声認識モデルについて",
                f"音声認識モデル({cache_mb} MB)も削除しますか?\n\n"
                "この置き場は、同じパソコンに入れた他の Grow Voice と\n"
                "共有しています。もう一方も使っている場合は「いいえ」を\n"
                "選んでください(削除すると再ダウンロードになります)。",
                icon="question",
            )

        # GPU版は Ollama(句読点・推敲・自動学習)を使うため、そのモデルも聞く。
        delete_ollama = False
        ollama = _ollama_dir()
        if ollama.exists():
            ollama_mb = _dir_size_mb(ollama)
            delete_ollama = mb.askyesno(
                "Ollama の AI モデルについて",
                f"Ollama の AI モデル({ollama_mb} MB)も削除しますか?\n\n"
                "Ollama を他の用途でも使っている場合は「いいえ」を\n"
                "選んでください。\n\n"
                "※ Ollama 本体(アプリ)は削除しません。不要な場合は\n"
                "   設定 → アプリ から別途アンインストールしてください。",
                icon="question",
            )

        # --- 実行 ---
        remove_autostart()
        remove_shortcuts()
        unregister_from_windows_apps()
        if delete_cache:
            remove_model_caches()
        if delete_ollama:
            try:
                shutil.rmtree(ollama)
            except Exception:
                pass
        stop_running()

        scheduled = schedule_self_delete(root_dir)

        if scheduled:
            mb.showinfo(
                "アンインストール完了",
                "削除しました。ご利用ありがとうございました。\n\n"
                "数秒後にフォルダごと消えます。\n"
                "この画面を閉じると終了します。",
            )
        else:
            open_folder(root_dir.parent if root_dir.parent.exists() else root_dir)
            mb.showinfo(
                "あと1つだけお願いします",
                "設定の削除は終わりました。\n\n"
                "フォルダだけ自動で消せなかったので、\n"
                f"お手数ですが次のフォルダをゴミ箱へ入れてください。\n\n{root_dir}",
            )
        return True
    finally:
        try:
            tkroot.destroy()
        except Exception:
            pass


def main(argv=None):
    ok = run()
    if ok:
        # 予約した削除が走れるよう、自分は即座に終了する
        os._exit(0)
    return 0


if __name__ == "__main__":
    sys.exit(main())
