#!/bin/bash
# マイクが正しく拾えているか確認 (macOS)
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

PY="$APP_ROOT/.venv/bin/python"
if [ ! -x "$PY" ]; then
  echo "❌ .venv がありません。先に '_mac/セットアップ.command' を実行してください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi

"$PY" "$APP_ROOT/src/mic_check.py"
echo
read -r -p "Enter キーで終了 " _
