#!/bin/bash
# 音声入力ツール 常駐起動 (macOS)
# - .venv の python で src/hotkey_app.py を起動
# - 子プロセスとして切り離し、Terminal を閉じても常駐継続
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

PY="$APP_ROOT/.venv/bin/python"
if [ ! -x "$PY" ]; then
  echo "❌ .venv がありません。先に '_mac/セットアップ.command' を実行してください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi

# 子プロセスを切り離して起動 (Terminal を閉じても残る)
nohup "$PY" "$APP_ROOT/src/hotkey_app.py" >/dev/null 2>&1 &
disown $! 2>/dev/null || true

echo "✅ 音声入力ツールを起動しました。メニューバーのアイコンを確認してください。"
sleep 2
