#!/bin/bash
# ログイン時の自動起動を有効化 (macOS LaunchAgent)
# - com.voiceinput.tool.plist の __APP_ROOT__ を実際のパスに置換
# - ~/Library/LaunchAgents/ にコピー
# - launchctl で load
# Win 版「管理者で自動起動を設定.bat」相当(管理者権限不要)。

set -u
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

LABEL="com.voiceinput.tool"
SRC_PLIST="$APP_ROOT/_mac/${LABEL}.plist"
DST_DIR="$HOME/Library/LaunchAgents"
DST_PLIST="$DST_DIR/${LABEL}.plist"

if [ ! -f "$SRC_PLIST" ]; then
  echo "❌ plist 雛形が見つかりません: $SRC_PLIST"
  read -r -p "Enter キーで終了 " _
  exit 1
fi
if [ ! -x "$APP_ROOT/.venv/bin/python" ]; then
  echo "❌ .venv がありません。先に '_mac/セットアップ.command' を実行してください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi

mkdir -p "$DST_DIR" "$APP_ROOT/logs"

# 既に load されていれば一旦 unload (上書きのため)
if launchctl list 2>/dev/null | grep -q "$LABEL"; then
  echo "既存の LaunchAgent をいったん停止します..."
  launchctl unload "$DST_PLIST" 2>/dev/null || true
fi

# __APP_ROOT__ を置換してコピー
# sed の区切りに | を使い、パスのスラッシュ衝突を回避
sed "s|__APP_ROOT__|${APP_ROOT}|g" "$SRC_PLIST" > "$DST_PLIST"
chmod 644 "$DST_PLIST"

echo "plist を配置しました: $DST_PLIST"

# load
if launchctl load "$DST_PLIST" 2>/dev/null; then
  echo "✅ ログイン時の自動起動を有効化しました。"
  echo "   次回 Mac にログインすると音声入力ツールが自動的に起動します。"
else
  echo "⚠ launchctl load に失敗しました。System Settings > プライバシーとセキュリティ で"
  echo "  Terminal にアクセシビリティ権限が付いているか確認してください。"
fi
echo
echo "(無効化したいときは:  launchctl unload '$DST_PLIST'  )"
echo
read -r -p "Enter キーで終了 " _
