#!/bin/bash
# 音声入力ツール 初回セットアップ (macOS)
# - 対応する Python (3.10〜3.12) を探して venv 作成
# - 依存パッケージ install
# - Moonshine 日本語エンジン(macOS 15 以降 + Apple Silicon のみ)を別に install
#   入らない Mac は Whisper で動く(autotune が自動で切替)
# - 他の .command すべてに実行権限付与
# - 詳細マニュアルは ../manual.html を参照
#
# 配布版では「② 音声入力を起動.command」が初回に --auto 付きで呼ぶ
# (--auto のときは最後の Enter 待ちを省き、Ollama の導入もしない。
#  Ollama は任意機能なので、Windows 版と同じくマニュアルの手順で入れる)。

set -u
AUTO=0
[ "${1:-}" = "--auto" ] && AUTO=1
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

pause_exit() {
  if [ "$AUTO" = "0" ]; then
    read -r -p "Enter キーで終了 " _
  fi
  exit "$1"
}

echo "============================================================"
echo "  音声入力ツール 初回セットアップ (macOS)"
echo "  (数分かかります。終わるまでこの窓を閉じないでください)"
echo "============================================================"
echo

# --- 1. 対応する Python (3.10〜3.12) を探す ---
# Mac 標準の python3 は 3.9、Homebrew の既定は 3.13 以降のことがあり、
# どちらも依存の導入に失敗する。版を指定して新しい順に探す。
PYCMD=""
for v in 3.12 3.11 3.10; do
  for c in "python$v" \
           "/Library/Frameworks/Python.framework/Versions/$v/bin/python$v" \
           "/opt/homebrew/bin/python$v" \
           "/usr/local/bin/python$v"; do
    if [ -z "$PYCMD" ] && command -v "$c" >/dev/null 2>&1; then
      PYCMD="$c"
    fi
  done
done
if [ -z "$PYCMD" ] && command -v python3 >/dev/null 2>&1; then
  if python3 -c 'import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,13) else 1)' 2>/dev/null; then
    PYCMD="python3"
  fi
fi
if [ -z "$PYCMD" ]; then
  echo "❌ 対応する Python (3.10〜3.12) が見つかりません。"
  echo "   マニュアルの「Python を入れる」で 3.12 を入れてから、もう一度実行してください。"
  echo "   https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg"
  pause_exit 1
fi
echo "✅ 使用する Python: $PYCMD ($("$PYCMD" -c 'import sys;print(".".join(map(str,sys.version_info[:3])))'))"
echo

# --- 2. venv 作成 ---
if [ ! -x "$APP_ROOT/.venv/bin/python" ]; then
  echo "専用 .venv を作成しています..."
  "$PYCMD" -m venv "$APP_ROOT/.venv" || { echo "❌ .venv を作れませんでした。"; pause_exit 1; }
fi
PY="$APP_ROOT/.venv/bin/python"
echo "✅ venv: $PY"
echo

# --- 3. pip install ---
echo "依存パッケージをインストールしています (初回は数分かかります)..."
"$PY" -m pip install --upgrade pip
if ! "$PY" -m pip install -r "$APP_ROOT/requirements.txt"; then
  echo "❌ 部品の取り込みに失敗しました。回線を確認して、もう一度実行してください。"
  pause_exit 1
fi
echo

# --- 4. Moonshine(速い日本語エンジン)---
echo "速い日本語エンジン (Moonshine) を入れています..."
if "$PY" -m pip install "moonshine-voice>=0.1.5"; then
  echo "✅ Moonshine を使います(キーを離してすぐ文字になります)"
else
  echo "ℹ この Mac では Moonshine を使えません(macOS 15 以降の M1〜 が必要です)。"
  echo "  代わりに Whisper で動きます(文字になるまで数秒かかります)。"
fi
echo

# --- 5. _mac/*.command に実行権限を付与 ---
chmod +x "$APP_ROOT/_mac/"*.command 2>/dev/null || true

# --- 6. Ollama(任意機能。手動セットアップ時のみ確認)---
if [ "$AUTO" = "0" ]; then
  echo "Ollama の導入状況を確認しています..."
  "$PY" "$APP_ROOT/tools/ensure_ollama.py" || true
  echo
fi

# 準備完了の印(途中で失敗した .venv を「準備済み」と誤判定しないため)
touch "$APP_ROOT/.venv/.setup_done"

# --- 7. マイクとアクセシビリティの権限案内 ---
echo "============================================================"
echo "  ⚠ 初回起動時に macOS から権限ダイアログが出ます"
echo "============================================================"
echo "  ・マイク: 「許可」を押してください"
echo "  ・アクセシビリティ: システム設定 > プライバシーとセキュリティ"
echo "    > アクセシビリティ で「ターミナル」を ON にしてください"
echo "  詳しくはマニュアルの「困ったとき」を参照。"
echo
echo "✅ セットアップが完了しました"
echo
if [ "$AUTO" = "0" ]; then
  echo "次は「② 音声入力を起動.command」をダブルクリックしてください。"
fi
pause_exit 0
