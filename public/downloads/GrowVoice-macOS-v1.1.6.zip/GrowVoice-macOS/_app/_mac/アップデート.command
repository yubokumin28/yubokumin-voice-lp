#!/bin/bash
# 音声入力ツール 自動アップデート (macOS)
# - tools/updater.py を呼んで GitHub Releases から最新版を取得し差分上書き
# - config/ logs/ .venv/ は保護(中身は触らない)
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

PY="$APP_ROOT/.venv/bin/python"
if [ ! -x "$PY" ]; then
  echo "❌ .venv がありません。先に '_mac/セットアップ.command' を実行してください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi

echo "============================================================"
echo "  音声入力ツール アップデート確認"
echo "============================================================"
echo

# 引数をそのまま透過 (--yes / --check / --repo URL)
"$PY" "$APP_ROOT/tools/updater.py" "$@"
rc=$?

echo
if [ $rc -eq 0 ]; then
  echo "完了。次回起動時から新しいバージョンになります。"
else
  echo "(終了コード $rc)"
fi
echo
read -r -p "Enter キーで終了 " _
exit $rc
