#!/bin/bash
# 設定画面を開く (macOS)
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

PY="$APP_ROOT/.venv/bin/python"
if [ ! -x "$PY" ]; then
  echo "❌ .venv がありません。先に '_mac/セットアップ.command' を実行してください。"
  read -r -p "Enter キーで終了 " _
  exit 1
fi

"$PY" "$APP_ROOT/src/settings_ui.py"
