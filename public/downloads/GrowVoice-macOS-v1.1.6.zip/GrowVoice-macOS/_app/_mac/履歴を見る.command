#!/bin/bash
# 入力履歴フォルダを Finder で開く (macOS)
cd "$(dirname "$0")/.."
APP_ROOT="$(pwd)"

LOG_DIR="$APP_ROOT/logs"
mkdir -p "$LOG_DIR"
open "$LOG_DIR"
