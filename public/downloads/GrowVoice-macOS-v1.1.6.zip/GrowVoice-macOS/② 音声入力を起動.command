#!/bin/bash
# Grow Voice 起動 (macOS)。初回だけ自動で準備してから常駐起動する。
cd "$(dirname "$0")/_app" || exit 1
APP_ROOT="$(pwd)"
PY="$APP_ROOT/.venv/bin/python"
export PYTHONUTF8=1

if [ ! -f "$APP_ROOT/.venv/.setup_done" ]; then
  chmod +x "$APP_ROOT/_mac/"*.command 2>/dev/null
  if ! bash "$APP_ROOT/_mac/セットアップ.command" --auto; then
    read -r -p "Enter キーで終了 " _
    exit 1
  fi
  echo "準備が完了しました。音声入力を起動します。"
fi

nohup "$PY" "$APP_ROOT/src/hotkey_app.py" >/dev/null 2>&1 &
disown $! 2>/dev/null || true
echo "✅ 起動しました。画面上のメニューバーにマイクのアイコンが出ます。"
echo "   この窓は閉じてかまいません。"
sleep 3
