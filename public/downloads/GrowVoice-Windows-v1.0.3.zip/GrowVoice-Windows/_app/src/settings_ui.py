# -*- coding: utf-8 -*-
"""settings_ui.py - 設定画面(録音キー + 辞書統合タブ)

「設定を開く.bat」または常駐本体のホットキー(既定 Ctrl+Shift+S)で開く。

  タブ1 録音キー: どのキーで録音するかを「押して登録」する。
  タブ2 辞書    : 言い換え / 記号・単位 / 建設用語(各分野) を
                  カテゴリ列付きで1ヶ所に統合表示。
                  追加時にカテゴリを選ぶと自動で適切なファイルへ保存。
                  カテゴリプルダウンで絞り込み表示も可能。

保存先(データ層は分離維持):
  録音キー   -> config/settings.json
  言い換え   -> config/replacements.json
  記号・単位 -> config/symbols.json(_comment は保持)
  建設用語   -> config/construction_terms.json(_comment は保持、section で分野)
反映:
  辞書は次の音声入力からすぐ反映。録音キーはツール再起動後に反映。
"""

import json
import os
import shutil
import subprocess
import sys
import threading
import webbrowser
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageOps

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config"
SETTINGS = CONFIG / "settings.json"
REPL = CONFIG / "replacements.json"
SYMBOLS = CONFIG / "symbols.json"
CONSTRUCTION = CONFIG / "construction_terms.json"
# 常駐本体(hotkey_app.py)が書く動作ログ・状態ファイル(動作ログタブで読む)
APP_LOG = ROOT / "logs" / "app.log"
HEARTBEAT = ROOT / "logs" / "heartbeat.txt"
OVERLAY_STATE_FILE = ROOT / "logs" / "overlay_state.txt"

sys.path.insert(0, str(ROOT / "src"))
from hotkey import evaluate_hotkey, pretty_key_label  # noqa: E402

# 妥当性レベルごとの文字色
LEVEL_COLORS = {"ok": "#1a7000", "warn": "#a05000", "bad": "#c00000"}

# --- 配色テーマ(クリーム地 + 黄アクセント) -----------------------------
CREAM = "#FBF7EC"        # ウインドウ背景
CARD = "#FFFFFF"         # カード・一覧背景
ACCENT = "#F6C544"       # 主役の黄色
ACCENT_HOVER = "#EBB72E"
ACCENT_TEXT = "#633806"  # 黄色の上に乗せる濃い文字
TEXT = "#2C2C2A"
MUTED = "#888780"
BORDER = "#E5DFD0"
SEL_BG = "#F6E2A0"       # 一覧の選択行
CHIP_BG = "#F1EDE2"      # カテゴリチップ
AI_BG = "#FAEEDA"        # ◆AI学習チップ
AI_TEXT = "#854F0B"

FONT = ("Yu Gothic UI", 13)
FONT_BOLD = ("Yu Gothic UI", 15, "bold")
FONT_SM = ("Yu Gothic UI", 11)
LIST_FONT = ("Yu Gothic UI", 12)


def _accent_btn(parent, text, command, width=110):
    """主役(黄色)ボタン。"""
    return ctk.CTkButton(
        parent, text=text, command=command, width=width, height=34,
        fg_color=ACCENT, hover_color=ACCENT_HOVER, text_color=ACCENT_TEXT,
        corner_radius=10, font=FONT,
    )


def _ghost_btn(parent, text, command, width=110, state="normal"):
    """白地の控えめボタン。"""
    return ctk.CTkButton(
        parent, text=text, command=command, width=width, height=34,
        fg_color=CARD, hover_color=CHIP_BG, text_color=TEXT,
        border_color=BORDER, border_width=1, corner_radius=10,
        font=FONT, state=state,
    )


def _themed_listbox(container, height):
    """クリーム配色にそろえた tk.Listbox(大量行でも高速)。"""
    sb = tk.Scrollbar(container)
    sb.pack(side="right", fill="y")
    lb = tk.Listbox(
        container, height=height, yscrollcommand=sb.set,
        font=LIST_FONT, activestyle="none", bd=0, relief="flat",
        highlightthickness=1, highlightbackground=BORDER,
        highlightcolor=BORDER, bg=CARD, fg=TEXT,
        selectbackground=SEL_BG, selectforeground=TEXT,
    )
    lb.pack(side="left", fill="both", expand=True)
    sb.config(command=lb.yview)
    return lb


# --- 丸窓アバター(右上アイコン) ----------------------------------------
# 表示は常に円形。元画像が四角でも中央を正方形に切り出して丸く見せる。
ASSETS = ROOT / "assets"
AVATAR_CUSTOM = ASSETS / "avatar_current.png"   # 旦那様が選んだ画像
AVATAR_DEFAULT = ASSETS / "avatar_default.png"  # 同梱の既定画像


def _resolve_avatar_path():
    """使うアバター画像を決める(選択画像 → 既定画像 → なし)。"""
    if AVATAR_CUSTOM.exists():
        return AVATAR_CUSTOM
    if AVATAR_DEFAULT.exists():
        return AVATAR_DEFAULT
    return None


def _circular_avatar_image(path, size):
    """四角い画像でも中央を正方形に切り出し、円形に切り抜いた CTkImage を返す。

    縁取りは付けない(透明の外側 + きれいな円)。4倍で描いて縮小し、
    円周のギザつきを抑える。
    """
    try:
        src = Image.open(path).convert("RGBA")
    except Exception:
        return None
    ss = size * 4
    img = ImageOps.fit(src, (ss, ss), Image.LANCZOS)
    mask = Image.new("L", (ss, ss), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, ss, ss), fill=255)
    img.putalpha(mask)
    img = img.resize((size, size), Image.LANCZOS)
    return ctk.CTkImage(light_image=img, dark_image=img, size=(size, size))


def _placeholder_avatar(size):
    """画像未設定時の円形プレースホルダ(淡い円・四角枠なし)。"""
    ss = size * 4
    img = Image.new("RGBA", (ss, ss), (0, 0, 0, 0))
    ImageDraw.Draw(img).ellipse((0, 0, ss, ss), fill=(241, 237, 226, 255))
    img = img.resize((size, size), Image.LANCZOS)
    return ctk.CTkImage(light_image=img, dark_image=img, size=(size, size))


# --- 推敲AI(Ollama)関連 ------------------------------------------------
OLLAMA_DOWNLOAD_URL = "https://ollama.com/download"


def _find_pythonw():
    """ターミナル窓を出さない pythonw.exe を返す。"""
    p = ROOT / ".venv" / "Scripts" / "pythonw.exe"
    return str(p) if p.exists() else "pythonw"


def _find_python():
    """標準出力を拾える python.exe を返す(アップデータの進捗表示用)。"""
    if sys.platform == "win32":
        p = ROOT / ".venv" / "Scripts" / "python.exe"
    else:
        p = ROOT / ".venv" / "bin" / "python"
    return str(p) if p.exists() else sys.executable


def _open_update_dialog(parent):
    """tools/updater.py を内部呼び出しし、進捗を子ウインドウに流す。

    `--yes` で実行(対話プロンプトは出ない)。stdout/stderr を 1 行ずつ
    Textbox に追記。終了コードで「最新です/完了/失敗」のトーストを出す。
    UI は別スレッドで読み取り、root.after で本体に反映してフリーズを防ぐ。
    """
    script = ROOT / "tools" / "updater.py"
    if not script.exists():
        messagebox.showerror("見つかりません",
                             "tools/updater.py が見つかりません。")
        return

    dlg = ctk.CTkToplevel(parent)
    dlg.title("アップデートを確認")
    dlg.geometry("640x440")
    dlg.configure(fg_color=CREAM)
    dlg.transient(parent.winfo_toplevel())
    dlg.after(60, dlg.lift)

    ctk.CTkLabel(
        dlg,
        text="GitHub の最新版と比較し、新しければ自動で上書きします。\n"
             "設定・履歴・.venv は触りません(保護対象)。",
        justify="left", anchor="w", text_color=TEXT, font=FONT_SM).pack(
            anchor="w", padx=16, pady=(14, 6))

    logbox = ctk.CTkTextbox(dlg, font=("Consolas", 11), fg_color=CARD,
                            text_color=TEXT, border_color=BORDER,
                            border_width=1, wrap="word")
    logbox.pack(fill="both", expand=True, padx=16, pady=6)
    logbox.configure(state="disabled")

    foot = ctk.CTkFrame(dlg, fg_color="transparent")
    foot.pack(fill="x", padx=16, pady=(2, 10))
    close_btn = _ghost_btn(foot, "閉じる", dlg.destroy, width=110)
    close_btn.pack(side="right")
    close_btn.configure(state="disabled")

    def _append(line):
        try:
            logbox.configure(state="normal")
            logbox.insert("end", line)
            logbox.see("end")
            logbox.configure(state="disabled")
        except Exception:
            pass

    def _finish(code):
        close_btn.configure(state="normal")
        if code == 0:
            messagebox.showinfo("アップデート",
                                "完了しました(既に最新の場合あり)。\n"
                                "更新があった場合はアプリを再起動してください。",
                                parent=dlg)
        else:
            messagebox.showerror("アップデート失敗",
                                 f"アップデータが終了コード {code} で停止しました。\n"
                                 "ログの末尾に原因が出ています。",
                                 parent=dlg)

    def worker():
        args = [_find_python(), "-u", str(script), "--yes"]
        kwargs = {"cwd": str(ROOT),
                  "stdin": subprocess.DEVNULL,
                  "stdout": subprocess.PIPE,
                  "stderr": subprocess.STDOUT,
                  "text": True,
                  "encoding": "utf-8",
                  "errors": "replace",
                  "bufsize": 1}
        if sys.platform == "win32":
            kwargs["creationflags"] = getattr(
                subprocess, "CREATE_NO_WINDOW", 0x08000000)
        try:
            proc = subprocess.Popen(args, **kwargs)
        except Exception as e:
            parent.after(0, lambda: _append(f"起動失敗: {e}\n"))
            parent.after(0, lambda: _finish(-1))
            return
        try:
            for line in proc.stdout:
                parent.after(0, lambda s=line: _append(s))
        except Exception:
            pass
        code = proc.wait()
        parent.after(0, lambda c=code: _append(f"\n[終了コード {c}]\n"))
        parent.after(0, lambda c=code: _finish(c))

    _append("アップデータを起動します...\n")
    threading.Thread(target=worker, daemon=True).start()


def _run_proofread_now(open_after=True):
    """proofread_cli.py を別プロセス(無窓・低優先度)で起動し今すぐ推敲・学習。"""
    if getattr(sys, "frozen", False):
        # 単体exe時は exe 自身を推敲モードで起動する
        import platform_compat
        extra = ("--open",) if open_after else ()
        platform_compat.spawn_app_mode("proofread", *extra, low_priority=True)
        messagebox.showinfo(
            "推敲を開始しました",
            "今日の履歴を裏で推敲して学習します(数十秒〜)。\n"
            "完了すると整えた結果がメモ帳で開きます。\n"
            "※ Ollama が未導入だと何も起きません(下のボタンから導入)。")
        return
    script = ROOT / "src" / "proofread_cli.py"
    if not script.exists():
        messagebox.showerror("見つかりません",
                             "proofread_cli.py が見つかりません。")
        return
    args = [_find_pythonw(), str(script)]
    if open_after:
        args.append("--open")
    kwargs = {"cwd": str(ROOT), "stdin": subprocess.DEVNULL,
              "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
              "close_fds": True}
    if sys.platform == "win32":
        kwargs["creationflags"] = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
            | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            | getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x00004000))
    try:
        subprocess.Popen(args, **kwargs)
        messagebox.showinfo(
            "推敲を開始しました",
            "今日の履歴を裏で推敲して学習します(数十秒〜)。\n"
            "完了すると整えた結果がメモ帳で開きます。\n"
            "※ Ollama が未導入だと何も起きません(下のボタンから導入)。")
    except Exception as e:
        messagebox.showerror("起動失敗", f"推敲の起動に失敗しました:\n{e}")


def _copy_pull_command():
    """推敲用モデルの取得コマンドをクリップボードにコピーする。"""
    model = _load_settings().get("ollama_model", "gemma4:latest")
    cmd = f"ollama pull {model}"
    try:
        import pyperclip
        pyperclip.copy(cmd)
        messagebox.showinfo(
            "コピーしました",
            f"次のコマンドをコピーしました。\n\n  {cmd}\n\n"
            "「PowerShell」に貼り付けて Enter を押すと、推敲用モデルが入ります。")
    except Exception:
        messagebox.showinfo(
            "モデル取得コマンド",
            f"このコマンドを「PowerShell」で1回実行してください。\n\n  {cmd}")


def _probe_ollama(settings, timeout=1.5):
    """Ollama に接続を試み、(つながったか, わかりやすい原因と対処) を返す。

    UI を止めないよう短いタイムアウトで別スレッドから呼ぶ前提。失敗時は
    「何が起きたか」「どうしたらいいか」を日本語1〜2行で返す(AI設定タブ表示用)。
    """
    import socket
    import urllib.error
    import urllib.request
    base = (settings or {}).get("ollama_url",
                                "http://localhost:11434").rstrip("/")
    try:
        with urllib.request.urlopen(base + "/api/tags", timeout=timeout) as r:
            if getattr(r, "status", 200) == 200:
                return (True, "")
        return (False, "Ollama が想定外の応答を返しました。\n"
                       "対処: Ollama を一度終了して起動し直してください。")
    except urllib.error.HTTPError as e:
        return (False, f"Ollama がエラー応答を返しました(コード {e.code})。\n"
                       "対処: Ollama を再起動してください。")
    except (urllib.error.URLError, OSError, socket.timeout) as e:
        reason = getattr(e, "reason", e)
        text = str(reason).lower()
        if isinstance(reason, ConnectionRefusedError) or \
                "10061" in text or "refused" in text:
            return (False, "Ollama が起動していません(接続拒否)。\n"
                           "対処: Ollama を起動してください。"
                           "未導入なら下の「Ollama を入れる」から導入できます。")
        if isinstance(reason, (TimeoutError, socket.timeout)) or \
                "timed out" in text:
            return (False, "Ollama の応答がありません(タイムアウト)。\n"
                           "対処: PC が重い可能性。少し待つか Ollama を再起動。")
        return (False, f"Ollama に接続できません: {reason}\n"
                       "対処: 下の「Ollama を入れる」から導入/起動してください。")
    except Exception as e:
        return (False, f"想定外のエラー: {e}\n"
                       "対処: Ollama を再起動しても直らない場合はご連絡ください。")


# 各状態の意味(説明文として AI設定タブ「状態の見かた」に常設する)
STATUS_LEGEND = [
    ("ok", "自動学習 稼働中",
     "推敲も学習も裏で動作中。理想の状態です。"),
    ("warn", "推敲のみ稼働",
     "②がOFF。推敲は回りますが、見つけた誤変換は辞書に自動登録されません"
     "(②をONにすると「辞書」タブの『AI自動登録』に入ります)。"),
    ("off", "自動推敲 OFF",
     "①がOFFのため裏では動いていません。下の①をONにしてください。"),
    ("bad", "Ollama 未接続",
     "Ollama が未起動/未導入です。下から導入・起動してください。"),
]


def _compute_status(settings, alive, reason=""):
    """状態を判定し (レベル, 見出し, ヘッダー補足, AI設定タブ用の詳細) を返す。

    レベル: ok=自動学習まで稼働 / warn=推敲のみ / off=自動推敲OFF / bad=未接続。
    理想(ok)以外はヘッダー補足を「→ AI設定タブへ」にして誘導する。
    """
    auto_pf = bool(settings.get("auto_proofread", True))
    auto_lr = bool(settings.get("learning_auto", True))
    last = str(settings.get("last_proofread_date", ""))
    if len(last) == 8 and last.isdigit():
        last_txt = f"最終推敲 {int(last[4:6])}/{int(last[6:8])}"
    else:
        last_txt = "まだ推敲なし"
    detail_of = {lv: d for lv, _t, d in STATUS_LEGEND}
    if not alive:
        return ("bad", "Ollama 未接続", "→ AI設定タブへ",
                reason or detail_of["bad"])
    if not auto_pf:
        return ("off", "自動推敲 OFF", "→ AI設定でON", detail_of["off"])
    if auto_lr:
        return ("ok", "自動学習 稼働中", last_txt,
                "推敲AIが裏で動いています。" + last_txt + "。")
    return ("warn", "推敲のみ稼働", "→ AI設定で②ON",
            last_txt + "。" + detail_of["warn"])


# --- カテゴリ管理 ---------------------------------------------------------
# 「言い換え」「記号・単位」は別ファイル管理のため削除不可(システム固定)。
# それ以外(建設用語の各分野・ユーザー独自)は construction_terms.json の
# section で管理し、追加・削除が可能。
CATEGORY_FIXED = ["言い換え", "記号・単位"]  # 削除・名称変更不可

# 既定で用意してある建設用語の分野(削除可)
# 「ユーザー追加」は旦那様の意向で既定リストから外した。
# 旦那様自身が「カテゴリ管理」から好きな名前で追加すればよく、
# 既定カテゴリとしては存在しない方が一覧がスッキリする。
CATEGORY_CONSTRUCTION_DEFAULT = [
    "一般・建築", "道路設計", "砂防設計",
    "ダム設計", "トンネル設計", "河川設計",
]


def _load_custom_categories():
    """settings.json から旦那様の追加したカテゴリ(独自分野)を読む。"""
    s = _load_settings()
    cats = s.get("custom_categories", [])
    return [c for c in cats if isinstance(c, str) and c] if isinstance(cats, list) else []


def _save_custom_categories(cats):
    """settings.json に旦那様の追加したカテゴリを書き戻す。"""
    s = _load_settings()
    s["custom_categories"] = list(cats)
    _save_settings(s)


def _all_categories(items=None):
    """現在使える全カテゴリ(固定 + 既定建設 + 独自 + 実データから抽出)。

    items を渡すと、過去データに残っている未登録 section も拾う。
    重複は順序を保ったまま除去する。
    """
    seen = []
    for c in CATEGORY_FIXED + CATEGORY_CONSTRUCTION_DEFAULT:
        if c not in seen:
            seen.append(c)
    for c in _load_custom_categories():
        if c not in seen:
            seen.append(c)
    if items:
        for it in items:
            c = it.get("category")
            if c and c not in seen:
                seen.append(c)
    return seen


def _category_to_source(category):
    """カテゴリ名 → (保存先, section)。

    「言い換え」→ replacements / 「記号・単位」→ symbols /
    その他はすべて construction(section にカテゴリ名)。
    """
    if category in ("言い換え", "AI自動登録"):
        return ("replacements", "")
    if category == "記号・単位":
        return ("symbols", "")
    return ("construction", category)


# --- ファイル入出力 --------------------------------------------------------

def _load_settings():
    try:
        return json.loads(SETTINGS.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_settings(data):
    if SETTINGS.exists():
        shutil.copy(SETTINGS, SETTINGS.with_name("settings.json.bak"))
    SETTINGS.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _load_rules():
    try:
        data = json.loads(REPL.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_rules(rules):
    if REPL.exists():
        shutil.copy(REPL, REPL.with_name("replacements.json.bak"))
    REPL.write_text(
        json.dumps(rules, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _load_symbols():
    """symbols.json を読み、(コメント類 dict, 表示用ペアのリスト) に分けて返す。"""
    try:
        data = json.loads(SYMBOLS.read_text(encoding="utf-8"))
    except Exception:
        return ({}, [])
    if not isinstance(data, dict):
        return ({}, [])
    meta = {k: v for k, v in data.items() if k.startswith("_")}
    items = [(k, v) for k, v in data.items() if not k.startswith("_")]
    return (meta, items)


def _save_symbols(meta, items):
    """symbols.json を保存する。_comment 等の meta を先頭に保持する。"""
    out = {}
    for k, v in meta.items():
        out[k] = v
    for read, sym in items:
        out[read] = sym
    if SYMBOLS.exists():
        shutil.copy(SYMBOLS, SYMBOLS.with_name("symbols.json.bak"))
    SYMBOLS.write_text(
        json.dumps(out, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _load_construction():
    """construction_terms.json を読み、(コメント類のリスト, 用語項目のリスト)。"""
    try:
        data = json.loads(CONSTRUCTION.read_text(encoding="utf-8"))
    except Exception:
        return ([], [])
    if not isinstance(data, list):
        return ([], [])
    metas = []
    items = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        if "wrong" in entry and "right" in entry:
            items.append({
                "wrong": entry.get("wrong", ""),
                "right": entry.get("right", ""),
                "enabled": bool(entry.get("enabled", False)),
                "section": entry.get("section", ""),
                "note": entry.get("note", ""),
            })
        else:
            metas.append(entry)
    return (metas, items)


def _save_construction(metas, items):
    """construction_terms.json を保存する。コメント類を先頭に維持する。"""
    out = list(metas) + list(items)
    if CONSTRUCTION.exists():
        shutil.copy(CONSTRUCTION,
                    CONSTRUCTION.with_name("construction_terms.json.bak"))
    CONSTRUCTION.write_text(
        json.dumps(out, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


# --- 統合辞書のロード/保存 ------------------------------------------------

def _load_unified_dictionary():
    """3ファイルから全項目を読んで統合リストを作る。

    戻り値: (items, sym_meta, ct_metas)
      items: [{"source", "category", "wrong", "right", "enabled",
               "section", "note"}, ...]
      sym_meta / ct_metas: 保存時に保持する元ファイルのコメント類
    """
    items = []
    # 1. 言い換え辞書(enabled / origin を保持。 学習由来の項目や、
    #    学習タブで無効化された項目を辞書タブ保存時に壊さないため)
    for r in _load_rules():
        if isinstance(r, dict) and r.get("wrong"):
            is_learned = r.get("origin") == "learning"
            items.append({
                "source": "replacements",
                # AI が自動で覚えた分は専用カテゴリ「AI自動登録」にまとめ、
                # 手で登録した分(言い換え)と区別して蓄積を一覧できるようにする。
                "category": "AI自動登録" if is_learned else "言い換え",
                "wrong": r["wrong"],
                "right": r.get("right", ""),
                "enabled": bool(r.get("enabled", True)),
                "section": "",
                "note": "",
                "origin": r.get("origin", ""),
                "provisional": bool(r.get("provisional", False)),
            })
    # 2. 記号・単位
    sym_meta, sym_items = _load_symbols()
    for k, v in sym_items:
        items.append({
            "source": "symbols",
            "category": "記号・単位",
            "wrong": k,
            "right": v,
            "enabled": True,
            "section": "",
            "note": "",
        })
    # 3. 建設用語
    ct_metas, ct_items = _load_construction()
    for c in ct_items:
        sec = c.get("section", "") or "一般・建築"
        items.append({
            "source": "construction",
            "category": sec,
            "wrong": c["wrong"],
            "right": c["right"],
            "enabled": bool(c.get("enabled", False)),
            "section": sec,
            "note": c.get("note", ""),
        })
    return items, sym_meta, ct_metas


def _save_unified_dictionary(items, sym_meta, ct_metas):
    """統合リストを 3 ファイルに振り分けて保存する。"""
    repl_rules = []
    sym_pairs = []
    ct_items = []
    for it in items:
        src = it.get("source", "construction")
        wrong = it.get("wrong", "")
        right = it.get("right", "")
        if not wrong:
            continue
        if src == "replacements":
            rule = {"wrong": wrong, "right": right}
            # 無効化(チェック外し)と学習由来の印を保存時に保持する
            if not it.get("enabled", True):
                rule["enabled"] = False
            if it.get("origin"):
                rule["origin"] = it["origin"]
            if it.get("provisional"):
                rule["provisional"] = True
            repl_rules.append(rule)
        elif src == "symbols":
            sym_pairs.append((wrong, right))
        else:  # construction
            ct_items.append({
                "wrong": wrong,
                "right": right,
                "enabled": bool(it.get("enabled", False)),
                "section": it.get("section") or "一般・建築",
                "note": it.get("note", ""),
            })
    _save_rules(repl_rules)
    _save_symbols(sym_meta, sym_pairs)
    _save_construction(ct_metas, ct_items)


# --- 一括貼り付けパーサ ----------------------------------------------------

def _parse_bulk_paste(text):
    """貼り付けテキストを (wrong, right) のペア列にパースする。

    対応区切り(優先順):Tab / 「→」「->」 / 全角『、』 / 半角カンマ
                       / 連続スペース / 単一スペース
    戻り値: (parsed_pairs, skipped_count)
    """
    pairs = []
    skipped = 0
    seps = ["\t", "→", "->", ",", "、", "  "]
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = None
        for sep in seps:
            if sep in line:
                parts = [p.strip() for p in line.split(sep, 1)]
                break
        if parts is None and " " in line:
            parts = [p.strip() for p in line.split(" ", 1)]
        if (parts and len(parts) == 2 and parts[0] and parts[1]):
            pairs.append((parts[0], parts[1]))
        else:
            skipped += 1
    return pairs, skipped


# --- 自動起動(Windows起動時に窓なしで常駐)のヘルパー --------------------

def _project_root():
    """src/settings_ui.py の2階層上 = プロジェクトルート。"""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _vbs_path():
    return os.path.join(_project_root(), "start_voiceinput.vbs")


def _startup_dir():
    return os.path.join(
        os.environ.get("APPDATA", ""),
        "Microsoft", "Windows", "Start Menu", "Programs", "Startup")


def _startup_lnk_path():
    # 文字化け回避のためファイル名はASCII。実体はスタートアップ内の起動係。
    return os.path.join(_startup_dir(), "VoiceInputTool.lnk")


def _legacy_startup_lnk():
    # 旧・日本語名のショートカット(重複防止のため見つけたら消す)。
    return os.path.join(_startup_dir(), "音声入力ツール(自動起動).lnk")


def _autostart_enabled():
    """スタートアップに自動起動ショートカットが在るか。"""
    return (os.path.exists(_startup_lnk_path())
            or os.path.exists(_legacy_startup_lnk()))


def _ensure_vbs():
    """窓なし起動係 start_voiceinput.vbs が無ければ生成する。"""
    p = _vbs_path()
    if os.path.exists(p):
        return
    proj = _project_root()
    content = (
        "Dim sh, projDir, py, target\r\n"
        'projDir = "%s"\r\n'
        'py = projDir & "\\.venv\\Scripts\\pythonw.exe"\r\n'
        'target = projDir & "\\src\\hotkey_app.py"\r\n'
        'Set sh = CreateObject("WScript.Shell")\r\n'
        "sh.CurrentDirectory = projDir\r\n"
        'sh.Run """" & py & """ """ & target & """", 0, False\r\n'
    ) % proj
    try:
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception:
        pass


def _set_autostart(enabled):
    """自動起動を ON/OFF する。成功で True。
    ON: スタートアップに wscript→vbs のショートカットを作る(窓なし)。
    OFF: そのショートカットを消す。
    pywin32非依存。ASCIIパスのみの小VBSを wscript で実行して .lnk を作るので、
    追加インストール不要・文字化けなし。"""
    # 旧・日本語名は常に掃除(重複自動起動を防ぐ)
    try:
        if os.path.exists(_legacy_startup_lnk()):
            os.remove(_legacy_startup_lnk())
    except Exception:
        pass

    lnk = _startup_lnk_path()
    if not enabled:
        try:
            if os.path.exists(lnk):
                os.remove(lnk)
            return True
        except Exception:
            return False

    try:
        wscript = os.path.join(os.environ.get("WINDIR", r"C:\Windows"),
                               "System32", "wscript.exe")
        proj = _project_root()
        if getattr(sys, "frozen", False):
            # 単体exe時は exe 自身を直接スタートアップに登録する
            # (console=False なので窓は出ない。vbs も pythonw も不要)。
            exe_path = sys.executable
            exe_dir = os.path.dirname(exe_path)
            target_line = 'sc.TargetPath = "%s"' % exe_path
            args_line = 'sc.Arguments = ""'
            workdir_line = 'sc.WorkingDirectory = "%s"' % exe_dir
        else:
            _ensure_vbs()
            vbs = _vbs_path()
            target_line = 'sc.TargetPath = "%s"' % wscript
            args_line = 'sc.Arguments = """%s"""' % vbs
            workdir_line = 'sc.WorkingDirectory = "%s"' % proj
        maker = os.path.join(os.environ.get("TEMP", proj), "_vi_make_lnk.vbs")
        lines = [
            'Set sh = CreateObject("WScript.Shell")',
            'Set sc = sh.CreateShortcut("%s")' % lnk,
            target_line,
            args_line,
            workdir_line,
            'sc.WindowStyle = 7',
            'sc.Description = "Voice Input auto start"',
            'sc.Save',
        ]
        with open(maker, "w", encoding="ascii") as f:
            f.write("\r\n".join(lines) + "\r\n")
        # CREATE_NO_WINDOW = 0x08000000(窓を出さない)
        subprocess.run([wscript, maker], creationflags=0x08000000, timeout=15)
        try:
            os.remove(maker)
        except Exception:
            pass
        return os.path.exists(lnk)
    except Exception:
        return False


# --- タブ1: 録音キー -------------------------------------------------------

def _build_hotkey_tab(parent):
    """録音キータブ。「キーを押して登録」方式。"""
    settings = _load_settings()
    state = {
        "label": settings.get("hotkey", "ctrl+alt"),
        "capturing": False,
        "seen": {},
        "held": set(),
        "order": [],
        "done": None,
    }

    ctk.CTkLabel(parent, text="録音に使うキーを登録します。",
                 font=FONT_BOLD, text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(18, 4))
    ctk.CTkLabel(
        parent,
        text="下の「キーを押して登録」を押してから、録音に使いたいキーを\n"
             "実際に押してください。「Ctrl+Alt」のような組み合わせも、\n"
             "同時に押せばそのまま登録できます。\n"
             "※ Alt 単体は Windows の仕様で反応しないことが多いです。\n"
             "  Ctrl 単体も Ctrl+C 等と重なります。「Ctrl+Alt」のような\n"
             "  組み合わせを推奨します。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM,
    ).pack(anchor="w", padx=20)

    card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                        border_color=BORDER, border_width=1)
    card.pack(fill="x", padx=20, pady=14)

    cur = ctk.CTkLabel(
        card,
        text="現在の録音キー: " + (pretty_key_label(state["label"])
                                  or state["label"]),
        font=FONT, text_color=TEXT)
    cur.pack(anchor="w", padx=16, pady=(14, 4))

    note = ctk.CTkLabel(card, text="", justify="left", anchor="w",
                        font=FONT_SM, text_color=MUTED)
    note.pack(anchor="w", padx=16)

    btn_row = ctk.CTkFrame(card, fg_color="transparent")
    btn_row.pack(anchor="w", padx=16, pady=(10, 14))
    capture_btn = _accent_btn(btn_row, "キーを押して登録", None, width=160)
    capture_btn.pack(side="left")
    save_btn = _ghost_btn(btn_row, "この録音キーを保存", None, width=160,
                          state="disabled")
    save_btn.pack(side="left", padx=8)

    ctk.CTkLabel(parent,
                 text="※ 録音キーの変更はツールを再起動すると反映されます。",
                 text_color="#a05000", font=FONT_SM).pack(
                     anchor="w", padx=20, pady=4)

    def show_eval(names):
        level, msg = evaluate_hotkey(names)
        note.configure(text=msg, text_color=LEVEL_COLORS.get(level, MUTED))

    init_names = [p.strip() for p in state["label"].split("+") if p.strip()]
    if init_names:
        show_eval(init_names)

    def begin_capture():
        try:
            import keyboard
        except ImportError:
            note.configure(
                text="keyboard ライブラリが見つかりません。"
                     "セットアップ.bat を実行してください。",
                text_color="#c00000")
            return
        state.update(capturing=True, seen={}, held=set(), order=[], done=None)
        capture_btn.configure(state="disabled")
        save_btn.configure(state="disabled")
        cur.configure(text="録音に使いたいキーを押してください…")
        note.configure(text="(押して離すと登録されます)", text_color=MUTED)

        def on_key(e):
            try:
                if e.event_type == "down":
                    if e.scan_code not in state["seen"]:
                        state["seen"][e.scan_code] = e.name or f"key{e.scan_code}"
                    if e.scan_code not in state["held"]:
                        state["held"].add(e.scan_code)
                        state["order"].append(e.scan_code)
                elif e.event_type == "up":
                    state["held"].discard(e.scan_code)
                    if state["order"] and not state["held"]:
                        state["done"] = list(state["order"])
                        keyboard.unhook(on_key)
            except Exception:
                pass

        keyboard.hook(on_key)
        parent.after(120, poll_capture)

    def poll_capture():
        if not state["capturing"]:
            return
        if state["done"] is None:
            parent.after(120, poll_capture)
            return
        state["capturing"] = False
        scans = state["done"]
        names = [state["seen"].get(sc, f"key{sc}") for sc in scans]
        label = "+".join(names)
        state["label"] = label
        pretty = pretty_key_label(label) or label
        cur.configure(text="登録するキー: " + pretty)
        show_eval(names)
        capture_btn.configure(state="normal")
        save_btn.configure(state="normal")

    def on_save():
        data = _load_settings()
        data["hotkey"] = state["label"]
        data.pop("hotkey_scan_codes", None)
        try:
            _save_settings(data)
        except Exception as e:
            messagebox.showerror("保存失敗", f"設定の保存に失敗しました:\n{e}")
            return
        pretty = pretty_key_label(state["label"]) or state["label"]
        messagebox.showinfo(
            "保存しました",
            f"録音キーを「{pretty}」にしました。\n"
            f"ツールを再起動すると反映されます。")

    capture_btn.configure(command=begin_capture)
    save_btn.configure(command=on_save)

    # --- 通知音(完了音)のオン/オフ ------------------------------------
    ctk.CTkLabel(parent, text="通知音", font=FONT_BOLD, text_color=TEXT).pack(
        anchor="w", padx=20, pady=(16, 2))
    snd_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                            border_color=BORDER, border_width=1)
    snd_card.pack(fill="x", padx=20, pady=(0, 10))
    snd_var = tk.BooleanVar(
        value=bool(_load_settings().get("sound_feedback", True)))

    def on_snd_toggle():
        s = _load_settings()
        s["sound_feedback"] = bool(snd_var.get())
        _save_settings(s)

    ctk.CTkSwitch(
        snd_card,
        text="話し終えて文字が入った時に「完了音」を鳴らす",
        variable=snd_var, command=on_snd_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(12, 2))
    ctk.CTkLabel(
        snd_card,
        text="ONで、入力が終わった合図にスピーカーから短い音が鳴ります(開始音は\n"
             "鳴りません)。OFFで完全に無音。次の音声入力からすぐ反映します。",
        justify="left", anchor="w", text_color=MUTED,
        font=("Yu Gothic UI", 10)).pack(anchor="w", padx=12, pady=(0, 6))

    def on_test_sound():
        try:
            import feedback
            feedback.recording_done()
        except Exception:
            pass

    _ghost_btn(snd_card, "音を試す", on_test_sound, width=120).pack(
        anchor="w", padx=12, pady=(0, 12))

    # --- Windows 起動時の自動起動 ----------------------------------------
    ctk.CTkLabel(parent, text="起動", font=FONT_BOLD, text_color=TEXT).pack(
        anchor="w", padx=20, pady=(16, 2))
    auto_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                             border_color=BORDER, border_width=1)
    auto_card.pack(fill="x", padx=20, pady=(0, 14))
    autostart_var = tk.BooleanVar(value=_autostart_enabled())
    auto_msg = ctk.CTkLabel(auto_card, text="", font=("Yu Gothic UI", 10),
                            text_color=MUTED, anchor="w", justify="left")

    def _refresh_auto_msg():
        if autostart_var.get():
            auto_msg.configure(
                text="ON: PCを起動すると自動で裏に常駐します(窓は出ません)。\n"
                     "アイコンをクリックしなくても、すぐ音声入力できます。",
                text_color=MUTED)
        else:
            auto_msg.configure(
                text="OFF: 自動では起動しません。使う時はデスクトップの\n"
                     "「音声入力ツール」アイコンから起動します。",
                text_color=MUTED)

    def on_autostart_toggle():
        ok = _set_autostart(bool(autostart_var.get()))
        if not ok:
            autostart_var.set(_autostart_enabled())
            auto_msg.configure(
                text="設定の変更に失敗しました。もう一度お試しください。",
                text_color="#c00000")
            return
        _refresh_auto_msg()

    ctk.CTkSwitch(
        auto_card,
        text="Windows起動時に自動で起動する(窓なしで裏に常駐・おすすめON)",
        variable=autostart_var, command=on_autostart_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(12, 2))
    auto_msg.pack(anchor="w", padx=12, pady=(0, 12))
    _refresh_auto_msg()

    # --- 使うマイク ---------------------------------------------------
    # 2026-07-20 旦那様報告: Bluetooth ヘッドセット(OneOdio A70)を使うと
    # 通話モード(狭帯域・低音質)に固定され、語尾が潰れる/変な文字になる。
    # 有線・USBマイクなら常に高音質固定なので、そちらを選べるようにする。
    ctk.CTkLabel(parent, text="使うマイク", font=FONT_BOLD,
                 text_color=TEXT).pack(anchor="w", padx=20, pady=(16, 2))
    mic_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                            border_color=BORDER, border_width=1)
    mic_card.pack(fill="x", padx=20, pady=(0, 14))
    ctk.CTkLabel(
        mic_card,
        text="Bluetooth ヘッドセットのマイクは通話モード(狭帯域・低音質)に\n"
             "固定されるため、語尾の認識精度が落ちます。有線・USB・内蔵マイクを\n"
             "選ぶと改善します(空欄=Windowsの既定マイクをそのまま使う)。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM).pack(
            anchor="w", padx=12, pady=(12, 6))

    # 選択肢から除く「マイクとして選んでも意味が無い」デバイス。
    # ・録音デバイス以外を映すもの(サウンドマッパー/ステレオミキサー/PCスピーカー
    #   はスピーカー出力のループバックで、話し声を拾うマイクではない)
    # ・改行や制御文字を含む内部ドライバ名(Bluetooth の WDM-KS 経路などで、
    #   実質同じマイクが MME/DirectSound で既に選べているため冗長)
    _MIC_EXCLUDE_SUBSTR = (
        "サウンド マッパー", "ステレオ ミキサー", "PC スピーカー",
        "プライマリ サウンド キャプチャ",
    )

    def _list_input_devices():
        """マイクの選択肢を集める。 名前の重複(複数の接続方式で同じマイクが
        見える)はまとめ、 スピーカー系ループバックや壊れた内部名は除外する。"""
        try:
            import sounddevice as sd
        except Exception:
            return []
        names, seen = [], set()
        try:
            for dev in sd.query_devices():
                if dev.get("max_input_channels", 0) <= 0:
                    continue
                nm = str(dev.get("name", "")).strip()
                if not nm or nm in seen:
                    continue
                if "\n" in nm or "\r" in nm:
                    continue  # 改行混じりの壊れたドライバ内部名
                if any(bad in nm for bad in _MIC_EXCLUDE_SUBSTR):
                    continue
                seen.add(nm)
                names.append(nm)
        except Exception:
            pass
        return names

    def _is_bt_headset(name):
        low = (name or "").lower()
        return ("hands-free" in low or "handsfree" in low
                or "headset" in low or "ヘッドセット" in (name or ""))

    mic_names = _list_input_devices()
    mic_options = ["(Windowsの既定マイクを使う)"] + mic_names
    saved_mic = str(_load_settings().get("input_device", "") or "").strip()
    # 保存値は「名前の一部」一致方式(streaming.py と同じ)なので、まず完全一致、
    # 無ければ部分一致するデバイス名を選択肢の初期値に充てる。
    initial = mic_options[0]
    if saved_mic:
        if saved_mic in mic_names:
            initial = saved_mic
        else:
            hit = next((n for n in mic_names
                       if saved_mic.lower() in n.lower()), None)
            initial = hit if hit else f"{saved_mic}(未検出)"
            if initial not in mic_options:
                mic_options.append(initial)

    mic_note = ctk.CTkLabel(mic_card, text="", justify="left", anchor="w",
                            text_color=MUTED, font=FONT_SM)

    def _refresh_mic_note(name):
        if name == mic_options[0]:
            mic_note.configure(
                text="Windowsの「既定のマイク」をそのまま使います。",
                text_color=MUTED)
        elif _is_bt_headset(name):
            mic_note.configure(
                text="⚠ Bluetooth ヘッドセットです。語尾の精度が落ちやすい"
                     "接続方式です。可能なら有線・USBマイクを推奨します。",
                text_color="#a05000")
        else:
            mic_note.configure(text="このマイクを使います。", text_color=MUTED)

    def on_mic_change(choice):
        s = _load_settings()
        if choice == mic_options[0]:
            s["input_device"] = ""
        else:
            s["input_device"] = choice.replace("(未検出)", "")
        _save_settings(s)
        _refresh_mic_note(choice)

    mic_menu = ctk.CTkOptionMenu(
        mic_card, values=mic_options, command=on_mic_change,
        fg_color=CARD, button_color=BORDER, button_hover_color=ACCENT,
        text_color=TEXT, dropdown_text_color=TEXT, font=FONT_SM, width=340)
    mic_menu.set(initial)
    mic_menu.pack(anchor="w", padx=12, pady=(0, 4))
    _refresh_mic_note(initial)
    mic_note.pack(anchor="w", padx=12, pady=(0, 4))

    def on_mic_refresh():
        new_names = _list_input_devices()
        new_options = [mic_options[0]] + new_names
        cur = mic_menu.get()
        if cur not in new_options:
            new_options.append(cur)
        mic_menu.configure(values=new_options)

    ctk.CTkLabel(
        mic_card,
        text="※ マイクの変更はツールを再起動すると反映されます。"
             "マイクを後から繋いだ時は「一覧を更新」を押してください。",
        text_color="#a05000", font=FONT_SM).pack(
            anchor="w", padx=12, pady=(0, 2))
    _ghost_btn(mic_card, "一覧を更新", on_mic_refresh, width=110).pack(
        anchor="w", padx=12, pady=(0, 12))


# --- タブ2: 辞書(統合) --------------------------------------------------

def _build_unified_dictionary_tab(parent):
    """言い換え / 記号・単位 / 建設用語 + AI自動登録 を一元管理する。

    AI が自動で覚えた項目(origin=learning)は「AI自動登録」カテゴリとして
    ここに表示・蓄積する。1回で覚えた仮登録は「(確認中)」と表示する。
    データは replacements.json を共有し、保存時も全カテゴリを壊さない。
    """
    items, sym_meta, ct_metas = _load_unified_dictionary()
    state = {"filter": "すべて表示", "sort": "登録順", "search": "",
             "displayed": []}

    SORT_OPTIONS = [
        "登録順",
        "聞こえ方 昇順", "聞こえ方 降順",
        "出したい文字 昇順", "出したい文字 降順",
    ]

    def get_filter_categories():
        return ["すべて表示"] + _all_categories(items)

    def get_add_categories():
        # 「AI自動登録」は学習が自動で増やす枠なので手動追加先には出さない。
        return [c for c in _all_categories(items) if c != "AI自動登録"]

    ctk.CTkLabel(parent, text="辞書(あなたが登録した言い換え・記号・建設用語)",
                 font=FONT_BOLD, text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(16, 2))
    ctk.CTkLabel(
        parent,
        text="カテゴリで絞り込み、追加・削除・一括貼り付けがここから全部できます。\n"
             "チェックで適用/解除(建設用語のみ)。言い換え/記号・単位は常に適用中。\n"
             "AI が自動で覚えた言い換えは「AI自動登録」カテゴリにここで蓄積されます。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM,
    ).pack(anchor="w", padx=20, pady=(0, 8))

    # フィルタ + 検索 + 並べ替え
    ctrl = ctk.CTkFrame(parent, fg_color="transparent")
    ctrl.pack(fill="x", padx=20, pady=(0, 6))

    search_var = tk.StringVar()
    search_entry = ctk.CTkEntry(ctrl, textvariable=search_var, width=210,
                                height=34, font=FONT,
                                placeholder_text="検索(聞こえ方/出したい文字)")
    search_entry.pack(side="left")

    def _menu(parent_w, var, values, cb, width):
        return ctk.CTkOptionMenu(
            parent_w, variable=var, values=values, width=width, height=34,
            font=FONT, fg_color=CARD, text_color=TEXT, button_color=ACCENT,
            button_hover_color=ACCENT_HOVER, dropdown_fg_color=CARD,
            dropdown_text_color=TEXT, dropdown_hover_color=CHIP_BG, command=cb)

    filter_var = tk.StringVar(value="すべて表示")
    filter_menu = _menu(ctrl, filter_var, get_filter_categories(),
                        lambda _v: on_filter_change(), 130)
    filter_menu.pack(side="left", padx=6)

    sort_var = tk.StringVar(value="登録順")
    sort_menu = _menu(ctrl, sort_var, SORT_OPTIONS,
                      lambda _v: on_sort_change(), 150)
    sort_menu.pack(side="left")

    count_label = ctk.CTkLabel(ctrl, text="", text_color=MUTED, font=FONT_SM)
    count_label.pack(side="left", padx=10)

    # 一覧(学習タブと同じ黄色チェックの行UI)
    scroll = ctk.CTkScrollableFrame(parent, fg_color=CARD, corner_radius=12,
                                    border_color=BORDER, border_width=1)
    scroll.pack(fill="both", expand=True, padx=20)

    def save_all():
        _save_unified_dictionary(items, sym_meta, ct_metas)

    def _visible_items():
        filt = state["filter"]
        q = state["search"].strip().lower()
        out = []
        for it in items:
            # AI 学習分は「AI自動登録」カテゴリとしてこの辞書タブに表示する
            # (1回で覚えた仮登録は「(確認中)」表示。不要なら削除で外す)。
            if filt != "すべて表示" and it.get("category") != filt:
                continue
            if q and q not in str(it.get("wrong", "")).lower() \
                    and q not in str(it.get("right", "")).lower():
                continue
            out.append(it)
        sk = state["sort"]
        if sk == "聞こえ方 昇順":
            out.sort(key=lambda x: x.get("wrong", ""))
        elif sk == "聞こえ方 降順":
            out.sort(key=lambda x: x.get("wrong", ""), reverse=True)
        elif sk == "出したい文字 昇順":
            out.sort(key=lambda x: x.get("right", ""))
        elif sk == "出したい文字 降順":
            out.sort(key=lambda x: x.get("right", ""), reverse=True)
        return out

    def on_row_toggle(it, var):
        if it.get("source") != "construction":
            # 言い換え/記号・単位は常に適用中。チェックは戻す。
            var.set(True)
            messagebox.showinfo(
                "情報",
                "言い換え/記号・単位は常に適用中です。\n"
                "不要なら右の「削除」で外してください。")
            return
        it["enabled"] = bool(var.get())
        try:
            save_all()
        except Exception as e:
            it["enabled"] = not it["enabled"]
            var.set(it["enabled"])
            messagebox.showerror("保存失敗", f"保存に失敗しました:\n{e}")

    def on_row_delete(it):
        if not messagebox.askyesno(
            "削除の確認",
            f"「{it.get('wrong')} → {it.get('right')}」を辞書から消します。"
            "よろしいですか?"):
            return
        try:
            items.remove(it)
        except ValueError:
            return
        try:
            save_all()
        except Exception as e:
            items.append(it)
            messagebox.showerror("保存失敗", f"保存に失敗しました:\n{e}")
            return
        refresh()

    def refresh():
        for w in scroll.winfo_children():
            w.destroy()
        shown = _visible_items()
        state["displayed"] = shown
        if not shown:
            ctk.CTkLabel(scroll, text="  該当する項目はありません。",
                         text_color=MUTED, font=FONT_SM).pack(
                             anchor="w", pady=8)
        for it in shown:
            row = ctk.CTkFrame(scroll, fg_color="transparent")
            row.pack(fill="x", pady=1)
            always_on = it.get("source") != "construction"
            var = tk.BooleanVar(value=True if always_on
                                else bool(it.get("enabled", False)))
            cat = it.get("category", "")
            mark = "  (確認中)" if it.get("provisional") else ""
            ctk.CTkCheckBox(
                row,
                text=f"[{cat}]  {it.get('wrong', '')}  →  "
                     f"{it.get('right', '')}{mark}",
                variable=var, font=FONT, text_color=TEXT, fg_color=ACCENT,
                hover_color=ACCENT_HOVER, checkmark_color=ACCENT_TEXT,
                command=lambda i=it, v=var: on_row_toggle(i, v)).pack(
                    side="left")
            _ghost_btn(row, "削除", lambda i=it: on_row_delete(i),
                       width=64).pack(side="right")
        count_label.configure(text=f"{len(shown)} 件 / 全 {len(items)} 件")

    # 検索は打鍵のたびに全描画すると重いので 250ms のディバウンス
    search_after = {"id": None}

    def _do_search():
        state["search"] = search_var.get()
        refresh()

    def on_search(_evt=None):
        if search_after["id"]:
            try:
                parent.after_cancel(search_after["id"])
            except Exception:
                pass
        search_after["id"] = parent.after(250, _do_search)

    search_entry.bind("<KeyRelease>", on_search)

    def on_filter_change():
        state["filter"] = filter_var.get()
        refresh()

    def on_sort_change():
        state["sort"] = sort_var.get()
        refresh()

    # 入力欄
    in_card = ctk.CTkFrame(parent, fg_color="transparent")
    in_card.pack(fill="x", padx=20, pady=(8, 4))
    e_wrong = ctk.CTkEntry(in_card, width=150, height=34, font=FONT,
                           placeholder_text="聞こえ方")
    e_wrong.grid(row=0, column=0, padx=(0, 6))
    e_right = ctk.CTkEntry(in_card, width=150, height=34, font=FONT,
                           placeholder_text="出したい文字")
    e_right.grid(row=0, column=1, padx=(0, 6))
    category_var = tk.StringVar(value="一般・建築")
    cat_menu = _menu(in_card, category_var, get_add_categories(), None, 130)
    cat_menu.grid(row=0, column=2, padx=(0, 6))
    e_note = ctk.CTkEntry(in_card, width=160, height=34, font=FONT,
                          placeholder_text="メモ(任意)")
    e_note.grid(row=0, column=3)

    def on_add():
        w = e_wrong.get().strip()
        r = e_right.get().strip()
        cat = category_var.get()
        note = e_note.get().strip()
        if not w or not r:
            messagebox.showwarning("未入力",
                                   "「聞こえ方」と「出したい文字」を入れてください。")
            return
        source, section = _category_to_source(cat)
        new_item = {"source": source, "category": cat, "wrong": w, "right": r,
                    "enabled": True, "section": section, "note": note}
        items.append(new_item)
        try:
            save_all()
        except Exception as e:
            items.pop()
            messagebox.showerror("保存失敗", f"保存に失敗しました:\n{e}")
            return
        e_wrong.delete(0, tk.END)
        e_right.delete(0, tk.END)
        e_note.delete(0, tk.END)
        refresh()
        e_wrong.focus()

    def _bulk_targets():
        return [it for it in state["displayed"]
                if it.get("source") == "construction"]

    def _scope_name():
        filt = state["filter"]
        return ("表示中の建設用語" if filt == "すべて表示"
                else f"カテゴリ「{filt}」")

    def on_bulk_enable():
        targets = _bulk_targets()
        if not targets:
            messagebox.showinfo(
                "情報",
                f"「{state['filter']}」に許可/拒否を切り替えられる項目はありません。\n"
                "(言い換え/記号・単位は常に適用中で、削除でのみ外せます。)")
            return
        if not messagebox.askyesno(
            "一括許可",
            f"{_scope_name()} {len(targets)} 件をすべて『適用中』にします。"
            "よろしいですか?"):
            return
        for it in targets:
            it["enabled"] = True
        try:
            save_all()
        except Exception as e:
            messagebox.showerror("保存失敗", f"保存に失敗しました:\n{e}")
        refresh()

    def on_bulk_disable():
        targets = _bulk_targets()
        if not targets:
            messagebox.showinfo(
                "情報",
                f"「{state['filter']}」に許可/拒否を切り替えられる項目はありません。")
            return
        if not messagebox.askyesno(
            "一括拒否",
            f"{_scope_name()} {len(targets)} 件をすべて『未適用』にします。"
            "よろしいですか?"):
            return
        for it in targets:
            it["enabled"] = False
        try:
            save_all()
        except Exception as e:
            messagebox.showerror("保存失敗", f"保存に失敗しました:\n{e}")
        refresh()

    def refresh_combos_and_list():
        new_filter_cats = get_filter_categories()
        new_add_cats = get_add_categories()
        filter_menu.configure(values=new_filter_cats)
        cat_menu.configure(values=new_add_cats)
        if state["filter"] not in new_filter_cats:
            state["filter"] = "すべて表示"
            filter_var.set("すべて表示")
        if category_var.get() not in new_add_cats:
            default_cat = ("一般・建築" if "一般・建築" in new_add_cats
                           else (new_add_cats[0] if new_add_cats else ""))
            category_var.set(default_cat)
        refresh()

    def on_bulk_paste():
        _open_unified_bulk_paste_dialog(parent, items, save_all,
                                        refresh_combos_and_list)

    def on_manage_categories():
        _open_category_manager_dialog(parent, items, save_all,
                                      refresh_combos_and_list)

    def on_more(choice):
        more_var.set("その他")
        if choice == "カテゴリ管理…":
            on_manage_categories()
        elif choice == "表示中をすべて許可":
            on_bulk_enable()
        elif choice == "表示中をすべて拒否":
            on_bulk_disable()

    # ボタン群(集約: 追加 + まとめて貼り付け + その他メニュー)
    btns = ctk.CTkFrame(parent, fg_color="transparent")
    btns.pack(fill="x", padx=20, pady=(6, 4))
    _accent_btn(btns, "追加", on_add, width=90).pack(side="left")
    _ghost_btn(btns, "まとめて貼り付け", on_bulk_paste, width=150).pack(
        side="left", padx=6)
    more_var = tk.StringVar(value="その他")
    more_menu = _menu(btns, more_var,
                      ["カテゴリ管理…", "表示中をすべて許可", "表示中をすべて拒否"],
                      on_more, 110)
    more_menu.pack(side="right")

    ctk.CTkLabel(
        parent,
        text="※ 変更は次の音声入力からすぐ反映されます。"
             "チェックで適用/解除(建設用語のみ)。\n"
             "※「表示中をすべて許可/拒否」はカテゴリで絞り込んだ範囲だけが対象です。",
        text_color=MUTED, justify="left", anchor="w", font=FONT_SM,
    ).pack(anchor="w", padx=20, pady=(2, 8))

    refresh()
    return {"items": items, "save_all": save_all,
            "refresh": refresh_combos_and_list,
            "categories": get_add_categories}


# --- タブ: ルールの見える化(読み取り専用) -----------------------------

# 句読点・整形の自動ルール。(見出し, before, after, 補足) の読み取り専用説明。
# formatter.py の実装と対応(add_question_marks / add_conjunction_comma /
# add_quotes_for_citations / フィラー削除 / 句読点ダブり正規化)。
_PUNCT_RULES = [
    ("疑問の語尾を「?」にする",
     "元気ですか。", "元気ですか?",
     "「か・かな・かね・っけ」で終わる文を疑問とみなす。「りんごとか」は対象外。"),
    ("接続詞の後ろに読点「、」を打つ",
     "だから明日行きます", "だから、明日行きます",
     "文頭の接続詞(だから/しかし 等)の直後に「、」を補う。文中の同じ語は触らない。"),
    ("引用を「」で囲む",
     "こうすべきだ。と思った", "「こうすべきだ。」と思った",
     "「…。と。」「…と思った/と言った」の直前の一文を引用とみなして囲む。"),
    ("「えー」「あのー」等のフィラーを消す",
     "えーと、明日の現場は", "明日の現場は",
     "話し言葉のつなぎ語を除去する。残った余分な「、」も整える。"),
    ("句読点・記号のダブりを整える",
     "わかりました。。", "わかりました。",
     "「。。」「、。」や連続スペースなど、重複した区切りを1つに正規化する。"),
]


def _build_rules_viewer_tab(parent):
    """このツールが自動でやっている整形・言い換えの全ルールを一覧で見せる。

    読み取り専用。入力処理には一切触れず、タブを開いた時だけ描画する
    (起動時間・入力速度に影響しない)。編集は「辞書」タブで行う。
    戻り値: タブを開くたびに最新化する再描画関数。
    """
    ctk.CTkLabel(parent, text="ルールの見える化(読むだけ)",
                 font=FONT_BOLD, text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(16, 2))
    ctk.CTkLabel(
        parent,
        text="このツールが音声入力に対して自動でやっていることの一覧です。\n"
             "ここは閲覧専用。変更は「辞書」タブ、ON/OFFは「AI設定」タブで。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM).pack(
            anchor="w", padx=20, pady=(0, 6))

    scroll = ctk.CTkScrollableFrame(parent, fg_color=CREAM, corner_radius=0)
    scroll.pack(fill="both", expand=True, padx=12, pady=(0, 8))

    def _read_json(path, default):
        try:
            return json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception:
            return default

    def _section(title):
        ctk.CTkLabel(scroll, text=title, font=("Yu Gothic UI", 13, "bold"),
                     text_color=TEXT).pack(anchor="w", padx=8, pady=(12, 4))

    def _example_card(title, before, after, note):
        card = ctk.CTkFrame(scroll, fg_color=CARD, corner_radius=12,
                            border_color=BORDER, border_width=1)
        card.pack(fill="x", padx=8, pady=3)
        ctk.CTkLabel(card, text="● " + title, font=("Yu Gothic UI", 12, "bold"),
                     text_color=TEXT, anchor="w", justify="left").pack(
                         anchor="w", padx=12, pady=(8, 2))
        ex = ctk.CTkFrame(card, fg_color="transparent")
        ex.pack(anchor="w", padx=12, pady=(0, 2))
        ctk.CTkLabel(ex, text=before, font=FONT_SM, text_color=MUTED).pack(
            side="left")
        ctk.CTkLabel(ex, text="  →  ", font=FONT_SM, text_color=ACCENT_TEXT).pack(
            side="left")
        ctk.CTkLabel(ex, text=after, font=("Yu Gothic UI", 11, "bold"),
                     text_color=TEXT).pack(side="left")
        if note:
            ctk.CTkLabel(card, text=note, font=("Yu Gothic UI", 10),
                         text_color=MUTED, anchor="w", justify="left",
                         wraplength=560).pack(anchor="w", padx=12, pady=(0, 8))

    def _info_card(text, accent=False):
        card = ctk.CTkFrame(scroll, fg_color=(AI_BG if accent else CARD),
                            corner_radius=12, border_color=BORDER, border_width=1)
        card.pack(fill="x", padx=8, pady=3)
        ctk.CTkLabel(card, text=text, font=FONT_SM,
                     text_color=(AI_TEXT if accent else TEXT),
                     anchor="w", justify="left", wraplength=580).pack(
                         anchor="w", padx=12, pady=8)

    def render():
        for w in scroll.winfo_children():
            w.destroy()

        settings = _read_json(SETTINGS, {})
        repl = _read_json(REPL, [])
        repl = repl if isinstance(repl, list) else []
        symbols = _read_json(SYMBOLS, {})
        construction = _read_json(CONSTRUCTION, {})

        manual = [r for r in repl if r.get("origin") != "learning"]
        learned = [r for r in repl if r.get("origin") == "learning"]
        sym_n = sum(1 for k in symbols if not str(k).startswith("_"))
        con_n = sum(1 for k in construction if not str(k).startswith("_"))
        q_on = bool(settings.get("add_question_marks", False))
        pstyle_on = bool(settings.get("punctuation_personalize", True))
        style_ex = _read_json(CONFIG / "punct_style.json", {})
        style_n = len(style_ex.get("examples", [])) \
            if isinstance(style_ex, dict) else 0

        # --- 概要 ---
        _section("いまの状態")
        _info_card(
            f"挿入時の句読点(その場で 、。? を打つ): "
            f"{'ON 稼働中' if q_on else 'OFF(推敲側で整えます)'}\n"
            f"句読点をあなたの文体に寄せる: "
            f"{'ON' if pstyle_on else 'OFF'}(お手本 {style_n} 文を学習中)\n"
            f"言い換えルール: 手動 {len(manual)} 件 + AIが覚えた {len(learned)} 件 "
            f"= 合計 {len(manual) + len(learned)} 件\n"
            f"記号・単位: {sym_n} 件 / 建設用語: {con_n} 件",
            accent=True)

        # --- 句読点・整形ルール ---
        _section("句読点・整形の自動ルール(話した文をこう整えます)")
        for title, before, after, note in _PUNCT_RULES:
            _example_card(title, before, after, note)

        # 言い換えの中身は「辞書」タブで一元管理(AI学習分は AI自動登録 カテゴリ)。
        _section("言い換え(誤変換の自動修正)")
        _info_card(
            f"言い換えルールは「辞書」タブで見られます。\n"
            f"AI が覚えた分({len(learned)} 件)は「辞書」タブの "
            f"「AI自動登録」カテゴリに蓄積され、使うほど増えていきます。")

        # --- 学習のしくみ(どんな時に覚えるか)を明記 ---
        auto_on = bool(settings.get("learning_auto", True))
        fast_on = bool(settings.get("learning_fast_track", True))
        fast_len = int(settings.get("learning_fast_min_len", 4))
        min_cnt = int(settings.get("learning_auto_min_count", 2))
        _section("学習のしくみ(どんな時に覚えるか)")
        _info_card(
            f"いまの設定: 自動で覚える={'ON' if auto_on else 'OFF'} / "
            f"早期登録={'ON' if fast_on else 'OFF'}(長さ{fast_len}文字以上) / "
            f"通常は同じ誤りが{min_cnt}回出たら登録",
            accent=True)
        _example_card(
            "長い固有名詞は1回で覚える(早期登録)",
            "コンクルート", "コンクリート",
            f"{fast_len}文字以上の語は別の語に紛れにくいので、1回出ただけで自動登録。"
            "(早期登録OFFなら従来どおり繰り返し必要)")
        _example_card(
            "短い語・略語は繰り返し出たら覚える",
            "sns", "SNS",
            f"短い語は全文置換で誤爆しやすいので、{min_cnt}回出てから登録する(安全側)。")
        _info_card(
            "1回で覚えた長い語は『(確認中)』の仮登録です。すぐ効きますが、\n"
            "その変換結果が後の推敲でさらに直されたら、誤りとみなして自動で取り消します"
            "(間違いを引きずりません)。同じ変換がもう一度出れば確定します。\n"
            "次の場合は自動で覚えません(安定するまで待つ・誤爆防止):\n"
            "・同じ聞こえ方で正解が割れている(推敲のたびに結果が違う)\n"
            "・手で登録済みの辞書と食い違う(競合)/ 数字だけ・2文字以下の語")

    render()
    return render


# --- タブ4: AI設定(推敲AI(Ollama)の設定) -------------------------------

def _build_ai_tab(parent):
    """推敲AI(Ollama)の設定だけを集めた専用タブ。

    学習タブの末尾に埋もれて触れなかったスイッチ・ボタンをここに独立させる。
    常駐中に裏で回す「① 自動推敲」「② 自動学習」のスイッチと、Ollama 導入・
    手動推敲のボタンを置く。今の稼働状態は右上アイコン下に常時表示。
    """
    ctk.CTkLabel(parent, text="推敲AI(Ollama)の設定",
                 font=FONT_BOLD, text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(16, 2))
    ctk.CTkLabel(
        parent,
        text="話した履歴を PC内の無料AI「Ollama」が読み直し、誤変換を見つけます\n"
             "(完全ローカル・ネット送信なし)。下の ① と ② は別の機能です。\n"
             "今どう動いているかは、右上アイコンの下にも常に表示しています。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM).pack(
            anchor="w", padx=20, pady=(0, 8))

    # --- 挿入時の句読点(ルール・高速・AIなし・遅延ゼロ)------------------
    ctk.CTkLabel(parent, text="挿入時の句読点(その場で打つ文字)",
                 font=("Yu Gothic UI", 12, "bold"), text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(2, 2))
    q_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                          border_color=BORDER, border_width=1)
    q_card.pack(fill="x", padx=20, pady=(0, 8))
    q_var = tk.BooleanVar(
        value=bool(_load_settings().get("add_question_marks", False)))

    def on_q_toggle():
        s = _load_settings()
        s["add_question_marks"] = bool(q_var.get())
        _save_settings(s)

    ctk.CTkSwitch(
        q_card,
        text="話した直後の文字に句読点(、。?)をルールで付ける(高速・AIなし)",
        variable=q_var, command=on_q_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(10, 2))
    ctk.CTkLabel(
        q_card,
        text="ONにすると、その場で挿入される文に文の区切り(。)や ? が付きます。\n"
             "ルール判定なので時々位置がズレます。OFFなら句読点なしで挿入(推敲側で整います)。\n"
             "AIは使わないので入力速度(0.8秒目標)は変わりません。次の音声入力から反映。",
        justify="left", anchor="w", text_color=MUTED,
        font=("Yu Gothic UI", 10)).pack(anchor="w", padx=12, pady=(0, 10))

    # --- 現在の状態(エラー時は内容と対処をここに表示)--------------------
    STATUS_COLORS = {"ok": "#1a7000", "warn": "#a05000",
                     "off": MUTED, "bad": "#c00000"}
    state_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                              border_color=BORDER, border_width=1)
    state_card.pack(fill="x", padx=20, pady=(2, 8))
    state_big = ctk.CTkLabel(state_card, text="● 状態を確認中…",
                             font=("Yu Gothic UI", 14, "bold"),
                             text_color=MUTED, anchor="w", justify="left")
    state_big.pack(anchor="w", padx=12, pady=(10, 2))
    state_detail = ctk.CTkLabel(state_card, text="", text_color=TEXT,
                                font=FONT_SM, anchor="w", justify="left")
    state_detail.pack(anchor="w", padx=12, pady=(0, 10))

    def update_status(level, msg, detail):
        state_big.configure(text="● " + msg,
                            text_color=STATUS_COLORS.get(level, MUTED))
        state_detail.configure(text=detail,
                               text_color=("#c00000" if level == "bad"
                                           else TEXT))

    ai_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                           border_color=BORDER, border_width=1)
    ai_card.pack(fill="x", padx=20, pady=(2, 12))

    ap_var = tk.BooleanVar(
        value=bool(_load_settings().get("auto_proofread", True)))

    def on_ap_toggle():
        s = _load_settings()
        turned_on = bool(ap_var.get())
        s["auto_proofread"] = turned_on
        _save_settings(s)
        # ①をONにした瞬間、Ollamaも裏で起こす(常駐の再起動を待たせない)
        if turned_on:
            import platform_compat
            threading.Thread(
                target=platform_compat.ensure_ollama_running,
                daemon=True).start()

    ctk.CTkSwitch(
        ai_card,
        text="① 話した内容を自動で推敲する(常駐中・話していない時に裏で)",
        variable=ap_var, command=on_ap_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(12, 2))

    auto_var = tk.BooleanVar(
        value=bool(_load_settings().get("learning_auto", True)))

    def on_auto_toggle():
        s = _load_settings()
        s["learning_auto"] = bool(auto_var.get())
        _save_settings(s)

    ctk.CTkSwitch(
        ai_card,
        text="② 推敲で見つけた誤変換を自動で辞書に覚えさせる",
        variable=auto_var, command=on_auto_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(0, 4))

    fast_var = tk.BooleanVar(
        value=bool(_load_settings().get("learning_fast_track", True)))

    def on_fast_toggle():
        s = _load_settings()
        s["learning_fast_track"] = bool(fast_var.get())
        _save_settings(s)

    ctk.CTkSwitch(
        ai_card,
        text="③ 長い固有名詞は1回で覚える(早期登録・短い語は誤爆防止で従来どおり)",
        variable=fast_var, command=on_fast_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(0, 4))

    pstyle_var = tk.BooleanVar(
        value=bool(_load_settings().get("punctuation_personalize", True)))

    def on_pstyle_toggle():
        s = _load_settings()
        s["punctuation_personalize"] = bool(pstyle_var.get())
        _save_settings(s)

    ctk.CTkSwitch(
        ai_card,
        text="④ 句読点をあなたの文体に寄せる(推敲が過去の文をお手本にする)",
        variable=pstyle_var, command=on_pstyle_toggle, font=FONT_SM,
        text_color=TEXT, progress_color=ACCENT).pack(
            anchor="w", padx=12, pady=(0, 4))

    ctk.CTkLabel(
        ai_card,
        text="①=推敲(材料づくり)をいつ回すか / ②=見つけた誤変換を勝手に登録するか。\n"
             "③=ON だと「コンクルート→コンクリート」のような長い語を1回で覚えます"
             "(短い語や略語は事故防止のため2回必要)。覚えすぎたら OFF で従来に戻せます。\n"
             "④=ON だと裏の推敲が、あなたの過去の文を見て句読点の付け方を真似します"
             "(その場の入力速度は不変。推敲が少し重ければ OFF に)。\n"
             "覚えた言い換えは「辞書」タブの『AI自動登録』カテゴリに溜まります。",
        justify="left", anchor="w", text_color=MUTED,
        font=("Yu Gothic UI", 10)).pack(anchor="w", padx=12, pady=(0, 6))

    ai_btns = ctk.CTkFrame(ai_card, fg_color="transparent")
    ai_btns.pack(fill="x", padx=12, pady=(0, 12))
    _ghost_btn(ai_btns, "Ollama を入れる ↗",
               lambda: webbrowser.open(OLLAMA_DOWNLOAD_URL), width=140).pack(
                   side="left")
    _ghost_btn(ai_btns, "モデル取得コマンドをコピー",
               _copy_pull_command, width=190).pack(side="left", padx=6)
    _accent_btn(ai_btns, "今すぐ推敲する",
                lambda: _run_proofread_now(True), width=130).pack(side="right")

    # --- ツールのアップデート(GitHub Releases から自動取得)-------------
    ctk.CTkLabel(parent, text="ツールのアップデート",
                 font=("Yu Gothic UI", 12, "bold"), text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(4, 2))
    up_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                           border_color=BORDER, border_width=1)
    up_card.pack(fill="x", padx=20, pady=(0, 12))
    ctk.CTkLabel(
        up_card,
        text="GitHub の最新版を確認し、新しければ自動で上書きします。\n"
             "設定・履歴・.venv は保護対象として触りません。",
        justify="left", anchor="w", text_color=MUTED,
        font=("Yu Gothic UI", 10)).pack(anchor="w", padx=12, pady=(10, 4))
    up_btns = ctk.CTkFrame(up_card, fg_color="transparent")
    up_btns.pack(fill="x", padx=12, pady=(0, 12))
    _accent_btn(up_btns, "アップデートを確認",
                lambda: _open_update_dialog(parent), width=160).pack(side="left")

    # --- 状態の見かた(説明文として常設)--------------------------------
    ctk.CTkLabel(parent, text="状態の見かた",
                 font=("Yu Gothic UI", 12, "bold"), text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(4, 2))
    legend_card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                               border_color=BORDER, border_width=1)
    legend_card.pack(fill="x", padx=20, pady=(0, 12))
    for lv, title, desc in STATUS_LEGEND:
        row = ctk.CTkFrame(legend_card, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=3)
        ctk.CTkLabel(row, text="●", font=("Yu Gothic UI", 13, "bold"),
                     text_color=STATUS_COLORS.get(lv, MUTED), width=18).pack(
                         side="left")
        ctk.CTkLabel(row, text=f"{title}: {desc}", text_color=TEXT,
                     font=FONT_SM, justify="left", anchor="w",
                     wraplength=620).pack(side="left", fill="x", expand=True)

    return update_status


# --- タブ5: 動作ログ(常駐本体のターミナル内容をここに表示) --------------

def _open_path(p):
    """ファイル/フォルダを既定アプリで開く(無ければ何もしない)。

    OS 差(Win: os.startfile / Mac: open コマンド)は platform_compat に集約。
    """
    try:
        if Path(p).exists():
            import platform_compat
            platform_compat.open_path(str(p))
    except Exception:
        pass


def _read_log_tail(path, max_lines=200, max_bytes=512 * 1024):
    """ログ末尾だけ読む(大きくても UI を軽く保つ)。"""
    try:
        size = path.stat().st_size
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            if size > max_bytes:
                f.seek(size - max_bytes)
                f.readline()  # 途中で切れた行は捨てる
            lines = f.readlines()
        return "".join(lines[-max_lines:])
    except Exception:
        return ""


def _build_status_tab(parent):
    """常駐本体(音声入力)の状態とログを表示する。

    黒いターミナル窓をやめた代わりに、起動状況・録音状態・「挿入」「速度」等の
    ログをこの画面で見られるようにする(Aqua Voice 流の常駐スタイル)。
    戻り値: 定期更新で呼ぶ refresh 関数。
    """
    ctk.CTkLabel(parent, text="動作ログ(音声入力の状態)",
                 font=FONT_BOLD, text_color=TEXT).pack(
                     anchor="w", padx=20, pady=(16, 2))
    ctk.CTkLabel(
        parent,
        text="以前は黒いターミナル窓に出ていた内容を、ここに表示します。\n"
             "起動しているか・録音中かどうか・挿入した文・処理速度が分かります。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM).pack(
            anchor="w", padx=20, pady=(0, 8))

    badges = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12,
                          border_color=BORDER, border_width=1)
    badges.pack(fill="x", padx=20, pady=(0, 8))
    live_label = ctk.CTkLabel(badges, text="● 確認中…",
                              font=("Yu Gothic UI", 13, "bold"),
                              text_color=MUTED)
    live_label.pack(side="left", padx=(12, 14), pady=10)
    state_label = ctk.CTkLabel(badges, text="",
                               font=("Yu Gothic UI", 13, "bold"),
                               text_color=MUTED)
    state_label.pack(side="left", pady=10)

    logbox = ctk.CTkTextbox(parent, font=("Consolas", 11), fg_color=CARD,
                            text_color=TEXT, border_color=BORDER,
                            border_width=1, wrap="none")
    logbox.pack(fill="both", expand=True, padx=20, pady=(0, 6))
    logbox.configure(state="disabled")

    def _inner():
        """CTkTextbox の中身(素の tk.Text)を取り出す。 選択範囲やスクロール位置は
        素の Text にしか無いため。 取れない実装でも動くよう本体を返して退避する。"""
        return getattr(logbox, "_textbox", logbox)

    def _copy_log():
        """表示中のログ全文をクリップボードへ入れる。

        ドラッグで選択しなくてもコピーできるようにする(自動更新と選択操作が
        競合して「コピーできない」という実害が出たため・2026-07-20 旦那様報告)。
        """
        try:
            data = _inner().get("1.0", "end-1c")
        except Exception:
            data = ""
        ok = False
        try:
            parent.clipboard_clear()
            parent.clipboard_append(data)
            parent.update_idletasks()  # クリップボードを確定させる
            ok = bool(data)
        except Exception:
            ok = False
        btn = copy_btn.get("w")
        if btn is not None:
            btn.configure(text="コピーしました" if ok else "コピー失敗")
            parent.after(1500, lambda: btn.configure(text="ログをコピー"))

    copy_btn = {"w": None}

    btns = ctk.CTkFrame(parent, fg_color="transparent")
    btns.pack(fill="x", padx=20, pady=(0, 10))
    _ghost_btn(btns, "ログ全文を開く",
               lambda: _open_path(APP_LOG), width=150).pack(side="left")
    copy_btn["w"] = _ghost_btn(btns, "ログをコピー", _copy_log, width=130)
    copy_btn["w"].pack(side="left", padx=(8, 0))
    ctk.CTkLabel(btns,
                 text="1.5秒ごとに自動更新します"
                      "(文字を選択している間は更新を止めるのでコピーできます)。",
                 text_color=MUTED, font=FONT_SM).pack(side="left", padx=10)

    STATE_MAP = {
        "recording": ("／ 録音中(話してOK)", "#c00000"),
        "busy": ("／ 処理中…", "#a05000"),
        "idle": ("／ 待機中", "#1a7000"),
    }

    # 直前に表示したログ本文。 変化が無い時は書き換えないための比較用。
    last_text = {"v": None}

    def refresh():
        import time
        live = False
        try:
            if HEARTBEAT.exists():
                ts = int((HEARTBEAT.read_text(encoding="utf-8").strip()
                          or "0"))
                live = (time.time() - ts) < 15
        except Exception:
            live = False
        if live:
            live_label.configure(text="● 常駐中(音声入力 待受)",
                                 text_color="#1a7000")
        else:
            live_label.configure(text="● 停止中(起動していません)",
                                 text_color="#c00000")
        st = ""
        try:
            st = OVERLAY_STATE_FILE.read_text(encoding="utf-8").strip()
        except Exception:
            st = ""
        if live and st in STATE_MAP:
            txt, col = STATE_MAP[st]
            state_label.configure(text=txt, text_color=col)
        else:
            state_label.configure(text="")
        text = _read_log_tail(APP_LOG) or (
            "  まだログがありません。\n"
            "  デスクトップの「音声入力ツール」から起動すると、"
            "ここに動作内容が出ます。")

        # 旦那様が選択中(コピーしようとしている)なら書き換えない。
        # 以前は 1.5 秒ごとに全消し→全入れ直しをしていたため、 ドラッグで
        # 選択してから Ctrl+C を押すまでの間に選択が消え、 コピーできなかった。
        try:
            if _inner().tag_ranges("sel"):
                return
        except Exception:
            pass
        # 内容が変わっていなければ触らない(無駄な再描画と選択消しを避ける)
        if text == last_text["v"]:
            return

        # 末尾を見ている時だけ末尾へ追従する。 上の方を読んでいる最中に
        # 勝手に末尾へ飛ばされると、 読んでいる箇所を見失うため。
        try:
            at_end = _inner().yview()[1] >= 0.999
        except Exception:
            at_end = True

        last_text["v"] = text
        logbox.configure(state="normal")
        logbox.delete("1.0", "end")
        logbox.insert("1.0", text)
        if at_end:
            logbox.see("end")
        logbox.configure(state="disabled")

    refresh()
    return refresh


# --- 一括貼り付けダイアログ(統合版) ------------------------------------

def _open_unified_bulk_paste_dialog(parent, items, save_func, refresh_cb):
    """カテゴリ指定付きの一括貼り付けダイアログ。"""
    dlg = ctk.CTkToplevel(parent)
    dlg.title("一括貼り付けで追加")
    dlg.geometry("600x480")
    dlg.configure(fg_color=CREAM)
    dlg.transient(parent.winfo_toplevel())
    dlg.after(60, dlg.lift)

    ctk.CTkLabel(
        dlg,
        text="Excel やスプレッドシートで「聞こえ方」「出したい文字」の2列を\n"
             "作ってコピー(Ctrl+C)してから、下の枠に貼り付け(Ctrl+V)、\n"
             "カテゴリを選んで「登録する」を押してください。\n"
             "区切りは Tab / 「→」/「->」/「,」/「、」/ 空白 を自動判定。",
        justify="left", anchor="w", text_color=TEXT, font=FONT_SM).pack(
            anchor="w", padx=16, pady=(14, 6))

    cat_frame = ctk.CTkFrame(dlg, fg_color="transparent")
    cat_frame.pack(anchor="w", padx=16, pady=(0, 4))
    ctk.CTkLabel(cat_frame, text="カテゴリ:", text_color=TEXT,
                 font=FONT).pack(side="left")
    cat_var = tk.StringVar(value="一般・建築")
    ctk.CTkOptionMenu(
        cat_frame, variable=cat_var, values=_all_categories(items),
        width=170, height=34, font=FONT, fg_color=CARD, text_color=TEXT,
        button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        dropdown_fg_color=CARD, dropdown_text_color=TEXT,
        dropdown_hover_color=CHIP_BG).pack(side="left", padx=6)

    text_area = ctk.CTkTextbox(dlg, height=210, font=LIST_FONT, fg_color=CARD,
                               text_color=TEXT, border_color=BORDER,
                               border_width=1)
    text_area.pack(fill="both", expand=True, padx=16, pady=6)

    msg_label = ctk.CTkLabel(dlg, text="", text_color=MUTED, font=FONT_SM,
                             justify="left", anchor="w")
    msg_label.pack(anchor="w", padx=16, pady=(2, 0))

    def do_register():
        raw = text_area.get("1.0", "end")
        pairs, skipped = _parse_bulk_paste(raw)
        if not pairs:
            msg_label.configure(
                text="登録できる行がありませんでした。"
                     "各行を 2列で貼り付けてください。",
                text_color="#c00000")
            return
        cat = cat_var.get()
        source, section = _category_to_source(cat)
        added = []
        for w, r in pairs:
            added.append({"source": source, "category": cat, "wrong": w,
                          "right": r, "enabled": True, "section": section,
                          "note": ""})
        items.extend(added)
        try:
            save_func()
        except Exception as e:
            for _ in range(len(added)):
                items.pop()
            msg_label.configure(text=f"保存に失敗しました:\n{e}",
                                text_color="#c00000")
            return
        refresh_cb()
        msg = f"{len(added)} 件をカテゴリ「{cat}」に登録しました。"
        if skipped:
            msg += f" {skipped} 行は形式が読めずスキップしました。"
        msg_label.configure(text=msg, text_color="#1a7000")
        text_area.delete("1.0", "end")

    btns = ctk.CTkFrame(dlg, fg_color="transparent")
    btns.pack(pady=10)
    _accent_btn(btns, "登録する", do_register, width=120).pack(
        side="left", padx=6)
    _ghost_btn(btns, "閉じる", dlg.destroy, width=120).pack(side="left", padx=6)

    text_area.focus()


# --- カテゴリ管理ダイアログ ----------------------------------------------

def _open_category_manager_dialog(parent, items, save_items, after_change_cb):
    """カテゴリの追加・削除を行うダイアログ。"""
    dlg = ctk.CTkToplevel(parent)
    dlg.title("カテゴリ管理")
    dlg.geometry("520x560")
    dlg.configure(fg_color=CREAM)
    dlg.transient(parent.winfo_toplevel())
    dlg.after(60, dlg.lift)

    ctk.CTkLabel(dlg, text="カテゴリの追加・削除", font=FONT_BOLD,
                 text_color=TEXT).pack(anchor="w", padx=16, pady=(14, 4))
    ctk.CTkLabel(
        dlg,
        text="「言い換え」「記号・単位」は別ファイル管理のため削除できません。\n"
             "それ以外を削除すると、そのカテゴリの項目もすべて消えます\n"
             "(確認ダイアログあり / 元に戻せません)。",
        justify="left", anchor="w", text_color=MUTED, font=FONT_SM).pack(
            anchor="w", padx=16, pady=(0, 6))

    list_card = ctk.CTkFrame(dlg, fg_color=CARD, corner_radius=12,
                             border_color=BORDER, border_width=1)
    list_card.pack(fill="both", expand=True, padx=16)
    list_inner = tk.Frame(list_card, bg=CARD)
    list_inner.pack(fill="both", expand=True, padx=8, pady=8)
    listbox = _themed_listbox(list_inner, 10)

    msg_label = ctk.CTkLabel(dlg, text="", text_color=MUTED, font=FONT_SM,
                             justify="left", anchor="w")
    msg_label.pack(anchor="w", padx=16, pady=(2, 0))

    cats_state = {"current": []}

    def refresh_list():
        listbox.delete(0, tk.END)
        cats = _all_categories(items)
        cats_state["current"] = cats
        for c in cats:
            count = sum(1 for it in items if it.get("category") == c)
            tag = "[固定]  " if c in CATEGORY_FIXED else "[削除可]"
            listbox.insert(tk.END, f"  {tag}  {c}  ({count} 件)")

    refresh_list()

    def on_delete_category():
        sel = listbox.curselection()
        if not sel:
            msg_label.configure(text="削除するカテゴリを選んでください。",
                                text_color="#c00000")
            return
        cat = cats_state["current"][sel[0]]
        if cat in CATEGORY_FIXED:
            msg_label.configure(
                text=f"「{cat}」は別ファイル管理のため削除できません。",
                text_color="#c00000")
            return
        targets = [it for it in items if it.get("category") == cat]
        if not messagebox.askyesno(
            "カテゴリ削除の確認",
            f"カテゴリ「{cat}」を削除します。\n"
            f"このカテゴリの項目 {len(targets)} 件もすべて削除されます。\n"
            f"よろしいですか?(元に戻せません)"):
            return
        backup_items = list(items)
        backup_custom = _load_custom_categories()
        items[:] = [it for it in items if it.get("category") != cat]
        custom = [c for c in _load_custom_categories() if c != cat]
        try:
            _save_custom_categories(custom)
            save_items()
        except Exception as e:
            items[:] = backup_items
            _save_custom_categories(backup_custom)
            msg_label.configure(text=f"保存失敗: {e}", text_color="#c00000")
            return
        msg_label.configure(
            text=f"カテゴリ「{cat}」と {len(targets)} 件の項目を削除しました。",
            text_color="#1a7000")
        refresh_list()
        after_change_cb()

    _ghost_btn(dlg, "選んだカテゴリを削除", on_delete_category, width=200).pack(
        anchor="w", padx=16, pady=(8, 6))

    ctk.CTkFrame(dlg, height=1, fg_color=BORDER).pack(
        fill="x", padx=16, pady=6)

    ctk.CTkLabel(dlg, text="新規カテゴリの追加", font=FONT_BOLD,
                 text_color=TEXT).pack(anchor="w", padx=16)
    ctk.CTkLabel(dlg,
                 text="独自分野(例:ガス設計 / 電気設計 / 顧客名 など)を作れます。",
                 text_color=MUTED, font=FONT_SM).pack(anchor="w", padx=16)

    add_frame = ctk.CTkFrame(dlg, fg_color="transparent")
    add_frame.pack(anchor="w", padx=16, pady=6)
    e_new = ctk.CTkEntry(add_frame, width=200, height=34, font=FONT,
                         placeholder_text="カテゴリ名")
    e_new.pack(side="left")

    def on_add_category():
        name = e_new.get().strip()
        if not name:
            msg_label.configure(text="カテゴリ名を入力してください。",
                                text_color="#c00000")
            return
        if name in _all_categories(items):
            msg_label.configure(text=f"カテゴリ「{name}」は既に存在します。",
                                text_color="#c00000")
            return
        if name in ("すべて表示",):
            msg_label.configure(text="その名前は予約語のため使えません。",
                                text_color="#c00000")
            return
        custom = _load_custom_categories()
        custom.append(name)
        try:
            _save_custom_categories(custom)
        except Exception as e:
            msg_label.configure(text=f"保存失敗: {e}", text_color="#c00000")
            return
        e_new.delete(0, tk.END)
        msg_label.configure(text=f"カテゴリ「{name}」を追加しました。",
                            text_color="#1a7000")
        refresh_list()
        after_change_cb()

    _accent_btn(add_frame, "追加", on_add_category, width=90).pack(
        side="left", padx=6)
    _ghost_btn(dlg, "閉じる", dlg.destroy, width=120).pack(pady=10)
    e_new.focus()


def main():
    # --- 二重起動ガード:設定画面を2つ開かせない(2026-07-09) ---
    # 既に設定画面が起動中なら、新しく開かず既存ウィンドウを前面に出して終了する。
    # Windows の名前付きミューテックスで「起動済みか」を判定(プロセス終了で自動解放)。
    try:
        import ctypes as _ctypes
        _k32 = _ctypes.windll.kernel32
        _k32.CreateMutexW(None, False, "GrowVoiceSettingsUI_SingleInstance")
        if _k32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            _u32 = _ctypes.windll.user32
            _hwnd = _u32.FindWindowW(None, "音声入力ツール 設定")
            if _hwnd:
                _u32.ShowWindow(_hwnd, 9)        # SW_RESTORE(最小化なら復元)
                _u32.SetForegroundWindow(_hwnd)  # 既存の窓を前面へ
            return  # 2つ目は開かずに終了
    except Exception:
        pass  # 判定に失敗しても通常起動は妨げない

    ctk.set_appearance_mode("light")
    root = ctk.CTk()
    root.title("音声入力ツール 設定")
    root.geometry("800x800")
    root.configure(fg_color=CREAM)
    root.resizable(False, True)
    # タスクバー/タイトルバーのアイコンを黄色マイクにする(Pythonロゴを避ける)
    try:
        root.iconbitmap(str(ASSETS / "voice_input.ico"))
    except Exception:
        pass

    header = ctk.CTkFrame(root, fg_color="transparent")
    header.pack(fill="x", padx=18, pady=(14, 0))
    badge = ctk.CTkFrame(header, width=40, height=40, fg_color="transparent")
    badge.pack(side="left")
    badge.pack_propagate(False)
    try:
        _logo_img = ctk.CTkImage(
            light_image=Image.open(ASSETS / "icon_mark.png").convert("RGBA"),
            size=(40, 40))
        ctk.CTkLabel(badge, image=_logo_img, text="").pack(expand=True)
    except Exception:
        ctk.CTkLabel(badge, text="🎤", font=("Segoe UI Emoji", 16),
                     text_color=ACCENT_TEXT).pack(expand=True)
    title_box = ctk.CTkFrame(header, fg_color="transparent")
    title_box.pack(side="left", padx=10)
    ctk.CTkLabel(title_box, text="音声入力ツール 設定", font=FONT_BOLD,
                 text_color=TEXT).pack(anchor="w")
    ctk.CTkLabel(title_box, text="話し方に合わせて育てる", font=FONT_SM,
                 text_color=MUTED).pack(anchor="w")

    # 右上: 丸窓アバター(クリックで画像変更。四角い画像も必ず円形で表示。
    # オレンジの枠は付けない)
    AV_SIZE = 96
    right_box = ctk.CTkFrame(header, fg_color="transparent")
    right_box.pack(side="right", padx=(0, 2))
    av_label = ctk.CTkLabel(right_box, text="", cursor="hand2")
    av_label.pack()
    # 右上アイコンの下: 自動学習(Ollama)の稼働状態を常時表示する
    status_label = ctk.CTkLabel(right_box, text="● 状態を確認中…",
                                font=("Yu Gothic UI", 11, "bold"),
                                text_color=MUTED)
    status_label.pack(pady=(3, 0))
    status_sub = ctk.CTkLabel(right_box, text="",
                              font=("Yu Gothic UI", 9), text_color=MUTED)
    status_sub.pack()

    def _apply_avatar():
        p = _resolve_avatar_path()
        cimg = _circular_avatar_image(p, AV_SIZE) if p else None
        if cimg is None:
            cimg = _placeholder_avatar(AV_SIZE)
        av_label.configure(image=cimg, text="")
        av_label.image = cimg  # GC 防止に参照を保持

    def on_pick_avatar(_evt=None):
        path = filedialog.askopenfilename(
            title="アイコン画像を選ぶ",
            filetypes=[("画像ファイル", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"),
                       ("すべてのファイル", "*.*")])
        if not path:
            return
        try:
            AVATAR_CUSTOM.parent.mkdir(parents=True, exist_ok=True)
            Image.open(path).convert("RGBA").save(AVATAR_CUSTOM)
        except Exception as e:
            messagebox.showerror("読み込み失敗",
                                 f"画像を読み込めませんでした:\n{e}")
            return
        _apply_avatar()

    av_label.bind("<Button-1>", on_pick_avatar)
    _apply_avatar()

    tabview = ctk.CTkTabview(
        root, fg_color=CREAM, corner_radius=14,
        segmented_button_fg_color=CHIP_BG,
        segmented_button_selected_color=ACCENT,
        segmented_button_selected_hover_color=ACCENT_HOVER,
        segmented_button_unselected_color=CHIP_BG,
        segmented_button_unselected_hover_color=BORDER,
        text_color=ACCENT_TEXT)
    tabview.pack(fill="both", expand=True, padx=18, pady=12)

    tab_dict = tabview.add("辞書")
    tab_key = tabview.add("録音キー")
    tab_rules = tabview.add("見える化")
    tab_ai = tabview.add("AI設定")
    tab_status = tabview.add("動作ログ")

    dict_api = _build_unified_dictionary_tab(tab_dict)
    _build_hotkey_tab(tab_key)
    rules_rebuild = _build_rules_viewer_tab(tab_rules)
    ai_status_update = _build_ai_tab(tab_ai)
    status_refresh = _build_status_tab(tab_status)

    # --- 稼働状態の常時表示 + 誘導 ---------------------------------------
    # 接続確認はネット待ちが出るので別スレッドで行い、結果だけ UI に反映。
    # 20秒ごとに自動更新(設定の切替や Ollama 起動/停止に追従)。
    # 理想(緑)以外はヘッダーから「AI設定」タブへ誘導し、エラー詳細はそこに出す。
    STATUS_COLORS = {"ok": "#1a7000", "warn": "#a05000",
                     "off": MUTED, "bad": "#c00000"}

    def _goto_ai(_evt=None):
        try:
            tabview.set("AI設定")
        except Exception:
            pass

    for _w in (status_label, status_sub):
        _w.configure(cursor="hand2")
        _w.bind("<Button-1>", _goto_ai)

    def _apply_status(level, msg, sub, detail):
        status_label.configure(text="● " + msg,
                               text_color=STATUS_COLORS.get(level, MUTED))
        status_sub.configure(text=sub)
        try:
            ai_status_update(level, msg, detail)
        except Exception:
            pass

    def _refresh_status():
        s = _load_settings()

        def work():
            alive, reason = _probe_ollama(s)
            level, msg, sub, detail = _compute_status(s, alive, reason)
            try:
                root.after(0, lambda: _apply_status(level, msg, sub, detail))
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()
        try:
            root.after(20000, _refresh_status)
        except Exception:
            pass

    def on_tab_change():
        cur = tabview.get()
        if cur == "見える化":
            rules_rebuild()
        elif cur == "AI設定":
            _refresh_status()  # タブを開いた瞬間に最新化
        elif cur == "動作ログ":
            status_refresh()

    # 動作ログタブを開いている間だけ 1.5 秒ごとに自動更新する
    def _refresh_log_loop():
        try:
            if tabview.get() == "動作ログ":
                status_refresh()
        except Exception:
            pass
        try:
            root.after(1500, _refresh_log_loop)
        except Exception:
            pass

    tabview.configure(command=on_tab_change)
    _refresh_status()
    _refresh_log_loop()
    root.mainloop()


if __name__ == "__main__":
    main()
