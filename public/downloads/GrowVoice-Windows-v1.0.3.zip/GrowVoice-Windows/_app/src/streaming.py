# -*- coding: utf-8 -*-
"""streaming.py - 擬似ストリーミング認識 (Step2)

faster-whisper は本来ストリーミング非対応。そこで「録音中に裏で先行認識」する。

考え方(HANDOFF 5章「待ち時間を喋っている時間の裏に隠す」):
  - 録音中、別スレッドが一定間隔で「ここまでの音声」を認識する。
  - ただし喋っている最中の末尾は途中で言葉が変わり得るので、末尾の数秒
    (safety_tail)は確定させず保留する。それより前のセグメントだけを確定する。
  - 確定したテキスト片は on_text コールバックで即座に渡す。常駐本体はそれを
    整形してカーソルに挿入するので、喋っている裏で文字が出続ける(Aqua方式)。
  - 喋り終わったら、未確定の末尾だけを認識して on_text で渡す。
  - 結果、喋り終わってから走る認識は「末尾の数秒分」だけになり待ち時間が縮む。

このファイルは2層に分かれている:
  - StreamingTranscriber : 確定ロジックの本体(音声配列とセグメントだけで動く。
                           GPU・マイク不要なので自動テストできる)
  - StreamingSession     : マイク録音 + ワーカースレッドの土台(実機専用)
"""

import threading

import numpy as np

SAMPLE_RATE = 16000


class StreamingTranscriber:
    """確定ロジックの本体。録音中は process_chunk、解放後は finalize を呼ぶ。

    process_chunk / finalize はどちらも「今回新たに確定したテキスト片」を返す。
    返り値を順につなぐと全文になる。confirmed_text には全文が積まれていく。
    """

    def __init__(
        self,
        transcriber,
        sample_rate=SAMPLE_RATE,
        chunk_interval=1.0,
        safety_tail_sec=0.6,
        min_new_sec=1.5,
    ):
        self.transcriber = transcriber
        self.sample_rate = sample_rate
        self.chunk_interval = chunk_interval  # 何秒ごとに裏で先行認識するか
        self.safety_tail_sec = safety_tail_sec  # 末尾の保留時間(確定させない長さ)
        self.min_new_sec = min_new_sec  # 未確定分がこれ未満なら先行認識をスキップ
        self.confirmed_text = ""
        self.confirmed_samples = 0  # 先頭から何サンプルまで確定済みか

    def reset(self):
        """次の録音に備えて確定状態を初期化する。"""
        self.confirmed_text = ""
        self.confirmed_samples = 0

    def process_chunk(self, full_audio):
        """録音中に呼ぶ。確定できたテキスト片を返す(無ければ空文字)。

        full_audio は録音開始からの全音声(16kHz float32)。
        末尾 safety_tail_sec より前のセグメント/単語を確定する。

        確定戦略:
          1. セグメントの end が cutoff より前 -> そのセグメント全体を確定
          2. cutoff にまたがるセグメントは、 単語タイムスタンプがあれば
             cutoff より前で終わる単語までを確定(句点なしの長文対策)
          3. 単語タイムスタンプが無ければ、 そのセグメントは確定しない
             (旧バージョンの faster-whisper 互換)
        """
        portion = full_audio[self.confirmed_samples:]
        dur = len(portion) / self.sample_rate
        if dur < self.min_new_sec:
            return ""  # 未確定分がまだ短い。確定できるものが無い
        # 単語単位の確定を可能にするため word_timestamps を要求する。
        # transcribe_raw が word_timestamps を受け取らない旧シグネチャでも
        # 動くようにフォールバックする。
        try:
            segments = self.transcriber.transcribe_raw(
                portion, word_timestamps=True
            )
        except TypeError:
            segments = self.transcriber.transcribe_raw(portion)
        cutoff = dur - self.safety_tail_sec  # この時刻より前で終わるものだけ確定
        delta_parts = []
        advance_sec = 0.0
        for seg in segments:
            if seg.end <= cutoff:
                # セグメント全体が安全域 -> 丸ごと確定
                delta_parts.append(seg.text)
                advance_sec = seg.end
                continue
            # 安全域にまたがるセグメント。 単語単位で詰められるなら詰める
            words = getattr(seg, "words", None)
            if words:
                kept_words = []
                last_word_end = advance_sec
                for w in words:
                    if w.end <= cutoff:
                        kept_words.append(w.word)
                        last_word_end = w.end
                    else:
                        break
                if kept_words:
                    delta_parts.append("".join(kept_words))
                    advance_sec = last_word_end
            # cutoff を跨いだ時点で以降のセグメントも cutoff より後 -> 打ち切り
            break
        if not delta_parts:
            return ""
        delta = "".join(delta_parts)
        self.confirmed_text += delta
        self.confirmed_samples += int(advance_sec * self.sample_rate)
        return delta

    def finalize(self, full_audio):
        """解放後に呼ぶ。未確定の末尾を認識し、その末尾テキスト片を返す。"""
        portion = full_audio[self.confirmed_samples:]
        if len(portion) > 0:
            segments = self.transcriber.transcribe_raw(portion)
            tail = "".join(s.text for s in segments)
        else:
            tail = ""
        self.confirmed_text += tail
        self.confirmed_samples = len(full_audio)
        return tail


class StreamingSession:
    """マイク録音とワーカースレッドを束ねる。start() で録音開始、stop() で全文を返す。

    on_text(テキスト片) を渡すと、確定したテキスト片を喋っている裏で順次通知する。
    常駐本体はそれを整形して即挿入する(Aqua方式の「喋りながら順次挿入」)。

    settings の "streaming" が false の時は先行認識をせず、従来通り
    解放後に一括認識する(既存の動きを壊さないための切替)。
    """

    def __init__(self, transcriber, settings, on_text=None):
        self.sample_rate = SAMPLE_RATE
        # 擬似ストリーミングは既定 OFF。短い発話では「録音中の先行認識」と
        # 「解放後の末尾認識」の境界で語頭が二重確定し(例: 心心配/急急/ブブ)、
        # 文頭付近のどもりや崩れの原因になる。短発話中心の用途では一括認識の
        # 方が安定するため既定を False にする(settings.json で true に変更可)。
        self.enabled = settings.get("streaming", False)
        self.on_text = on_text
        self.streamer = StreamingTranscriber(
            transcriber,
            sample_rate=self.sample_rate,
            chunk_interval=float(settings.get("stream_chunk_sec", 1.0)),
            safety_tail_sec=float(settings.get("stream_safety_tail_sec", 0.6)),
        )
        self._frames = []
        self._stream = None
        self._worker = None
        self._stop_flag = threading.Event()
        # --- 常時マイク + プリロール(文頭の取りこぼし対策) -------------
        # 従来はキー押下のたびに InputStream を開いていたが、デバイスが開く
        # までの 100〜300ms の音声(=話し始め)が失われ、文頭の誤認識が
        # 多発していた。マイクを開きっぱなしにし、待機中は直近 preroll_sec
        # だけをリングバッファに保持。録音開始はフラグ操作だけになるので
        # 開始遅延ゼロ + 押す直前の音もプリロールとして含められる。
        # settings.json の mic_always_on:false で従来方式に戻せる。
        self.preroll_sec = float(settings.get("preroll_sec", 0.25))
        self._persistent_wanted = bool(settings.get("mic_always_on", True))
        # --- 語尾の取りこぼし対策(2026-07-20) --------------------------------
        # キーを離した瞬間に締め切ると、最後の 100〜200ms(=語尾)がまだドライバの
        # バッファの中にあり、録音に入らないまま捨てられる。 Whisper は欠けた語尾を
        # 消すか別の字に化かす(「語尾が消える/変な文字になる」の正体)。
        # MME/DirectSound は遅延が 90〜180ms と大きいので影響が大きい。
        # 締め切る前にこの秒数だけ待ち、その間に届いた音まで録音に含める。
        # settings.json の tail_drain_sec で調整可(0 で無効)。
        self.tail_drain_sec = float(settings.get("tail_drain_sec", 0.12))
        # --- 使うマイクの指定(配布先の環境差を吸収するため) -----------------
        # input_device: マイク名の一部(例 "Realtek")か番号。空なら OS の既定。
        # prefer_low_latency: 同じマイクが複数の接続方式で見えている時、最も
        #   遅延の小さい方式(多くの環境で WASAPI = 数ms)を選ぶ。MME は 90〜180ms
        #   あり語尾を取りこぼしやすいので、既定で ON にする。
        self.input_device = settings.get("input_device", "")
        self.prefer_low_latency = bool(settings.get("prefer_low_latency", True))
        self.device_desc = "既定のマイク"
        self._pstream = None       # 常時オープンの InputStream
        self._recording = False    # True の間だけ _frames に蓄積
        self._ring = []            # 待機中の直近音声(プリロール用)
        self._ring_samples = 0
        # 直近の stop() 呼び出しの内訳秒数。原因切り分け用に hotkey_app.py が読む。
        # キー: "teardown" (録音停止+ワーカー合流) / "transcribe" (本体の認識)
        self.last_metrics = {"teardown": 0.0, "transcribe": 0.0}

    @staticmethod
    def _looks_like_bluetooth_headset(name):
        """Bluetooth ヘッドセットのマイクらしい名前かを判定する。

        Bluetooth ヘッドセットはマイクを使う瞬間に通話用(ハンズフリー)へ
        切り替わり、狭帯域・低音質になる。 語尾が潰れて認識精度が大きく落ちる
        ので、配布先でも気付けるよう起動時に注意を出す。
        """
        raw = name or ""
        low = raw.lower()
        return ("hands-free" in low or "handsfree" in low
                or "headset" in low or "ヘッドセット" in raw)

    def _resolve_device(self):
        """使うマイクの (index, 説明) を返す。 index が None なら OS の既定に任せる。

        1. settings.input_device の指定(名前の一部 or 番号)を優先
        2. 指定が無ければ OS の既定マイクの「名前」を基準にする
        3. prefer_low_latency が True なら、同じ名前で見えている接続方式のうち
           最も遅延の小さいものを選ぶ(MME 90〜180ms → WASAPI 数ms)
        """
        import sounddevice as sd

        devices = sd.query_devices()
        inputs = [(i, d) for i, d in enumerate(devices)
                  if d.get("max_input_channels", 0) > 0]

        def ha_name(d):
            try:
                return sd.query_hostapis(d["hostapi"])["name"]
            except Exception:
                return ""

        want = str(self.input_device or "").strip()
        target_name = None
        if want:
            if want.isdigit() and any(i == int(want) for i, _ in inputs):
                i = int(want)
                d = devices[i]
                return i, f"{d['name']} / {ha_name(d)}"
            low = want.lower()
            for i, d in inputs:
                if low in str(d.get("name", "")).lower():
                    target_name = str(d.get("name", ""))
                    break
            if target_name is None:
                print(f" 【警告】指定のマイク「{want}」が見つかりませんでした。"
                      f"既定のマイクを使います。")
        if target_name is None:
            try:
                di = sd.default.device[0]
                d = (sd.query_devices(di) if di is not None
                     else sd.query_devices(kind="input"))
                target_name = str(d.get("name", ""))
            except Exception:
                return None, "既定のマイク"

        cands = [(i, d) for i, d in inputs
                 if str(d.get("name", "")) == target_name]
        if not cands:
            return None, "既定のマイク"

        # 実際に 16kHz/モノラルで開ける候補だけに絞る。 WASAPI は共有モードだと
        # デバイス既定のサンプルレートしか受け付けず 16kHz を拒否することがあり
        # (PaErrorCode -9997)、選んでも開けずに退避するだけで無駄が出るため、
        # 選ぶ前にここで確認しておく。
        def _usable(i):
            try:
                sd.check_input_settings(
                    device=i, samplerate=self.sample_rate,
                    channels=1, dtype="float32")
                return True
            except Exception:
                return False

        usable = [(i, d) for i, d in cands if _usable(i)]
        if usable:
            cands = usable

        if self.prefer_low_latency:
            i, d = min(cands, key=lambda t: float(
                t[1].get("default_low_input_latency", 1.0) or 1.0))
        else:
            i, d = cands[0]
        lat = float(d.get("default_low_input_latency", 0.0) or 0.0)
        return i, f"{d['name']} / {ha_name(d)} / 遅延{lat * 1000:.0f}ms"

    def open_mic(self):
        """マイクを常時オープンにする(起動時に1回呼ぶ)。

        成功すると以降の録音開始/停止はフラグ操作だけになり、
        PortAudio のストリーム開閉が押下時に発生しない。
        失敗時は False を返し、従来の「押下時に開く」方式で動き続ける。
        指定マイクが開けない環境でも止まらないよう、既定マイクへ自動で退避する。
        """
        if not self._persistent_wanted or self._pstream is not None:
            return self._pstream is not None
        import sounddevice as sd

        try:
            idx, desc = self._resolve_device()
        except Exception:
            idx, desc = None, "既定のマイク"

        attempts = [(idx, desc)]
        if idx is not None:
            attempts.append((None, "既定のマイク(退避)"))
        for device, label in attempts:
            try:
                self._pstream = sd.InputStream(
                    samplerate=self.sample_rate,
                    channels=1,
                    dtype="float32",
                    callback=self._callback,
                    device=device,
                )
                self._pstream.start()
                self.device_desc = label
                if self._looks_like_bluetooth_headset(label):
                    print(" 【注意】Bluetooth ヘッドセットのマイクは通話モード"
                          "(狭帯域・低音質)で動くため、語尾の精度が落ちます。"
                          "有線・USB・内蔵マイクを推奨します"
                          "(settings.json の input_device で指定できます)。")
                return True
            except Exception as e:
                self._pstream = None
                if device is None:
                    print(f" 【情報】常時マイクを開けないため従来方式で動きます: {e}")
                    return False
                print(f" 【情報】マイク「{label}」を開けませんでした({e})。"
                      f"既定のマイクで再試行します。")
        return False

    def close_mic(self):
        """常時マイクを閉じる(終了時用。失敗しても無視)。"""
        if self._pstream is not None:
            try:
                self._pstream.stop()
                self._pstream.close()
            except Exception:
                pass
            self._pstream = None

    def reopen_mic(self):
        """常時マイクを開き直す(自己修復)。

        ヘッドセットの電源OFF・スリープ・USB/Bluetooth の抜き差し・既定デバイスの
        切替が起きると、起動時に開いた常時マイクのストリームが「生きているのに
        音を1サンプルも返さない」状態になる。 これが起きると以降は毎回・全アプリで
        録音が空になり、貼り付けるテキストが生まれない。 本メソッドで現在の既定
        入力デバイスに開き直して復旧する。

        戻り値: 開き直して常時マイクが使える状態なら True。
                常時マイクを使わない設定なら False。
        """
        if not self._persistent_wanted:
            return False
        self.close_mic()
        # PortAudio はデバイス一覧を初期化時にキャッシュするため、抜き差し後に
        # 切り替わった既定デバイスを確実に拾うには再初期化が要る。 失敗しても
        # そのまま open_mic を試す(安全側)。
        try:
            import sounddevice as sd
            sd._terminate()
            sd._initialize()
        except Exception:
            pass
        return self.open_mic()

    def mic_is_alive(self):
        """常時マイクのストリームが有効(active)かを返す。判定不能時は True 扱い
        (無用な再オープンで録音開始を遅らせないため、安全側に倒す)。"""
        if self._pstream is None:
            return False
        try:
            return bool(self._pstream.active)
        except Exception:
            return True

    def start(self):
        """録音を開始する。streaming 有効時は裏で先行認識スレッドも動かす。"""
        self.streamer.reset()
        self._stop_flag.clear()
        # 常時マイクのストリームが死んでいたら、録音開始の前に開き直す。
        # (デバイス切替・スリープ対策。 生きている時は素通しで開始遅延ゼロ)
        if self._persistent_wanted and self._pstream is not None \
                and not self.mic_is_alive():
            try:
                self.reopen_mic()
            except Exception:
                pass
        if self._pstream is not None:
            # 常時マイク: 押す直前 preroll_sec の音声を先頭に含めて録音開始。
            # ストリームの開閉なし(フラグだけ)なので開始遅延ゼロ。
            self._frames = self._ring[:]
            self._recording = True
        else:
            # フォールバック: 従来どおり押下時にストリームを開く
            import sounddevice as sd

            self._frames = []
            self._stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype="float32",
                callback=self._callback,
            )
            self._stream.start()
        if self.enabled:
            self._worker = threading.Thread(target=self._loop, daemon=True)
            self._worker.start()

    def _callback(self, indata, frames, time_info, status):
        if self._recording or self._pstream is None:
            self._frames.append(indata.copy())
            return
        # 待機中(常時マイク): 直近 preroll_sec だけ保持し、古い分は捨てる。
        # どこにも保存しない使い捨てバッファ(プライバシー面でも溜めない)。
        self._ring.append(indata.copy())
        self._ring_samples += len(indata)
        limit = int(self.preroll_sec * self.sample_rate)
        while self._ring and self._ring_samples - len(self._ring[0]) >= limit:
            self._ring_samples -= len(self._ring[0])
            self._ring.pop(0)

    def _snapshot(self):
        """現時点までの全音声を1次元配列で取り出す(録音中でも安全に呼べる)。"""
        frames = self._frames[:]  # リストのスナップショット(list の append はGILで安全)
        if not frames:
            return np.zeros(0, dtype="float32")
        return np.concatenate(frames, axis=0).flatten().astype("float32")

    def _loop(self):
        """ワーカースレッド。一定間隔で先行認識し、確定分を on_text で通知する。"""
        while not self._stop_flag.is_set():
            if self._stop_flag.wait(self.streamer.chunk_interval):
                break  # 解放された。途中の余計な認識はせず抜ける
            try:
                delta = self.streamer.process_chunk(self._snapshot())
                if delta and self.on_text:
                    self.on_text(delta)
            except Exception as e:
                # 先行認識は「おまけ」。失敗しても finalize が全部を拾うので止めない
                print(f" 【警告】裏での先行認識に失敗(無視して継続): {e}")

    def _teardown(self):
        """録音を止める(認識・挿入はしない共通処理)。

        常時マイク使用時はフラグを下ろすだけ(マイク自体は開いたまま)。
        リングバッファも空にして、今回の録音音声が次回のプリロールに
        混ざらないようにする。
        """
        self._recording = False
        self._ring = []
        self._ring_samples = 0
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            finally:
                self._stream = None
        # ワーカーを止める。モデルの同時使用を避けるため必ず合流する
        self._stop_flag.set()
        if self._worker is not None:
            self._worker.join()
            self._worker = None

    def _drain_tail(self):
        """締め切る前に、語尾がドライバから届くまでほんの少しだけ待つ。

        _recording を True のまま待つので、待っている間にコールバックが届けた
        音はそのまま録音(_frames)に入る。 待ち時間は「設定値」と「実際の
        入力遅延の1.5倍」の大きい方(上限 0.3秒)にして、遅い経路(MME 等)でも
        語尾を拾い切り、速い経路(WASAPI 等)では無駄に待たない。
        """
        wait = self.tail_drain_sec
        if wait <= 0:
            return
        try:
            lat = float(getattr(self._pstream, "latency", 0.0) or 0.0)
            if lat > 0:
                wait = max(wait, min(lat * 1.5, 0.3))
        except Exception:
            pass
        try:
            import time as _t
            _t.sleep(wait)
        except Exception:
            pass

    def cancel(self):
        """録音を破棄して停止する。認識も挿入もしない。

        最低押し込み時間に満たない短い押下(Ctrl+C 等のショートカット操作)で
        誤って録音が走った時に、何も出力せず後始末だけする用途。
        """
        self._teardown()

    def stop(self):
        """録音を停止し、認識済みの全文テキストを返す。音が短すぎる時は空文字。

        未挿入の末尾テキスト片は、この中で on_text により通知する。
        所要時間の内訳は self.last_metrics に "teardown" と "transcribe" で
        書き出す(原因切り分け用)。
        """
        import time as _time

        t0 = _time.perf_counter()
        # 締め切る前に語尾ぶんを待つ(cancel 時は破棄するので待たない)
        self._drain_tail()
        self._teardown()
        t1 = _time.perf_counter()
        audio = self._snapshot()
        # 録れた音のサンプル数を記録する。 hotkey_app 側がこれを見て
        # 「押していたのに音がほぼ無い=マイク無音化」を検知し、自己修復する。
        samples = int(audio.size)
        if audio.size < 1600:  # 0.1秒未満の誤爆は無視
            self.last_metrics = {"teardown": t1 - t0, "transcribe": 0.0,
                                 "samples": samples}
            return ""
        if self.enabled:
            tail = self.streamer.finalize(audio)
            if tail and self.on_text:
                self.on_text(tail)
            t2 = _time.perf_counter()
            self.last_metrics = {"teardown": t1 - t0, "transcribe": t2 - t1,
                                 "samples": samples}
            return self.streamer.confirmed_text.strip()
        # streaming 無効: 従来通り、解放後に全体を一括認識する
        segments = self.streamer.transcriber.transcribe_raw(audio)
        whole = "".join(s.text for s in segments).strip()
        if whole and self.on_text:
            self.on_text(whole)
        t2 = _time.perf_counter()
        self.last_metrics = {"teardown": t1 - t0, "transcribe": t2 - t1,
                             "samples": samples}
        return whole
