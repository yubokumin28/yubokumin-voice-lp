# -*- coding: utf-8 -*-
"""hotkey_app.py - 音声入力ツール 常駐本体 (第2段 / 最小版の完成形)

ホットキー(既定 左Ctrl)を長押し中に録音し、解放で
  録音 -> 音声認識 -> 整形 -> 句読点AI -> カーソル位置へ挿入
を一連で実行する。Ctrl+Alt+D で設定画面(録音キー変更・辞書登録)を開く。
録音中の状態は画面右上の録音中ランプ(overlay.py)に表示する。

検証用:  python src/hotkey_app.py --test-wav <音声ファイル>
         録音の代わりに WAV を読み込み、認識〜整形までを確認する(挿入はしない)。
"""

import os
import subprocess
import sys
import threading
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent
ROOT = SRC.parent
sys.path.insert(0, str(SRC))

from formatter import load_config, format_text, detect_hallucination  # noqa: E402

CONFIG_DIR = ROOT / "config"
TEMPLATE_DIR = CONFIG_DIR / "_templates"
OVERLAY_STATE = ROOT / "logs" / "overlay_state.txt"
APP_LOG = ROOT / "logs" / "app.log"          # 設定画面「動作ログ」が読む
HEARTBEAT = ROOT / "logs" / "heartbeat.txt"  # 常駐中かを設定画面が判定する印


def _ensure_user_config():
    """旦那様の辞書ファイルが無ければ、 テンプレートから初回コピーする。

    辞書ファイル(replacements.json / symbols.json / construction_terms.json)
    は旦那様の編集を git 管理の上書きから守るため .gitignore 配下に置く。
    存在しなければ config/_templates/*.default.json から複製して初期化する。
    旦那様が消去・編集した後は二度と上書きしない(永続化される)。
    """
    import shutil
    pairs = [
        ("replacements.json", "replacements.default.json"),
        ("symbols.json", "symbols.default.json"),
        ("construction_terms.json", "construction_terms.default.json"),
    ]
    for user_file, template_file in pairs:
        user_path = CONFIG_DIR / user_file
        if user_path.exists():
            continue
        template_path = TEMPLATE_DIR / template_file
        if template_path.exists():
            try:
                shutil.copy(template_path, user_path)
                print(f" 初回起動: {user_file} を初期データから作成しました。")
            except Exception as e:
                print(f" 【警告】{user_file} の初期化に失敗: {e}")


_overlay = {"current": "idle"}


def set_overlay_state(state):
    """録音中ランプ(overlay.py)に今の状態を伝える。

    state: "idle"/"recording"/"busy"/"error"/"repair"。
    ファイル経由で別プロセスのランプに渡す。失敗しても本体は止めない。
    """
    try:
        _overlay["current"] = state
        OVERLAY_STATE.parent.mkdir(parents=True, exist_ok=True)
        OVERLAY_STATE.write_text(state, encoding="utf-8")
    except Exception:
        pass


def flash_overlay_state(state, hold=2.5):
    """一時状態(error/repair)を hold 秒だけランプに表示し、その後 idle に戻す。

    エラー検出や自動修復のように一瞬で過ぎる出来事を、ランプで見える時間だけ
    保持する。hold 秒の間に別の状態(recording 等)が入ったら idle には戻さない
    (新しい状態を優先)。本体の処理は一切止めない。
    """
    try:
        set_overlay_state(state)

        def _revert():
            if _overlay["current"] == state:
                set_overlay_state("idle")

        t = threading.Timer(hold, _revert)
        t.daemon = True
        t.start()
    except Exception:
        pass


class _Tee:
    """print の出力を、元の出力先(あれば)とログファイルの両方へ流す。

    窓なし(pythonw)起動では元の stdout が無いのでファイルだけに書く。
    設定画面の「動作ログ」タブが APP_LOG を読み、以前ターミナルに出ていた
    内容(起動状況・挿入・速度・警告)を同じように見せる。
    """

    def __init__(self, original, fileobj):
        self._original = original
        self._file = fileobj

    def write(self, s):
        if self._original is not None:
            try:
                self._original.write(s)
            except Exception:
                pass
        try:
            self._file.write(s)
            self._file.flush()
        except Exception:
            pass

    def flush(self):
        for t in (self._original, self._file):
            if t is not None:
                try:
                    t.flush()
                except Exception:
                    pass


def _setup_logging():
    """stdout/stderr を logs/app.log にも流す(窓なし起動でも内容を残す)。"""
    try:
        APP_LOG.parent.mkdir(parents=True, exist_ok=True)
        # 肥大化防止: 512KB を超えたら 1 世代だけ退避して作り直す
        if APP_LOG.exists() and APP_LOG.stat().st_size > 512 * 1024:
            bak = APP_LOG.with_suffix(".log.1")
            try:
                if bak.exists():
                    bak.unlink()
                APP_LOG.replace(bak)
            except Exception:
                pass
        f = open(APP_LOG, "a", encoding="utf-8", buffering=1)
        sys.stdout = _Tee(sys.stdout, f)
        sys.stderr = _Tee(sys.stderr, f)
    except Exception:
        pass


def _start_heartbeat():
    """常駐中の印として、5秒ごとに現在時刻を heartbeat.txt に書く。

    設定画面はこの時刻の新しさ(15秒以内)で「常駐中/停止中」を判定する。
    daemon スレッドなので本体終了とともに自然に止まる。
    """
    import threading
    import time

    def beat():
        while True:
            try:
                HEARTBEAT.parent.mkdir(parents=True, exist_ok=True)
                HEARTBEAT.write_text(str(int(time.time())), encoding="utf-8")
            except Exception:
                pass
            time.sleep(5)

    threading.Thread(target=beat, daemon=True).start()


def _pause_if_console():
    """コンソールがある時だけ Enter 待ちする(窓なし起動では何もしない)。"""
    try:
        if sys.stdin is not None and sys.stdin.isatty():
            input("Enterキーで閉じます...")
    except Exception:
        pass


def _load_config_safe(fallback=None):
    try:
        return load_config(CONFIG_DIR)
    except ValueError as e:
        if fallback is not None:
            print(f"【警告】設定の再読込に失敗。前回の設定を使います: {e}")
            return fallback
        print("【エラー】" + str(e))
        return None


def run_test_wav(wav_path):
    """録音の代わりに WAV を流し、認識〜整形までを確認する(挿入なし)。"""
    _ensure_user_config()
    config = _load_config_safe()
    if config is None:
        return 1
    from transcriber import Transcriber
    from recorder import read_wav_file

    print(f"テスト音声: {wav_path}")
    audio = read_wav_file(wav_path)

    from latency import Stopwatch

    transcriber = Transcriber(config["settings"])
    transcriber.warmup()
    sw = Stopwatch()
    raw = transcriber.transcribe(audio)
    sw.lap("認識")
    formatted = format_text(raw, config)
    sw.lap("整形")
    print(f"使用デバイス : {transcriber.device}")
    if transcriber.device == "cpu":
        print("【警告】GPUが使えずCPU動作です。認識が大幅に遅くなります。")
    print(f"認識(生)    : {raw}")
    print(f"整形後      : {formatted}")
    print(f"段階別      : {sw.summary()}")
    return 0


def run_resident():
    """常駐モード。ホットキーを監視して音声入力を行う。"""
    # 旦那様の辞書ファイルが無ければテンプレートから初回コピー
    # (永続化:旦那様の編集が私のマージで上書きされないため)
    _ensure_user_config()
    config = _load_config_safe()
    if config is None:
        _pause_if_console()
        return 1
    settings = config["settings"]

    # 二重起動を防ぐ(プロセスの溜まり込み対策)
    from singleton import SingleInstance

    instance = SingleInstance()
    if instance.already_running:
        print("音声入力ツールは既に起動しています。二重起動はできません。")
        print("動作中のウィンドウをそのまま使ってください。")
        _pause_if_console()
        return 0

    _start_heartbeat()  # 常駐の印を出し続ける(設定画面の状態表示用)

    import threading
    import time

    import feedback
    import history
    from platform_compat import (  # noqa: E402
        install_global_key_hook,
        add_emergency_reset_hotkey,
        unhook_all_global,
        wait_forever,
        ensure_ollama_running,
        is_modifier_held,
    )
    from latency import Stopwatch  # Step1: 段階別の時間計測
    from streaming import StreamingSession  # 録音+認識のラッパー
    from inserter import insert_text, warmup as inserter_warmup
    from transcriber import Transcriber

    sound_on = settings.get("sound_feedback", True)

    print("=" * 56)
    print(" 音声入力ツール 起動中")
    print("=" * 56)
    print(" 音声認識モデルを読み込んでいます...")
    transcriber = Transcriber(settings)
    print(f" 読み込み完了。使用デバイス: {transcriber.device}")
    # warmup の実行は hook 登録の「後」 に行う(下記)。
    # 順番を変えた理由:
    #   warmup を先に同期実行すると、 その3〜5秒の間ホットキー(緊急リセット
    #   Pause など)が一切効かず、 旦那様が起動直後に固まった時に詰む。
    # 対策: 先に hook を登録し、 録音だけ state["warming_up"] フラグで
    # ガードする。 これで緊急リセットは起動直後から使えて、 録音は warmup
    # 完了後に解禁される。 設定はタスクトレイから開く(常時可)。

    # 初回挿入の遅延・失敗対策:pyperclip(OLE)の初回コストと
    # keyboard.is_pressed の初回コストをここで前払いしておく。
    # 「一発目だけターゲットに貼り付かない」症状の根治。
    try:
        inserter_warmup()
    except Exception as e:
        print(f" 【情報】挿入機能の暖機をスキップ: {e}")

    # 古い履歴ログを静かに整理(30日より前の history_*.txt を削除、
    # latency.csv が10000行超なら末尾5000行に切り詰め)
    try:
        history.cleanup_old_logs()
    except Exception:
        pass
    # Step1: CPUで動いている時は遅いので、見逃さないよう強く警告する
    if transcriber.device == "cpu":
        print("")
        print(" " + "!" * 50)
        print(" !!  警告: GPU(CUDA)が使えず CPU で動作しています。")
        print(" !!  認識が約10倍遅くなります(数十秒かかることがあります)。")
        print(" !!  対策: セットアップ.bat を再実行してください。")
        if transcriber.cpu_fallback_reason:
            print(f" !!  原因: {transcriber.cpu_fallback_reason}")
        print(" " + "!" * 50)
        print("")

    hotkey = settings.get("hotkey", "left alt")
    # 設定画面はタスクトレイから開く(Aqua Voice 流)。旧 dict_hotkey は廃止。
    # 録音キーは keyboard ライブラリのフックが渡す「キー名」で判定する。
    # スキャンコードでは左右Ctrl(同じ29)/左右Alt(同じ56)を区別できないため、
    # 名前で見分ける。設定画面の登録も同じ e.name を保存するので、左右が必ず
    # 一致する。settings["hotkey"] は "+" 連結のキー名ラベル。
    from hotkey import (  # noqa: E402
        hotkey_matches as _hotkey_matches,
        parse_hotkey_label,
        pretty_key_label,
    )
    # 録音キー・min_hold_sec は「設定画面で変えたら本体の再起動なしで反映」
    # するため runtime 辞書に入れる。 settings.json の mtime を監視する
    # ワーカースレッドが、 変更を検知したらここを書き換える。
    runtime = {
        "target_names": parse_hotkey_label(hotkey),
        "min_hold_sec": float(settings.get("min_hold_sec", 0.3)),
        "hotkey_label": hotkey,
    }
    if not runtime["target_names"]:
        print(" 【警告】録音キーを判別できませんでした。"
              "設定画面(設定を開く.bat)で録音キーを登録し直してください。")
    pretty_hotkey = pretty_key_label(hotkey) or hotkey
    print(f" 録音      : {pretty_hotkey} を押している間"
          f"({runtime['min_hold_sec']}秒以上の長押しで反応)")
    print(" 設定を開く: タスクトレイのアイコンを右クリック → 設定を開く")
    print(" 終了      : タスクトレイの「終了」 or このウィンドウを閉じる")
    print("-" * 56)

    # 録音中ランプ(別プロセス)を起動する。本体が消えれば自動で閉じる。
    if settings.get("show_overlay", True):
        set_overlay_state("idle")
        try:
            if getattr(sys, "frozen", False):
                # 単体exe時は exe 自身を録音ランプモードで起動する
                import platform_compat
                platform_compat.spawn_app_mode("overlay", os.getpid())
            else:
                subprocess.Popen(
                    [sys.executable, str(SRC / "overlay.py"), str(os.getpid())]
                )
        except Exception as e:
            print(f" 【情報】録音中ランプを表示できませんでした: {e}")

    # warming_up: warmup 完了まで True。 録音はその間ブロックする
    # (設定と緊急リセットのホットキーは効く)。
    state = {"recording": False, "busy": False, "config": config,
             "input_count": 0, "warming_up": True}
    # 50回入力ごとにターミナル画面をクリアする(長時間使用での表示蓄積を抑制)
    CLEAR_THRESHOLD = 50
    # 自己修復:録音が60秒を超えたら自動キャンセル(暴走防止)
    MAX_RECORDING_SEC = 60.0
    # 無音検知の閾値(RMS。 これ以下ならハルシネーション防止のため認識をスキップ)
    # 旦那様の実機実測:小声で話しても RMS=0.0014 程度なので、 完全無音だけを
    # 弾く設定にする。 settings.json の silence_rms_threshold で調整可能。
    # 0 にすれば無音検知を完全に無効化できる。
    SILENCE_RMS_THRESHOLD = float(settings.get("silence_rms_threshold", 0.0003))

    # 録音と認識を担うセッション(キー解放後に一括認識する)。
    # 録音中の状態はマウスカーソル付近の小窓(overlay)で見える。
    recorder = StreamingSession(transcriber, settings)
    # 文頭の取りこぼし対策: マイクを常時オープンにする(メインスレッドで1回)。
    # 押下時のストリーム開閉が無くなり、押す直前 0.25秒も録音に含まれるので
    # 「話し始めの文字が化ける/欠ける」が減る。失敗時は従来方式で動く。
    if recorder.open_mic():
        print(" マイク: 常時オープン(文頭の取りこぼし対策・録音開始遅延ゼロ)")
        # どのマイクをどの接続方式で掴んでいるかを必ず残す。 語尾の精度低下は
        # ここ(低音質/高遅延なデバイスを掴んでいる)が原因のことが多いため。
        print(f" 使用マイク: {recorder.device_desc}")

    # 今押されているキーを「名前」で追跡する。スキャンコードは左右Ctrl/Alt を
    # 区別できないため、フックが渡す e.name(left ctrl / right ctrl 等)を使う。
    held_names = set()

    def process():
        set_overlay_state("busy")
        print(" 認識中...")
        sw = Stopwatch()  # Step1: 喋り終わり後の各処理を計測
        # 自己修復:録音音声が「完全に無音(RMS が閾値未満)」なら Whisper を
        # 呼ばない。無音に対して Whisper を実行すると多言語混在の意味不明な
        # 出力(ハルシネーション)を出すため、事前に止めて防ぐ。
        # 閾値は settings.silence_rms_threshold で調整可能。 0 で完全無効化。
        if SILENCE_RMS_THRESHOLD > 0:
            try:
                import numpy as np
                audio = (recorder._snapshot()
                         if hasattr(recorder, "_snapshot") else None)
                if audio is not None and audio.size > 0:
                    rms = float(np.sqrt(np.mean(audio ** 2)))
                    if rms < SILENCE_RMS_THRESHOLD:
                        print(f" 無音(RMS={rms:.5f} < 閾値"
                              f"{SILENCE_RMS_THRESHOLD:.5f})のため"
                              f"認識をスキップしました。")
                        print(f"   ※ 話していたのにスキップされる場合は"
                              f"settings.json の silence_rms_threshold を"
                              f"下げてください(0 で無効化)。")
                        recorder.cancel()
                        set_overlay_state("idle")
                        return
            except Exception:
                pass
        # Step2: 喋っている裏で先行認識が進むので、ここの認識は末尾だけで短い。
        raw = recorder.stop()
        if not raw:  # 0.1秒未満の誤爆や無音は無視
            # 自己修復:0.3秒以上押していたのに音がほぼ無い場合は、常時マイクが
            # 無音化している(ヘッドセットの電源OFF・スリープ・既定デバイス切替)。
            # 本当の無音発話は上の silence チェックで既に "無音" と表示済みなので、
            # ここに来て音がほぼ無いのは「マイクが何も返していない」異常を意味する。
            try:
                samples = int(recorder.last_metrics.get("samples", 0))
            except Exception:
                samples = 0
            if samples < 1600:
                print(" 【警告】音声を取得できませんでした。マイクを開き直します"
                      "(マイクの電源・接続・既定の入力デバイスをご確認ください)。")
                try:
                    if recorder.reopen_mic():
                        print("   マイクを再オープンしました。"
                              "もう一度話してみてください。")
                    else:
                        print("   マイクの再オープンに失敗しました"
                              "(常時マイク無効設定の可能性)。")
                except Exception as e:
                    print(f"   マイク再オープンでエラー(無視して継続): {e}")
                # 窓なし常駐では旦那様はログを見ないので、失敗音でも即座に知らせる。
                # (この不具合が長く気づかれなかった主因=無音・無通知 の再発防止)
                if sound_on:
                    try:
                        feedback.error()
                    except Exception:
                        pass
                flash_overlay_state("repair")  # ランプに「修復」を一時表示
                return
            set_overlay_state("idle")
            return
        sw.lap("認識")
        # 辞書/設定が育つので毎回 config を読み直す(ハルシネーション判定でも使う)
        cfg = _load_config_safe(fallback=state["config"])
        state["config"] = cfg
        repeat_wl = cfg.get("settings", {}).get("repeat_whitelist", [])
        # 自己修復:ハルシネーション検出。 旦那様の希望に従い:
        #   - 重度(キリル/ハングル混在・漢字の異常羅列・非日本語比率)は
        #     作業文書を壊す異物なので破棄し、 失敗音で気付かせる。
        #   - 軽度(同一フレーズの過剰繰り返し)は長文の一部のことが多く、
        #     破棄すると喋った内容が丸ごと消えるので、 破棄せず圧縮して挿入する。
        is_hall, reason, severe = detect_hallucination(raw, repeat_wl)
        if is_hall and severe:
            print(" ⚠ 認識結果に異常を検出しました。 貼り付けをスキップして"
                  "復旧を試みます。")
            print(f"   理由: {reason}")
            print(f"   破棄したテキスト先頭: {raw[:60]}...")
            # 破棄内容を残す(挿入も履歴記録もされないので、後で確認できるよう
            # logs/discarded_YYYYMMDD.txt に時刻・理由つきで保存する)。
            try:
                dpath = history.append_discarded(raw, reason)
                print(f"   破棄ログ: {dpath}")
            except Exception as e:
                print(f"   【警告】破棄ログの保存に失敗: {e}")
            if sound_on:
                try:
                    feedback.error()
                except Exception:
                    pass
            # 自動修復:streaming ワーカーの確定状態を初期化し、 次回の認識に
            # 引きずられないようにする。 recorder.stop() で既に teardown 済み
            # なので、 ここでは内部の確定テキスト/位置だけを reset する。
            try:
                if hasattr(recorder, "streamer"):
                    recorder.streamer.reset()
            except Exception:
                pass
            flash_overlay_state("error")  # ランプに「エラー」を一時表示
            return
        if is_hall:
            # 軽度: 破棄しない。 長文が丸ごと消える事故を防ぐことを最優先し、
            # 後段の format_text(remove_repeats)による圧縮に委ねて挿入する。
            print(f" 【情報】{reason}を検出。 破棄せず圧縮して挿入します。")
        formatted = format_text(raw, cfg)
        sw.lap("整形")
        final = formatted
        # 履歴に必ず残す(挿入が失敗してもテキストを失わないため)
        try:
            history.append(raw, final)
        except Exception as e:
            print(f" 【警告】履歴の保存に失敗しました: {e}")
        sw.lap("履歴")
        insert_text(final)
        sw.lap("挿入")
        if sound_on:
            feedback.recording_done()
        sw.log()  # logs/latency.csv に追記(改善の推移を追える)
        print(f" 挿入: {final}")
        print(f" 速度: {sw.summary()}")
        # 一定回数ごとにターミナル画面をクリアして表示蓄積を抑える。
        # 窓なし起動(コンソール無し)では cls がcmd窓を一瞬出すので行わない。
        state["input_count"] += 1
        _has_console = bool(getattr(sys, "stdout", None)) and \
            getattr(getattr(sys.stdout, "_original", None), "isatty", lambda: False)()
        if _has_console and state["input_count"] >= CLEAR_THRESHOLD:
            try:
                os.system("cls")
            except Exception:
                pass
            print("=" * 56)
            print(" 音声入力ツール 起動中(画面を整理しました)")
            print("=" * 56)
            print(f" 録音      : {pretty_hotkey} を押している間"
                  f"({min_hold_sec}秒以上の長押しで反応)")
            print(" 設定を開く: タスクトレイのアイコンを右クリック → 設定を開く")
            print(" 終了      : タスクトレイの「終了」 or このウィンドウを閉じる")
            print("-" * 56)
            state["input_count"] = 0
        set_overlay_state("idle")  # 一連の処理が完了 → 待機表示に戻す

    def delayed_start_beep():
        # 最低押し込み時間を超えても押し続けていれば「録音開始」を知らせる。
        # 短い押下(ショートカット操作)では鳴らさないので通知音が邪魔にならない。
        if state["recording"]:
            set_overlay_state("recording")
            if sound_on:
                feedback.recording_start()

    def force_stop_recording():
        """自己修復:録音が長すぎる時の暴走防止。

        旦那様がキーを離し忘れた・OS イベントが落ちた等で録音が
        無限に続くと、 後で Whisper に渡した時にハルシネーションや
        メモリ問題を起こす。 60秒で自動キャンセルする。
        """
        if state["recording"]:
            print(f" 録音が{MAX_RECORDING_SEC}秒を超えたので自動キャンセルします。")
            state["recording"] = False
            try:
                recorder.cancel()
            except Exception:
                pass
            flash_overlay_state("repair")  # 暴走録音の自動キャンセル=自動修復

    def reset_state():
        """緊急リセット(既定 Pause キー / settings.reset_hotkey で変更可)。

        録音中・認識中で固まった時に旦那様が手動で初期状態に戻せる。
        ツールを終了せずに復帰できるので長時間使用の自己修復として有効。
        Pause キーは Windows では事実上未使用なので衝突しない。
        Pause キーが無いキーボードの場合は settings.json の reset_hotkey で
        別のキー(例: "scroll lock" / "f9" / "ctrl+alt+r" 等)に変更可能。
        """
        print(" 緊急リセット:録音中・認識中の状態を強制リセットしました。")
        state["recording"] = False
        state["busy"] = False
        try:
            recorder.cancel()
        except Exception:
            pass
        for key in ("beep_timer", "max_timer"):
            t = state.pop(key, None)
            if t is not None:
                try:
                    t.cancel()
                except Exception:
                    pass
        try:
            flash_overlay_state("repair")  # 緊急リセット=手動の自己修復
        except Exception:
            pass

    def on_event(e):
        # 押下キーの追跡は busy 中も続ける(状態がずれないようにするため)
        name = (e.name or "").lower().strip()
        if name:
            # event_type は Win/Mac 共通の文字列("down" / "up")
            if e.event_type == "down":
                held_names.add(name)
            elif e.event_type == "up":
                held_names.discard(name)

        if state["busy"]:
            return
        # 録音キーを構成する全キー名が今押されているか(名前ベース判定)。
        # runtime["target_names"] は設定変更を自動検知して更新されるので、
        # 旦那様が設定画面で録音キーを変えると、 本体を再起動せずに反映される。
        down = _hotkey_matches(runtime["target_names"], held_names)
        # warmup 中は録音を始めない(モデル競合で初回が遅くなるのを防ぐ)。
        # 緊急リセットは別 hook なので warmup 中でもそのまま反応する。
        if state.get("warming_up") and down:
            return
        if down and not state["recording"]:
            state["recording"] = True
            state["t0"] = time.perf_counter()
            recorder.start()
            # すぐには鳴らさない。min_hold_sec を超えて押し続けた時だけ開始音を出す
            timer = threading.Timer(runtime["min_hold_sec"], delayed_start_beep)
            timer.daemon = True
            state["beep_timer"] = timer
            timer.start()
            # 自己修復:60秒を超える長押しは自動キャンセル(暴走防止)
            max_timer = threading.Timer(MAX_RECORDING_SEC, force_stop_recording)
            max_timer.daemon = True
            state["max_timer"] = max_timer
            max_timer.start()
        elif not down and state["recording"]:
            state["recording"] = False
            for key in ("beep_timer", "max_timer"):
                t = state.pop(key, None)
                if t is not None:
                    t.cancel()
            held = time.perf_counter() - state.get("t0", 0.0)
            if held < runtime["min_hold_sec"]:
                # 短すぎる押下 = Ctrl+C 等のショートカット操作。録音は破棄する
                recorder.cancel()
                set_overlay_state("idle")
                return
            # 認識は同期で実行する。 sounddevice の stream を別スレッドから
            # stop/close すると PortAudio が不安定になり「録音はされるが
            # 挿入されない」症状が出るため、 録音を開始した hook スレッドで
            # 全部完結させる。
            # 設定ホットキー(Ctrl+Shift+S)は録音キーと別物にしてあるので、
            # 録音中でも問題なく反応する。
            state["busy"] = True
            try:
                process()
            except Exception as e:
                print(f" 【エラー】処理に失敗しました: {e}")
                if sound_on:
                    try:
                        feedback.error()
                    except Exception:
                        pass
                flash_overlay_state("error")  # ランプに「エラー」を一時表示
            finally:
                state["busy"] = False

    # 設定画面は タスクトレイの右クリックメニュー から開く(Aqua Voice 流)。
    # keyboard hook は録音キーだけが触る構造になり、 設定起動と音声入力の
    # 衝突が原理的に発生しない。 トレイは別スレッドで動き、 設定は
    # os.startfile 経由で Windows シェルが起動するので親子関係ゼロ。

    # 緊急リセットのキー。 既定は Pause キー単独(Windowsでは事実上未使用)。
    # キーボードに Pause が無い場合は settings.json の "reset_hotkey" で
    # "scroll lock" / "f9" / "ctrl+alt+r" 等に変更可能。
    reset_hotkey = settings.get("reset_hotkey", "pause")
    pretty_reset_hotkey = pretty_key_label(reset_hotkey) or reset_hotkey

    def _register_hooks():
        """keyboard hook を(再)登録する。

        録音キーの追跡 (on_event) と緊急リセット (reset_hotkey) だけを扱う。
        設定起動はタスクトレイ経由なのでここには含めない。
        Windows の LowLevelHooksTimeout で hook が外された時に再登録できる。
        """
        try:
            unhook_all_global()
        except Exception:
            pass
        install_global_key_hook(on_event)
        try:
            add_emergency_reset_hotkey(reset_hotkey, reset_state)
        except Exception as e:
            print(f" 【警告】緊急リセットキー({reset_hotkey})の登録に失敗: {e}")

    # 既存の reset_state は state の初期化のみ。 keyboard 側の hook も
    # 再登録した方が「反応しない」状態から確実に復帰できるため、
    # reset_state の中で _register_hooks も呼ぶようにする。
    _orig_reset = reset_state

    def reset_state_with_hooks():  # noqa: F811
        _orig_reset()
        try:
            _register_hooks()
            print(" keyboard hook も再登録しました。")
        except Exception as e:
            print(f" hook 再登録に失敗: {e}")

    # reset_state 自体を差し替える(後段の keepalive とリセットキー両方で使う)
    reset_state = reset_state_with_hooks  # noqa: F811

    _register_hooks()
    print(f" 緊急リセット: {pretty_reset_hotkey}"
          " (録音中・認識中で固まった時に押す)")
    print(" 設定を開く  : タスクトレイのアイコンを右クリック → 設定を開く")
    print("               (または「設定を開く.bat」をダブルクリックでも可)")
    print("-" * 56)

    # --- タスクトレイ常駐(Aqua Voice 流の設定アクセス)-------------------
    # 設定画面の起動を「マウス操作」 だけに分離する。 keyboard hook と
    # 設定の subprocess が絡まないので、 「設定を開いたら音声入力が止まる」
    # 系の構造的衝突が原理的に発生しない。
    tray_icon = {"i": None}
    try:
        from tray import create_tray  # noqa: E402
        # 終了アクション: keepalive と keyboard.wait() を抜けてプロセス終了。
        # tkinter なしの素 Python で確実に終わるよう os._exit を使う。
        def _on_quit():
            print(" タスクトレイから終了が選択されました。 ツールを停止します。")
            try:
                stop_keepalive.set()
            except Exception:
                pass
            # 終了時に「今日の履歴」をバックで推敲(別プロセス・無窓)。
            # トレイは即閉じ、 推敲は切り離した pythonw プロセスが裏で続ける
            # ので、 終了が待たされない。 Ollama が無ければ何も起きない。
            try:
                if getattr(sys, "frozen", False):
                    import platform_compat
                    platform_compat.spawn_app_mode("proofread")
                else:
                    from tray import _find_pythonw, _spawn_detached, PROOFREAD_CLI
                    if PROOFREAD_CLI.exists():
                        _spawn_detached(_find_pythonw(), PROOFREAD_CLI)
            except Exception:
                pass
            os._exit(0)
        tray_icon["i"] = create_tray(on_reset=reset_state, on_quit=_on_quit)
        print(" タスクトレイにアイコンを表示しました。")
    except Exception as e:
        print(f" 【情報】タスクトレイの起動に失敗(設定を開く.bat から開けます): {e}")

    # 認識エンジンの warmup を「別スレッド」で温める(非同期)。
    # 同期実行だと 終了→再起動のたびに warmup 完了まで本体の開始が待たされる。
    # 非同期にすると トレイ・常駐ループは即動き、 録音キーだけが warming_up
    # ガードで温め完了まで待つ(録音の安全性は保たれる)。
    # ※ 根本的な「再起動の3秒遅延」は、 トレイの「PC起動時に自動で起動する」を
    #   オンにして常駐させ、 そもそも再起動しない運用で解消する。
    print(" 認識エンジンを裏で温めています(温め中も他の操作はできます)...")

    def _warmup_bg():
        _t0 = time.perf_counter()
        try:
            transcriber.warmup()
        except Exception as e:
            print(f" 【情報】warmup でエラー(無視して継続): {e}")
        finally:
            state["warming_up"] = False
        print(f" 準備完了({time.perf_counter() - _t0:.1f}秒)。録音できます。")

    threading.Thread(target=_warmup_bg, daemon=True).start()

    # --- hook keepalive(自動再登録)---------------------------------------
    # 「Ctrl+Alt 等の録音キーが反応しないことがある」症状の自己修復。
    # 1分ごとに hook を再登録し、 OS のタイムアウトで外されたままになる
    # ことを防ぐ。 録音中・認識中はスキップして副作用を避ける。
    KEEPALIVE_INTERVAL_SEC = 60.0
    stop_keepalive = threading.Event()

    def _hook_keepalive():
        while not stop_keepalive.is_set():
            if stop_keepalive.wait(KEEPALIVE_INTERVAL_SEC):
                break
            if state.get("recording") or state.get("busy"):
                continue
            # 修飾キーを押している最中に hook を登録し直すと、 unhook_all で
            # 押下中の Ctrl/Shift/Alt が「解放された」扱いになり、
            # 「ドラッグで選択 → Ctrl+C」が効かない・選択が外れる、という
            # 実害が出る(2026-07-20 旦那様報告)。 押している間は触らない。
            # OS に直接聞くので、 キー追跡の取りこぼしで永久に止まることはない。
            try:
                if (is_modifier_held("ctrl") or is_modifier_held("alt")
                        or is_modifier_held("shift")):
                    continue
            except Exception:
                pass
            try:
                _register_hooks()
            except Exception:
                pass

    threading.Thread(target=_hook_keepalive, daemon=True).start()

    # --- 設定変更の自動再同期 (settings.json の mtime 監視) -----------------
    # 旦那様が設定画面で録音キー・最小押し込み時間・緊急リセットキーを
    # 変えたら、 本体の再起動なしで自動反映する。 辞書/整形ルールは
    # process() の毎回 _load_config_safe で既に反映されるので、 ここでは
    # 「起動時に1度だけ読まれていた値」をライブにする役目を担う。
    SETTINGS_PATH = CONFIG_DIR / "settings.json"
    settings_mtime = {"v": SETTINGS_PATH.stat().st_mtime
                      if SETTINGS_PATH.exists() else 0.0}

    def _settings_watcher():
        nonlocal reset_hotkey, pretty_reset_hotkey
        while not stop_keepalive.is_set():
            if stop_keepalive.wait(3.0):  # 3秒ごとに mtime をチェック
                break
            try:
                if not SETTINGS_PATH.exists():
                    continue
                mt = SETTINGS_PATH.stat().st_mtime
                if mt == settings_mtime["v"]:
                    continue
                settings_mtime["v"] = mt
                # 設定が変わった -> 再読込
                new_cfg = _load_config_safe(fallback=state["config"])
                if new_cfg is None:
                    continue
                new_settings = new_cfg.get("settings", {})
                # 1. 録音キーの更新
                new_hotkey = new_settings.get("hotkey", runtime["hotkey_label"])
                if new_hotkey != runtime["hotkey_label"]:
                    runtime["target_names"] = parse_hotkey_label(new_hotkey)
                    runtime["hotkey_label"] = new_hotkey
                    pretty = pretty_key_label(new_hotkey) or new_hotkey
                    print(f" 設定反映: 録音キーを {pretty} に変更しました"
                          f"(再起動不要)。")
                # 2. min_hold_sec
                new_min = float(new_settings.get("min_hold_sec",
                                                 runtime["min_hold_sec"]))
                if abs(new_min - runtime["min_hold_sec"]) > 1e-6:
                    runtime["min_hold_sec"] = new_min
                    print(f" 設定反映: 最低押し込み時間を {new_min} 秒に"
                          f"変更しました。")
                # 3. 緊急リセットキー
                new_reset = new_settings.get("reset_hotkey", reset_hotkey)
                if new_reset != reset_hotkey:
                    reset_hotkey = new_reset
                    pretty_reset_hotkey = pretty_key_label(new_reset) or new_reset
                    try:
                        _register_hooks()
                        print(f" 設定反映: 緊急リセットキーを"
                              f" {pretty_reset_hotkey} に変更しました。")
                    except Exception as e:
                        print(f" 【警告】緊急リセットキーの再登録に失敗: {e}")
                # 4. state の config を最新に(次の process() で使われる)
                state["config"] = new_cfg
            except Exception as e:
                print(f" 【情報】設定の自動再同期でエラー(無視して継続): {e}")

    threading.Thread(target=_settings_watcher, daemon=True).start()

    # --- 自動推敲スケジューラ(常駐中も学習を回す)-------------------------
    # 句読点・誤変換の自動修正(推敲)は Ollama を使う重い処理。リアルタイム
    # 認識に影響しないよう「話していない時に・低優先度で・新しい内容がある
    # 時だけ」回す。終了後は proofread_cli がモデルをメモリから降ろす。
    # settings.json の auto_proofread:false で無効化できる。Ollama 未導入なら
    # proofread_cli が静かに何もしない(安全側)。
    # ①がONなら常駐開始と同時にOllamaもバックグラウンドで起こす(2026-07-19)。
    if settings.get("auto_proofread", True):
        threading.Thread(target=ensure_ollama_running, daemon=True).start()

    AUTO_CHECK_SEC = 3 * 60       # 3分ごとに条件を確認(学習頻度UP 2026-07-11)
    AUTO_IDLE_SEC = 8 * 60        # 最後の発話から8分静かなら実行(旧15分)
    AUTO_MIN_GAP_SEC = 20 * 60    # 自動実行どうしは最低20分あける(旧1時間)
    last_auto = {"t": 0.0, "mtime": 0.0}

    def _auto_proofread_scheduler():
        # 起動直後の高負荷を避けて少し待つ
        if stop_keepalive.wait(180):
            return
        while not stop_keepalive.is_set():
            try:
                cfg = state.get("config") or {}
                s = cfg.get("settings", {}) if isinstance(cfg, dict) else {}
                if s.get("auto_proofread", True) and not state.get("recording") \
                        and not state.get("busy"):
                    f = history.today_log()
                    if f.exists():
                        mt = f.stat().st_mtime
                        now = time.time()
                        if (mt > last_auto["mtime"]
                                and now - mt >= AUTO_IDLE_SEC
                                and now - last_auto["t"] >= AUTO_MIN_GAP_SEC):
                            _did_spawn = False
                            if getattr(sys, "frozen", False):
                                import platform_compat
                                platform_compat.spawn_app_mode(
                                    "proofread", low_priority=True)
                                _did_spawn = True
                            else:
                                from tray import (_find_pythonw,
                                                  _spawn_detached,
                                                  PROOFREAD_CLI)
                                if PROOFREAD_CLI.exists():
                                    _spawn_detached(_find_pythonw(),
                                                    PROOFREAD_CLI,
                                                    low_priority=True)
                                    _did_spawn = True
                            if _did_spawn:
                                last_auto["t"] = now
                                last_auto["mtime"] = mt
                                print(" 自動推敲: 今日の履歴を裏で推敲・学習中"
                                      "(低優先度)。")
            except Exception:
                pass
            if stop_keepalive.wait(AUTO_CHECK_SEC):
                break

    threading.Thread(target=_auto_proofread_scheduler, daemon=True).start()

    try:
        wait_forever()  # ウィンドウを閉じるまで常駐
    finally:
        stop_keepalive.set()
    return 0


def main():
    _setup_logging()  # 以後の print は logs/app.log にも残る(窓なしでも見られる)
    if len(sys.argv) >= 3 and sys.argv[1] == "--test-wav":
        return run_test_wav(sys.argv[2])
    return run_resident()


if __name__ == "__main__":
    sys.exit(main())
