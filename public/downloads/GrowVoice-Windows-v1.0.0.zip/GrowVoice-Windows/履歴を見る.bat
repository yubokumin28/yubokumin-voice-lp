@echo off
rem NOTE: keep this file in Shift-JIS (cp932) with ASCII-only comments.
chcp 932 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
if exist "%~dp0.venv\Scripts\python.exe" (set "PY=%~dp0.venv\Scripts\python.exe") else (set "PY=python")
"%PY%" src\history.py
