' start_voiceinput.vbs - launch the voice input tool with NO window at all.
'
' Why this exists:
'   Launching python directly (or even pythonw via a .lnk) can flash or keep a
'   console/terminal window on some setups. If the user closes that window the
'   tool dies. This VBScript starts pythonw fully hidden (window style = 0) and
'   does NOT wait, so there is never any visible window and nothing to close.
'   Used both for auto-start at login and for the desktop launch icon.

Dim sh, projDir, py, target
projDir = "C:\ClaudeCode\260520_voice-input"
py = projDir & "\.venv\Scripts\pythonw.exe"
target = projDir & "\src\hotkey_app.py"

Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = projDir
' 0 = hidden window, False = do not wait for it to finish
sh.Run """" & py & """ """ & target & """", 0, False
