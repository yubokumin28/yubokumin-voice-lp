@echo off
rem NOTE: keep this file in Shift-JIS (cp932) with ASCII-only comments.
chcp 932 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1

rem Open the settings GUI (hotkey + dictionaries) without a console window.
if exist "%~dp0.venv\Scripts\pythonw.exe" (set "PYW=%~dp0.venv\Scripts\pythonw.exe") else (set "PYW=pythonw")
start "" "%PYW%" src\settings_ui.py
