@echo off
rem 音声入力ツール 自動アップデート (Windows)
rem tools/updater.py を呼んで GitHub Releases から最新版を取得し差分上書き。
rem config/ logs/ .venv/ は保護(中身は触らない)。
rem 既存 .bat には触らず、追加配置のみ。
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1

if exist "%~dp0.venv\Scripts\python.exe" (
    set "PY=%~dp0.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

echo ============================================================
echo  音声入力ツール アップデート確認
echo ============================================================
echo.

"%PY%" "%~dp0tools\updater.py" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo 完了。次回起動時から新しいバージョンになります。
) else (
    echo (終了コード %RC%)
)
echo.
pause
exit /b %RC%
