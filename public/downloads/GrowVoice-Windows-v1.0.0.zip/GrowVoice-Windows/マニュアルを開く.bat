@echo off
rem manual.html を既定ブラウザで開く (Windows)
rem 既存 .bat には触らず、追加配置のみ。
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist "%~dp0manual.html" (
    echo manual.html がまだありません ^(Step 7 で作成予定^)。
    pause
    exit /b 1
)

start "" "%~dp0manual.html"
