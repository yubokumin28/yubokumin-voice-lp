# -*- coding: utf-8 -*-
"""learning.py - 育つAI 第2段(誤変換の自動学習・承認制)

第1段(punctuate.proofread_history_file)が出力した推敲版履歴と、推敲前の
履歴を突き合わせ、「繰り返し出る誤変換ペア」の候補を抽出して蓄積する。

候補は自動では辞書に入れない。設定UIの「学習」タブで旦那様が承認した
ものだけが config/replacements.json 等へ登録される(承認制)。

設計方針:
  - Ollama 等のAIは呼ばない。純粋な文字列処理のみ(数十msで完了)。
  - 句読点・鉤括弧・空白の付与は推敲由来の差分なので候補にしない。
  - 短すぎる wrong は全域置換で誤爆するため候補にしない(安全側)。
  - 同じ日の推敲を何度やり直しても二重カウントしない(daily を差し替え)。
  - 却下(rejected)した候補は記録に残し、二度と提示しない。
"""

import difflib
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# punctuate.py の履歴行と同じ形式("[HH:MM:SS] 本文")
_HISTORY_LINE_RE = re.compile(r"^(\[\d{2}:\d{2}:\d{2}\]\s*)(.*)$")

# 推敲が足し引きする可能性のある記号類。比較・トリミングの対象。
_PUNCT_CHARS = "、。「」『』・…?!?!,.,.()()  \t"
_PUNCT_STRIP_RE = re.compile("[" + re.escape(_PUNCT_CHARS) + r"\s]")

# 候補の安全上限
_MAX_WRONG_LEN = 12          # 辞書に入れる wrong の最大長
_MAX_EXPAND_PER_SIDE = 4     # 境界拡張で左右それぞれ伸ばせる文字数
_MAX_PENDING = 200           # pending 候補の保持上限
_MAX_EXAMPLES = 3            # 候補ごとに残す例文の数
_EXAMPLE_CONTEXT = 15        # 例文として残す前後の文字数


# ---------------------------------------------------------------------------
# 文字種の判定(境界拡張で使う)
# ---------------------------------------------------------------------------

def _char_class(c):
    """文字種を返す: kanji / hira / kata / alnum / other。"""
    o = ord(c)
    if 0x4E00 <= o <= 0x9FFF or c in "々〆":
        return "kanji"
    if 0x3041 <= o <= 0x309F:
        return "hira"
    if 0x30A1 <= o <= 0x30FF or c == "ー":
        return "kata"
    if c.isascii() and c.isalnum():
        return "alnum"
    if 0xFF10 <= o <= 0xFF19 or 0xFF21 <= o <= 0xFF3A or 0xFF41 <= o <= 0xFF5A:
        return "alnum"  # 全角英数
    return "other"


def _strip_punct(text):
    """比較用に句読点・記号・空白を除いた文字列を返す。"""
    return _PUNCT_STRIP_RE.sub("", text)


def _kana_fold(text):
    """カタカナをひらがなに畳んだ文字列を返す(揺れ判定用)。"""
    return "".join(
        chr(ord(c) - 0x60) if 0x30A1 <= ord(c) <= 0x30F6 else c
        for c in text
    )


def _is_all_digits(text):
    """数字(半角・全角)だけで構成されているか。"""
    return bool(text) and all(
        c.isdigit() or 0xFF10 <= ord(c) <= 0xFF19 for c in text
    )


# ---------------------------------------------------------------------------
# 履歴ファイルの突き合わせ
# ---------------------------------------------------------------------------

def _read_body_lines(path):
    """履歴ファイルから [(タイムスタンプ前置, 本文), ...] を取り出す。

    補足行 "    (認識の生テキスト: ...)" や空行は読み飛ばす。
    """
    result = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        m = _HISTORY_LINE_RE.match(line)
        if m and m.group(2).strip():
            result.append((m.group(1), m.group(2)))
    return result


def _pair_lines(history_path, refined_path):
    """推敲前後の本文行を、タイムスタンプで対応付けて返す。

    推敲版は履歴より少し前に作られる(=行数が少ない)ことが多いため、
    行数の一致は要求しない。同じタイムスタンプ([HH:MM:SS])の行同士だけを
    安全に突き合わせる。同一タイムスタンプが複数ある行は、誤対応を避けるため
    両側とも除外する(安全側)。これで「行数がズレると学習が丸ごと0になる」
    問題を防ぐ。
    """
    try:
        before_lines = _read_body_lines(history_path)
        after_lines = _read_body_lines(refined_path)
    except OSError:
        return []

    def _counts(lines):
        c = {}
        for ts, _body in lines:
            k = ts.strip()
            c[k] = c.get(k, 0) + 1
        return c

    before_dup = {k for k, n in _counts(before_lines).items() if n > 1}
    after_dup = {k for k, n in _counts(after_lines).items() if n > 1}
    after_map = {ts.strip(): body for ts, body in after_lines
                 if ts.strip() not in after_dup}

    pairs = []
    for ts, body_b in before_lines:
        k = ts.strip()
        if k in before_dup or k not in after_map:
            continue
        pairs.append((body_b, after_map[k]))
    return pairs


# ---------------------------------------------------------------------------
# 1行ペアからの候補抽出
# ---------------------------------------------------------------------------

def _merged_replace_blocks(before, after):
    """SequenceMatcher の replace ブロックを取り出す。

    1文字以下の equal を挟んで隣接する replace は1つに結合する
    (活用形の途中一致などで差分が細切れになるのを防ぐ)。
    insert(句読点追加)/ delete(フィラー削除)は候補にしない。
    """
    sm = difflib.SequenceMatcher(None, before, after, autojunk=False)
    blocks = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != "replace":
            continue
        if blocks:
            p_i1, p_i2, p_j1, p_j2 = blocks[-1]
            # 直前の replace との間が「1文字以下の equal」だけなら結合
            if i1 - p_i2 == j1 - p_j2 and 0 <= i1 - p_i2 <= 1:
                blocks[-1] = (p_i1, i2, p_j1, j2)
                continue
        blocks.append((i1, i2, j1, j2))
    return blocks


def _expand_boundary(before, after, i1, i2, j1, j2):
    """短すぎる差分を、同じ文字種が続く範囲まで左右に広げる。

    「苦→駆」のような1文字置換は辞書に入れると危険なので、前後の一致
    文脈(「出線」等)を取り込んで「苦出線→駆出線」の形にする。
    拡張は wrong が3文字に届くまで、左右それぞれ最大4文字。
    """
    left = 0
    while (
        i2 - i1 < 3
        and left < _MAX_EXPAND_PER_SIDE
        and i1 > 0
        and j1 > 0
        and before[i1 - 1] == after[j1 - 1]
        and i2 > i1 and j2 > j1
        and _char_class(before[i1 - 1]) == _char_class(before[i1])
        and _char_class(after[j1 - 1]) == _char_class(after[j1])
    ):
        i1 -= 1
        j1 -= 1
        left += 1
    right = 0
    while (
        i2 - i1 < 3
        and right < _MAX_EXPAND_PER_SIDE
        and i2 < len(before)
        and j2 < len(after)
        and before[i2] == after[j2]
        and i2 > i1 and j2 > j1
        and _char_class(before[i2]) == _char_class(before[i2 - 1])
        and _char_class(after[j2]) == _char_class(after[j2 - 1])
    ):
        i2 += 1
        j2 += 1
        right += 1
    return i1, i2, j1, j2


def _trim_punct_edges(w, r):
    """両端の句読点・記号を落とす(「、エレメス」→「エレメス」)。"""
    punct = set(_PUNCT_CHARS) | {" "}
    while w and r and w[0] in punct and r[0] in punct and w[0] == r[0]:
        w, r = w[1:], r[1:]
    while w and r and w[-1] in punct and r[-1] in punct and w[-1] == r[-1]:
        w, r = w[:-1], r[:-1]
    w = w.strip("".join(punct))
    r = r.strip("".join(punct))
    return w, r


def extract_pairs(history_path, refined_path):
    """推敲前後の履歴ファイルから誤変換ペア候補を抽出する。

    返り値: [{"wrong":, "right":, "core_wrong":, "core_right":, "example":}, ...]
    (頻度カウントや既存辞書との照合は update_from_refined 側で行う)
    """
    results = []
    for before, after in _pair_lines(history_path, refined_path):
        if before == after:
            continue
        for i1, i2, j1, j2 in _merged_replace_blocks(before, after):
            core_w = before[i1:i2]
            core_r = after[j1:j2]
            # 句読点・空白だけの差分は推敲由来なので捨てる
            if _strip_punct(core_w) == _strip_punct(core_r):
                continue
            # 行の過半を占める差分は推敲AIの書き換えすぎ(信頼できない)
            if i1 == 0 and i2 == len(before):
                continue  # 行全体の置き換え
            if len(core_w) >= max(10, 0.5 * len(before)):
                continue
            # 境界拡張(危険な極小差分を文脈ごと取り込む)
            e1, e2, f1, f2 = _expand_boundary(before, after, i1, i2, j1, j2)
            w, r = _trim_punct_edges(before[e1:e2], after[f1:f2])
            core_w, core_r = _trim_punct_edges(core_w, core_r)
            if not w or not r or w == r:
                continue
            if _strip_punct(w) == _strip_punct(r):
                continue
            # 安全フィルタ
            if len(w) <= 2:
                continue
            if len(w) <= 3 and all(_char_class(c) == "hira" for c in w):
                continue
            if len(w) > _MAX_WRONG_LEN:
                continue
            if _is_all_digits(_strip_punct(w)):
                continue
            # 例文: 差分の前後を少し含めて切り出す
            s = max(0, e1 - _EXAMPLE_CONTEXT)
            e = min(len(before), e2 + _EXAMPLE_CONTEXT)
            example = ("…" if s > 0 else "") + before[s:e] + ("…" if e < len(before) else "")
            results.append({
                "wrong": w,
                "right": r,
                "core_wrong": core_w or w,
                "core_right": core_r or r,
                "example": example,
            })
    return results


# ---------------------------------------------------------------------------
# 既存辞書の読み込み(候補との重複・競合チェック用)
# ---------------------------------------------------------------------------

def _load_existing_dict(config_dir):
    """既存辞書を {wrong: right} で返す(壊れていても落とさない寛容版)。"""
    config_dir = Path(config_dir)
    existing = {}

    def _load_json(name):
        path = config_dir / name
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

    data = _load_json("replacements.json")
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("wrong"):
                existing[item["wrong"]] = item.get("right", "")

    data = _load_json("construction_terms.json")
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("enabled") and item.get("wrong"):
                existing[item["wrong"]] = item.get("right", "")

    data = _load_json("symbols.json")
    if isinstance(data, dict):
        for k, v in data.items():
            if k and not k.startswith("_"):
                existing[k] = v

    return existing


def _load_settings_json(config_dir):
    """settings.json を読む(無い・壊れている時は空 dict)。"""
    path = Path(config_dir) / "settings.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _load_hotwords(config_dir):
    """settings.json の hotwords(空白区切り文字列)を set で返す。"""
    settings = _load_settings_json(config_dir)
    return set((settings.get("hotwords", "") or "").split())


def _append_replacements(config_dir, pairs, provisional=False):
    """言い換え辞書(replacements.json)にペアを追記する。

    既に同じ wrong がある場合は追加しない(競合を作らない)。
    ファイルが壊れている時は何も書かず 0 を返す(データ保護優先)。
    provisional=True のときは「仮登録(確認中)」の印を付ける。仮登録は次の
    推敲で裏付けが取れれば確定、別の変換と矛盾したら自動で撤回される。
    返り値: 実際に追加した件数。
    """
    path = Path(config_dir) / "replacements.json"
    rules = []
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                return 0
            rules = data
        except Exception:
            return 0
    known_wrongs = {r.get("wrong") for r in rules if isinstance(r, dict)}
    added = 0
    for w, r in pairs:
        if not w or not r or w == r or w in known_wrongs:
            continue
        # origin=learning の印で「学習(AI自動登録)」分を識別できる。
        # enabled=True で登録(辞書タブでチェックを外すと False になる)。
        rule = {"wrong": w, "right": r, "enabled": True, "origin": "learning"}
        if provisional:
            rule["provisional"] = True   # 確認中(1回で覚えた仮の登録)
        rules.append(rule)
        known_wrongs.add(w)
        added += 1
    if added:
        if path.exists():
            try:
                shutil.copy2(path, path.with_name("replacements.json.bak"))
            except OSError:
                pass
        path.write_text(
            json.dumps(rules, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return added


# ---------------------------------------------------------------------------
# 候補ストア(config/learning_candidates.json)
# ---------------------------------------------------------------------------

def candidates_path(config_dir=None):
    base = Path(config_dir) if config_dir else (ROOT / "config")
    return base / "learning_candidates.json"


def _load_store(path):
    """候補ストアを読む。壊れていたら .bak に退避して空から再開する。"""
    path = Path(path)
    if not path.exists():
        return {"version": 1, "candidates": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("candidates"), list):
            raise ValueError("unexpected structure")
        return data
    except Exception:
        try:
            shutil.copy2(path, path.with_suffix(".json.broken.bak"))
        except OSError:
            pass
        return {"version": 1, "candidates": []}


def _save_store(path, store):
    """候補ストアを保存する(上書き前に .bak を残す)。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        try:
            shutil.copy2(path, path.with_suffix(".json.bak"))
        except OSError:
            pass
    path.write_text(
        json.dumps(store, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _candidate_count(cand):
    return sum(cand.get("daily", {}).values())


def _refresh_seen_dates(cand):
    days = sorted(cand.get("daily", {}).keys())
    if days:
        cand["first_seen"] = f"{days[0][:4]}-{days[0][4:6]}-{days[0][6:]}"
        cand["last_seen"] = f"{days[-1][:4]}-{days[-1][4:6]}-{days[-1][6:]}"


def _shrink_resolved(cand):
    """approved/rejected は再提示防止に必要な情報だけ残して軽量化する。"""
    shrunk = {
        "wrong": cand.get("wrong", ""),
        "right": cand.get("right", ""),
        "core_wrong": cand.get("core_wrong", cand.get("wrong", "")),
        "core_right": cand.get("core_right", cand.get("right", "")),
        "status": cand.get("status", ""),
    }
    if cand.get("auto"):
        shrunk["auto"] = True  # 自動登録だった印(あとから追跡できるように)
    return shrunk


def _total_count(cand):
    """variants も含めた出現回数の合計。"""
    return _candidate_count(cand) + sum(
        sum(v.get("daily", {}).values()) for v in cand.get("variants", [])
    )


def _is_fast_track_safe(wrong, right, fast_min_len):
    """1回の出現でも自動登録してよい「衝突しにくい」候補か判定する。

    全文置換で事故るのは「短い・ありふれた語」。逆に長い固有名詞
    (パイコーン→Pinecone 等)は別語の一部に紛れにくく、1回で覚えても安全。
      - wrong が fast_min_len 文字以上(既定4)= 長くて誤爆しにくい
      - wrong と right が異なる
    短い語・ASCII 略語(sns/win/html 等)は対象外 → 従来どおり2回必要。
    """
    w = (wrong or "").strip()
    r = (right or "").strip()
    if not w or not r or w == r:
        return False
    if len(w) < fast_min_len:
        return False
    return True


def _self_heal_provisional(config_dir, day_counts, candidates):
    """仮登録(確認中)の自動検証。1回で覚えた間違いを引きずらないための仕組み。

    登録済みの語は以降フォーマッタが自動変換するので、間違った「入力」は履歴に
    二度と現れない。そこで信号は「登録した出力」に置く:
      - 仮登録 w→r の『出力 r』が、今回の推敲でさらに別の語へ直された
        (= r が wrong として現れた)→ r は誤りだった疑い → 撤回。
        候補ストアも pending に戻して再学習できるようにする。
      - 同じ w→r がもう一度出た(テスト・取りこぼし時)→ 裏付け → 確定。
      - どちらでもない → そのまま様子見(仮のまま稼働。辞書タブで手動削除も可)。
    """
    path = Path(config_dir) / "replacements.json"
    if not path.exists():
        return
    try:
        rules = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return
    if not isinstance(rules, list):
        return

    day_rights = {}
    wrongs_today = set()
    for (w, r) in day_counts:
        day_rights.setdefault(w, set()).add(r)
        wrongs_today.add(w)

    def _to_pending(w, r):
        for c in candidates:
            if (c.get("wrong") == w and c.get("right") == r
                    and c.get("status") == "approved" and c.get("auto")):
                c["status"] = "pending"
                c.pop("provisional", None)
                c.pop("auto", None)

    changed = False
    kept = []
    for rule in rules:
        if not (isinstance(rule, dict) and rule.get("provisional")):
            kept.append(rule)
            continue
        w, r = rule.get("wrong"), rule.get("right")
        if r and r != w and r in wrongs_today:
            # 出力 r がさらに直された = 覚えた変換が誤りの疑い → 撤回
            changed = True
            _to_pending(w, r)
        elif w in day_rights and r in day_rights.get(w, ()):
            rule.pop("provisional", None)   # 再確認 → 確定
            kept.append(rule)
            changed = True
            for c in candidates:
                if (c.get("wrong") == w and c.get("right") == r
                        and c.get("status") == "approved"):
                    c["provisional"] = False
        else:
            kept.append(rule)               # 様子見
    if changed:
        try:
            shutil.copy2(path, path.with_name("replacements.json.bak"))
        except OSError:
            pass
        path.write_text(
            json.dumps(kept, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8")


def _auto_register(candidates, config_dir):
    """安全な候補を自動で辞書登録する(育つAI第2段の自動化)。

    自動登録する条件(全部満たすものだけ):
      - 競合なし(既存辞書・認識ヒントと衝突していない)
      - 出現回数がしきい値以上
          * 通常: learning_auto_min_count 回(既定2回 = 繰り返し出る)
          * 早期登録: 衝突しにくい長い語(_is_fast_track_safe)は1回でも可
            (learning_fast_track:false で無効化、learning_fast_min_len で長さ調整)
      - 同じ wrong に対し right が1通り(推敲のブレで割れていない)
    条件を満たさないものは pending のまま残り、設定UIの「学習」タブで
    旦那様が判断する。settings.json の learning_auto:false で全面無効化。
    返り値: 辞書に追加した件数。
    """
    settings = _load_settings_json(config_dir)
    if not settings.get("learning_auto", True):
        return 0
    min_count = int(settings.get("learning_auto_min_count", 2))
    fast_track = bool(settings.get("learning_fast_track", True))
    fast_min_len = int(settings.get("learning_fast_min_len", 4))
    pendings = [c for c in candidates if c.get("status") == "pending"]
    rights_by_wrong = {}
    for c in pendings:
        rights_by_wrong.setdefault(c.get("wrong"), set()).add(c.get("right"))
    pairs_conf = []   # 確定(2回以上の裏付けあり)
    pairs_prov = []   # 仮登録(長い語を1回で覚えた・確認中)
    eligible = []
    for c in pendings:
        if c.get("conflict"):
            continue
        total = _total_count(c)
        is_fast = fast_track and _is_fast_track_safe(
            c.get("wrong"), c.get("right"), fast_min_len)
        # 衝突しにくい長い語は1回でも、それ以外は min_count 回で登録。
        need = 1 if is_fast else min_count
        if total < need:
            continue
        if len(rights_by_wrong.get(c.get("wrong"), set())) > 1:
            continue  # 表記が割れている = 判断に困る → 安定するまで待つ
        # min_count 未満で入る = 1回きりの早期登録 → 仮登録にして自己修正対象に。
        provisional = total < min_count
        bucket = pairs_prov if provisional else pairs_conf
        c["_provisional"] = provisional
        eligible.append(c)
        bucket.append((c.get("wrong"), c.get("right")))
        for v in c.get("variants", []):
            if v.get("wrong") and v.get("right") and v["wrong"] != v["right"]:
                bucket.append((v["wrong"], v["right"]))
    if not pairs_conf and not pairs_prov:
        return 0
    added = (_append_replacements(config_dir, pairs_conf, provisional=False)
             + _append_replacements(config_dir, pairs_prov, provisional=True))
    if added:
        # 書き込みに成功した時だけ承認済みにする(失敗時は pending のまま)
        for c in eligible:
            c["status"] = "approved"
            c["auto"] = True
            c["provisional"] = bool(c.pop("_provisional", False))
    return added


# ---------------------------------------------------------------------------
# 取り込み(推敲のたびに proofread_cli から呼ばれる)
# ---------------------------------------------------------------------------

def _date_key_from_path(history_path):
    m = re.search(r"history_(\d{8})", Path(history_path).name)
    if m:
        return m.group(1)
    import datetime
    return f"{datetime.datetime.now():%Y%m%d}"


def update_from_refined(history_path, refined_path, config_dir=None):
    """推敲結果から候補を抽出し、候補ストアへ冪等にマージする。

    同じ日のファイルで何度呼んでも daily[日付] を差し替えるだけなので
    二重カウントしない。返り値: pending 候補の総数。
    """
    config_dir = Path(config_dir) if config_dir else (ROOT / "config")
    store_path = candidates_path(config_dir)
    store = _load_store(store_path)
    date_key = _date_key_from_path(history_path)

    extracted = extract_pairs(history_path, refined_path)

    # 今日の出現回数を (wrong, right) ごとに集計
    day_counts = {}
    day_examples = {}
    for item in extracted:
        key = (item["wrong"], item["right"])
        day_counts[key] = day_counts.get(key, 0) + 1
        day_examples.setdefault(key, item)

    existing = _load_existing_dict(config_dir)
    hotwords = _load_hotwords(config_dir)
    candidates = store["candidates"]

    # 仮登録(確認中)の自己修正: 裏付けが取れれば確定、矛盾すれば撤回。
    # 撤回時は候補を pending に戻すので、解決済み判定より前に行う。
    _self_heal_provisional(config_dir, day_counts, candidates)

    # 解決済み(approved/rejected)のコアキー: 再提示しない
    resolved_cores = {
        (c.get("core_wrong"), c.get("core_right"))
        for c in candidates
        if c.get("status") in ("approved", "rejected")
    }
    resolved_pairs = {
        (c.get("wrong"), c.get("right"))
        for c in candidates
        if c.get("status") in ("approved", "rejected")
    }

    # この日付の古いカウントを全候補から消す(冪等性: 差し替え方式)
    for cand in candidates:
        if cand.get("status") == "pending":
            cand.get("daily", {}).pop(date_key, None)
            for v in cand.get("variants", []):
                v.get("daily", {}).pop(date_key, None)

    for (w, r), count in day_counts.items():
        item = day_examples[(w, r)]
        core_key = (item["core_wrong"], item["core_right"])
        # 既存辞書と完全一致 → 登録済みなので取り込まない
        if existing.get(w) == r:
            continue
        # 解決済み(承認/却下済み)→ 再提示しない
        if core_key in resolved_cores or (w, r) in resolved_pairs:
            continue
        conflict = (w in existing and existing.get(w) != r) or (w in hotwords)

        target = _find_merge_target(candidates, w, r, core_key)
        if target is None:
            target = {
                "wrong": w,
                "right": r,
                "core_wrong": item["core_wrong"],
                "core_right": item["core_right"],
                "daily": {},
                "examples": [],
                "status": "pending",
                "conflict": False,
                "variants": [],
            }
            candidates.append(target)
        _merge_into(target, w, r, count, date_key, item["example"], core_key)
        target["conflict"] = bool(target.get("conflict")) or conflict

    # 出現が消えた pending(daily が空)を掃除
    candidates[:] = [
        c for c in candidates
        if c.get("status") != "pending" or c.get("daily")
    ]

    _fold_redundant(candidates)

    for cand in candidates:
        if cand.get("status") == "pending":
            _refresh_seen_dates(cand)

    # 安全な候補(繰り返し出る・競合なし・表記割れなし)は自動で辞書登録。
    # 判断に困るものだけが pending に残り、設定UIの「学習」タブに出る。
    _auto_register(candidates, config_dir)

    _prune(candidates)
    store["candidates"] = [
        _shrink_resolved(c) if c.get("status") in ("approved", "rejected")
        else c
        for c in candidates
    ]
    _save_store(store_path, store)
    return sum(1 for c in candidates if c.get("status") == "pending")


def _find_merge_target(candidates, w, r, core_key):
    """新しい (w, r) を合流させるべき既存 pending 候補を探す。"""
    fold_w, fold_r = _kana_fold(w), _kana_fold(r)
    for cand in candidates:
        if cand.get("status") != "pending":
            continue
        # 完全一致
        if cand.get("wrong") == w and cand.get("right") == r:
            return cand
        # コア一致(活用形の前後文脈だけ違う)
        if (cand.get("core_wrong"), cand.get("core_right")) == core_key:
            return cand
        # かな揺れ(畳むと同じ・right も同じ)
        if (_kana_fold(cand.get("wrong", "")) == fold_w
                and _kana_fold(cand.get("right", "")) == fold_r
                and cand.get("right") == r):
            return cand
        for v in cand.get("variants", []):
            if v.get("wrong") == w and v.get("right") == r:
                return cand
    return None


def _merge_into(cand, w, r, count, date_key, example, core_key):
    """候補 cand に (w, r) の今日の出現を合流させる。"""
    if cand.get("wrong") == w and cand.get("right") == r:
        cand.setdefault("daily", {})[date_key] = (
            cand.get("daily", {}).get(date_key, 0) + count
        )
    else:
        # 表記違い(コア一致・かな揺れ)は variants 側でカウント
        for v in cand.setdefault("variants", []):
            if v.get("wrong") == w and v.get("right") == r:
                v.setdefault("daily", {})[date_key] = (
                    v.get("daily", {}).get(date_key, 0) + count
                )
                break
        else:
            cand["variants"].append({"wrong": w, "right": r,
                                     "daily": {date_key: count}})
        # コア一致(活用形の前後文脈違い)なら、より短く安全な方を代表に採用
        is_core_match = (
            (cand.get("core_wrong"), cand.get("core_right")) == core_key
        )
        if (is_core_match and len(w) >= 3
                and len(w) < len(cand.get("wrong", ""))):
            old_w, old_r = cand.get("wrong"), cand.get("right")
            cand["wrong"], cand["right"] = w, r
            # 元の代表は variants に退避し、新代表は variants から外す
            if not any(v.get("wrong") == old_w and v.get("right") == old_r
                       for v in cand["variants"]):
                cand["variants"].append(
                    {"wrong": old_w, "right": old_r, "daily": {}})
            new_variants = []
            for v in cand["variants"]:
                if v.get("wrong") == w and v.get("right") == r:
                    # 新代表の出現カウントは本体 daily へ移す
                    for dk, n in v.get("daily", {}).items():
                        cand.setdefault("daily", {})[dk] = (
                            cand.get("daily", {}).get(dk, 0) + n
                        )
                else:
                    new_variants.append(v)
            cand["variants"] = new_variants
    examples = cand.setdefault("examples", [])
    if example and example not in examples and len(examples) < _MAX_EXAMPLES:
        examples.append(example)


def _fold_redundant(candidates):
    """候補Aを候補Bに適用するとBが再現できるなら、BをAへ畳む。

    例: A=(苦出線→駆出線) があれば B=(苦出線した→駆出線した) は不要。
    """
    pendings = [c for c in candidates if c.get("status") == "pending"]
    removed = set()
    for a in pendings:
        if id(a) in removed:
            continue
        aw, ar = a.get("wrong", ""), a.get("right", "")
        if not aw or not ar:
            continue
        for b in pendings:
            if b is a or id(b) in removed:
                continue
            bw, br = b.get("wrong", ""), b.get("right", "")
            if aw in bw and bw.replace(aw, ar) == br:
                # B の出現回数を A に合算して B を消す
                for dk, n in b.get("daily", {}).items():
                    a.setdefault("daily", {})[dk] = (
                        a.get("daily", {}).get(dk, 0) + n
                    )
                for ex in b.get("examples", []):
                    if ex not in a.setdefault("examples", []) \
                            and len(a["examples"]) < _MAX_EXAMPLES:
                        a["examples"].append(ex)
                a["conflict"] = bool(a.get("conflict")) or bool(b.get("conflict"))
                removed.add(id(b))
    candidates[:] = [c for c in candidates if id(c) not in removed]


def _prune(candidates):
    """pending の保持上限を超えたら、頻度が低く古いものから削る。"""
    pendings = [c for c in candidates if c.get("status") == "pending"]
    if len(pendings) <= _MAX_PENDING:
        return
    pendings.sort(key=lambda c: (_candidate_count(c), c.get("last_seen", "")))
    drop = {id(c) for c in pendings[: len(pendings) - _MAX_PENDING]}
    candidates[:] = [c for c in candidates if id(c) not in drop]


# ---------------------------------------------------------------------------
# 承認UI向けAPI(settings_ui.py から呼ばれる)
# ---------------------------------------------------------------------------

def load_pending(config_dir=None, min_count=2):
    """承認待ち候補を頻度降順で返す。min_count 未満は省く(既定: 2回以上)。

    各要素は候補 dict のコピーに "count" を足したもの。
    """
    store = _load_store(candidates_path(config_dir))
    result = []
    for cand in store["candidates"]:
        if cand.get("status") != "pending":
            continue
        count = _candidate_count(cand) + sum(
            sum(v.get("daily", {}).values()) for v in cand.get("variants", [])
        )
        if count < (min_count or 1):
            continue
        item = dict(cand)
        item["count"] = count
        result.append(item)
    # 回数降順 → 最終確認日降順(安定ソートを2段重ね)
    result.sort(key=lambda c: c.get("last_seen", ""), reverse=True)
    result.sort(key=lambda c: c["count"], reverse=True)
    return result


def pending_count(config_dir=None, min_count=2):
    """学習タブの見出しに出す件数。"""
    return len(load_pending(config_dir, min_count))


def approve(wrong, right, config_dir=None):
    """候補を承認済みにする。

    返り値: 辞書に登録すべき (wrong, right) ペアのリスト(variants 含む)。
    同じ wrong を持つ他の pending 候補(right 違い=推敲のブレ)は
    自動で rejected にする(1つ選んだら他は不要)。
    実際の辞書ファイルへの書き込みは呼び出し側(設定UI)が行う。
    """
    path = candidates_path(config_dir)
    store = _load_store(path)
    pairs = []
    for cand in store["candidates"]:
        if cand.get("status") != "pending":
            continue
        if cand.get("wrong") == wrong and cand.get("right") == right:
            cand["status"] = "approved"
            pairs.append((wrong, right))
            for v in cand.get("variants", []):
                if v.get("wrong") and v.get("right") \
                        and (v["wrong"], v["right"]) not in pairs \
                        and v["wrong"] != v["right"]:
                    pairs.append((v["wrong"], v["right"]))
    if pairs:
        for cand in store["candidates"]:
            if cand.get("status") == "pending" and cand.get("wrong") == wrong:
                cand["status"] = "rejected"
        store["candidates"] = [
            _shrink_resolved(c) if c.get("status") in ("approved", "rejected")
            else c
            for c in store["candidates"]
        ]
        _save_store(path, store)
    return pairs


def reject(wrong, right, config_dir=None):
    """候補を却下する(記録に残り、二度と提示されない)。"""
    path = candidates_path(config_dir)
    store = _load_store(path)
    changed = False
    for cand in store["candidates"]:
        if (cand.get("status") == "pending"
                and cand.get("wrong") == wrong and cand.get("right") == right):
            cand["status"] = "rejected"
            changed = True
    if changed:
        store["candidates"] = [
            _shrink_resolved(c) if c.get("status") in ("approved", "rejected")
            else c
            for c in store["candidates"]
        ]
        _save_store(path, store)
    return changed
