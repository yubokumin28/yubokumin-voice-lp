# -*- coding: utf-8 -*-
"""make_ico.py - トレイと同じ黄色マイクのアイコンを .ico ファイルに書き出す。

専用 exe(音声入力ツール.exe)に埋め込むためのアイコン。 tray.py の
_make_icon_image をそのまま使うので、 トレイの実物と完全に同じ絵になる。
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from tray import _make_icon_image  # noqa: E402

OUT = ROOT / "assets" / "voice_input.ico"


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    img = _make_icon_image(256)
    img.save(
        str(OUT),
        sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    print("ico:", OUT)


if __name__ == "__main__":
    main()
