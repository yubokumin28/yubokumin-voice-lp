# -*- coding: utf-8 -*-
"""detect_spec.py - マシンスペックを 1 つの JSON にまとめて出力する。

両 OS 対応:
  - Windows: WMI 経由(or wmic フォールバック)で CPU / RAM / GPU を取得し、
            CUDA 利用可否は torch.cuda → nvidia-smi の順で判定。
  - macOS:  sysctl + system_profiler で CPU / RAM / GPU を取得。

出力スキーマ(STDOUT に JSON 1 行):
  {
    "os": "windows" | "darwin",
    "arch": "x86_64" | "arm64",
    "cpu": "Intel(R) Core(TM) Ultra 7 265F" | "Apple M2",
    "ram_gb": 32,
    "gpu_name": "NVIDIA GeForce RTX 5060 Ti" | "Apple M2 GPU" | null,
    "gpu_vram_gb": 16 | null,
    "cuda_available": true | false,
    "apple_silicon": true | false
  }

設計方針:
  - 重い依存は使わない。WMI/sysctl/system_profiler/wmic のような OS 標準ツールを直接叩く。
  - 失敗してもクラッシュさせず、取れた値だけ詰めて返す(下流の pick_ollama_model.py が安全側にフォールバックする)。
  - sys.platform で直接分岐(platform_compat は使わない、tools/ は独立に動かしたい)。
"""

import json
import platform
import re
import shutil
import subprocess
import sys
from typing import Optional


def _run(cmd, timeout=8) -> str:
    try:
        out = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=False
        )
        return (out.stdout or "") + (out.stderr or "")
    except Exception:
        return ""


# ---------- Windows ----------

def _powershell(script: str) -> str:
    """軽量 PowerShell 呼び出し。Win11 で wmic が無いときの主力。"""
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return ""
    return _run([ps, "-NoProfile", "-NonInteractive", "-Command", script])


def _win_cpu_name() -> Optional[str]:
    # まず wmic(Win10 まで)、無ければ PowerShell CIM
    out = _run(["wmic", "cpu", "get", "Name", "/value"])
    for line in out.splitlines():
        if line.startswith("Name="):
            v = line.split("=", 1)[1].strip()
            if v:
                return v
    v = _powershell("(Get-CimInstance Win32_Processor).Name").strip()
    if v:
        # 複数行(物理 CPU が複数)の場合は先頭行
        return v.splitlines()[0].strip()
    try:
        import platform as _p
        return _p.processor() or None
    except Exception:
        return None


def _win_ram_gb() -> Optional[int]:
    out = _run(["wmic", "ComputerSystem", "get", "TotalPhysicalMemory", "/value"])
    for line in out.splitlines():
        if line.startswith("TotalPhysicalMemory="):
            try:
                b = int(line.split("=", 1)[1].strip())
                return max(1, round(b / (1024 ** 3)))
            except Exception:
                pass
    # Win11: wmic 不在 → PowerShell CIM
    v = _powershell("(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory").strip()
    try:
        if v:
            return max(1, round(int(v.splitlines()[0]) / (1024 ** 3)))
    except Exception:
        pass
    return None


def _win_gpu() -> tuple:
    """(gpu_name, vram_gb, cuda_available) を返す。"""
    name = None
    vram = None
    cuda = False

    # 1) nvidia-smi が最も信頼できる(NVIDIA GPU のみ)
    smi = shutil.which("nvidia-smi")
    if smi:
        out = _run([smi, "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"])
        if out.strip():
            first = out.strip().splitlines()[0]
            parts = [p.strip() for p in first.split(",")]
            if len(parts) >= 2:
                name = parts[0]
                try:
                    mb = int(parts[1])
                    vram = max(1, round(mb / 1024))
                except Exception:
                    pass
            cuda = True

    # 2) torch があれば CUDA 利用可否を再確認
    if not cuda:
        try:
            import torch  # type: ignore
            cuda = bool(getattr(torch, "cuda", None) and torch.cuda.is_available())
            if cuda and not name:
                try:
                    name = torch.cuda.get_device_name(0)
                except Exception:
                    pass
        except Exception:
            pass

    # 3) どちらも失敗したら wmic / PowerShell で GPU 名だけは拾う
    if not name:
        out = _run(["wmic", "path", "Win32_VideoController", "get", "Name", "/value"])
        for line in out.splitlines():
            if line.startswith("Name="):
                v = line.split("=", 1)[1].strip()
                if v:
                    name = v
                    break
    if not name:
        v = _powershell("(Get-CimInstance Win32_VideoController | Select-Object -First 1).Name").strip()
        if v:
            name = v.splitlines()[0].strip()

    return name, vram, cuda


# ---------- macOS ----------

def _mac_cpu_name() -> Optional[str]:
    v = _run(["sysctl", "-n", "machdep.cpu.brand_string"]).strip()
    return v or None


def _mac_ram_gb() -> Optional[int]:
    v = _run(["sysctl", "-n", "hw.memsize"]).strip()
    try:
        return max(1, round(int(v) / (1024 ** 3)))
    except Exception:
        return None


def _mac_gpu() -> tuple:
    """(gpu_name, vram_gb, cuda_available) を返す。Mac は cuda_available 常に False。"""
    name = None
    vram = None
    out = _run(["system_profiler", "SPDisplaysDataType"])
    # Chipset Model: Apple M2 / VRAM (Total): 16 GB など
    m = re.search(r"Chipset Model:\s*(.+)", out)
    if m:
        name = m.group(1).strip()
    m = re.search(r"(?:VRAM \(Total\)|Metal Support).*?(\d+)\s*(MB|GB)", out, re.IGNORECASE)
    if m:
        n = int(m.group(1))
        if m.group(2).upper() == "MB":
            vram = max(1, round(n / 1024))
        else:
            vram = n
    return name, vram, False


def detect() -> dict:
    plat = sys.platform
    arch = platform.machine().lower()
    info = {
        "os": None,
        "arch": arch,
        "cpu": None,
        "ram_gb": None,
        "gpu_name": None,
        "gpu_vram_gb": None,
        "cuda_available": False,
        "apple_silicon": False,
    }

    if plat == "win32":
        info["os"] = "windows"
        info["cpu"] = _win_cpu_name()
        info["ram_gb"] = _win_ram_gb()
        gpu_name, vram, cuda = _win_gpu()
        info["gpu_name"] = gpu_name
        info["gpu_vram_gb"] = vram
        info["cuda_available"] = cuda
    elif plat == "darwin":
        info["os"] = "darwin"
        info["cpu"] = _mac_cpu_name()
        info["ram_gb"] = _mac_ram_gb()
        gpu_name, vram, _ = _mac_gpu()
        info["gpu_name"] = gpu_name
        info["gpu_vram_gb"] = vram
        info["apple_silicon"] = arch in ("arm64", "aarch64")
    else:
        info["os"] = plat

    return info


def main():
    info = detect()
    json.dump(info, sys.stdout, ensure_ascii=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
