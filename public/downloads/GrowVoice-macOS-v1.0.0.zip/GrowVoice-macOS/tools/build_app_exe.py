# -*- coding: utf-8 -*-
"""build_app_exe.py - 専用 exe「音声入力ツール.exe」を作る。

Windows のタスクバー設定リストやトレイで「Python」+別アイコンと表示される
問題を解消する。 python.exe を venv の Scripts 内にコピーし、 rcedit で
赤マイクの .ico と表示名(音声入力ツール)を埋め込む。

venv の Scripts 内に作るので site-packages 等の依存解決はそのまま効く。
手順: python.exe をコピー → rcedit で赤マイク .ico と表示名を埋め込み →
PE ヘッダのサブシステムを「窓なし(GUI)」に1バイト書き換える。
これで「赤マイクアイコン + 表示名 + ターミナル窓なし」を同時に満たす。
(rcedit は pythonw.exe コピーへの書き込みに失敗するため、この順番にする。)
以前ターミナルに出ていた内容は logs/app.log に残り、設定画面の
「動作ログ」タブで確認できる。
"""

import os
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RCEDIT = ROOT / "tools" / "rcedit-x64.exe"
ICON = ROOT / "assets" / "voice_input.ico"
SCRIPTS = ROOT / ".venv" / "Scripts"
SRC_EXE = SCRIPTS / "python.exe"          # コンソール版(rcedit が扱える)
DST_EXE = SCRIPTS / "音声入力ツール.exe"

_SUBSYSTEM_WINDOWS = 2   # 窓なし(GUI)
_SUBSYSTEM_CONSOLE = 3   # コンソール


def _set_windowless(exe_path):
    """PE の Subsystem を「窓なし(GUI)」に書き換える(editbin 不要)。

    DOS ヘッダ 0x3C の値が PE シグネチャ位置。そこ +0x5C が Subsystem(2byte)。
    """
    try:
        data = bytearray(exe_path.read_bytes())
        pe = struct.unpack_from("<I", data, 0x3C)[0]
        if data[pe:pe + 4] != b"PE\x00\x00":
            print("  【警告】PE 署名が見つからず、窓なし化をスキップしました。")
            return False
        off = pe + 0x5C
        if data[off] == _SUBSYSTEM_CONSOLE:
            data[off] = _SUBSYSTEM_WINDOWS
            exe_path.write_bytes(data)
        return data[off] == _SUBSYSTEM_WINDOWS
    except Exception as e:
        print(f"  【警告】窓なし化に失敗(コンソール窓が出ます): {e}")
        return False


def main():
    if not SRC_EXE.exists():
        print(f"  python.exe が見つかりません: {SRC_EXE}")
        return 1
    # Windows Defender が venv\Scripts 内の書き換えを保護して rcedit が失敗する
    # ことがあるため、一時フォルダで加工してから配置する。
    tmp_fd, tmp_name = tempfile.mkstemp(suffix=".exe", prefix="voiceapp_")
    os.close(tmp_fd)
    tmp = Path(tmp_name)
    try:
        shutil.copy2(SRC_EXE, tmp)
        if RCEDIT.exists() and ICON.exists():
            cmd = [
                str(RCEDIT), str(tmp),
                "--set-icon", str(ICON),
                "--set-version-string", "FileDescription", "音声入力ツール",
                "--set-version-string", "ProductName", "音声入力ツール",
                "--set-version-string", "OriginalFilename", "音声入力ツール.exe",
            ]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode == 0:
                print("  アイコンと表示名を埋め込みました。")
            else:
                print(f"  rcedit 失敗(アイコンなしで継続): {r.stderr.strip()}")
        else:
            print("  rcedit か .ico が無いので埋め込みは skip(make_ico.py を先に)。")
        if _set_windowless(tmp):
            print("  窓なし(ターミナルを出さない)に設定しました。")
        shutil.copy2(tmp, DST_EXE)
        print(f"  配置: {DST_EXE.name}")
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass
    print("  完了。 ツールを起動し直すと『音声入力ツール』として表示されます。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
