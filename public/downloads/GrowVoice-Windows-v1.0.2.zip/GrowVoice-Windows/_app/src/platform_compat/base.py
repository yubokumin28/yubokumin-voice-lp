# -*- coding: utf-8 -*-
"""base.py - OS抽象層のインターフェース仕様(ドキュメント用)

このファイルは「windows.py / macos.py が何を実装すべきか」を
1ヶ所にまとめたドキュメントを兼ねる。実行時の import 対象では無いが、
新しい OS 対応(例: Linux)を足す時はここの仕様に従って実装する。

各関数の意味と契約:

--- ホットキー --------------------------------------------------------------
register_hotkey_listener(key_label, on_press, on_release)
  key_label    : "right ctrl" / "right alt" など、hotkey.py で扱う表記
  on_press     : 録音キーが押された瞬間に1引数なしで呼ばれる callback
  on_release   : 録音キーが離れた瞬間に1引数なしで呼ばれる callback
  戻り値: listener オブジェクト(unregister_hotkey_listener で渡す)

unregister_hotkey_listener(listener)
  listener を停止して内部リソースを解放する。

is_modifier_held(name)
  name : "ctrl" / "alt" / "shift" のいずれか
  戻り値: 今その修飾キーが押下中なら True。
          挿入直前の修飾キー解放待ちで使う(inserter.py)。

--- カーソル位置への挿入 ---------------------------------------------------
paste_at_cursor()
  「いま貼り付けキーを送る」だけ。前段でクリップボードに本文を入れて呼ぶ。
  Win: keyboard.send("ctrl+v") / Mac: AppleScript "keystroke v using cmd"。

type_text_directly(text) -> bool
  IME を通さずに Unicode 文字列を直接注入する。
  クリップボードが使えない時のフォールバック。
  Mac には等価機能が無いので False を返してよい(呼び出し側はリトライ)。

--- 単一インスタンス -------------------------------------------------------
SingleInstance(name)
  名前付き排他オブジェクトで二重起動を抑止する。
  属性 already_running: 既に別インスタンスが居れば True
  メソッド release(): リソース解放(プロセス終了時に自動でも解放される)

--- 自動起動(ログイン時に常駐) ------------------------------------------
is_autostart_enabled() -> bool
toggle_autostart() -> bool       # 切替後の状態(オンにしたら True)を返す
                                 # 失敗時は元の状態のまま False を返す等は OS 側で安全に
get_autostart_description() -> str
  「Windowsスタートアップ」「macOS LaunchAgent」など、設定 UI で
  旦那様/ユーザーに表示する説明文。

--- 子プロセス起動(無窓・分離) ------------------------------------------
find_no_console_python() -> str
  ターミナル窓を出さずに Python スクリプトを動かすための実行ファイルパス。
  Win: pythonw.exe / Mac: ふつうの python(Mac は GUI 起動で窓は出ない)

spawn_detached(python_path, script_path, *args, low_priority=False)
  子プロセスを親 console から完全分離して起動する。
  低優先度起動オプションあり(自動推敲など裏方処理を遅らせるため)。

--- パス・OS UI を開く ----------------------------------------------------
open_path(path)
  ファイルやフォルダを既定アプリで開く。
  Win: os.startfile / Mac: subprocess.run(["open", path])

open_system_taskbar_settings()
  トレイアイコン常時表示のための OS 側設定画面を開く。
  Win: ms-settings:taskbar / Mac: System Settings の "Menu Bar" ページ

--- プロセス生存確認 ------------------------------------------------------
is_process_alive(pid) -> bool
  指定 PID が生きているか。overlay.py が親プロセスの生死を見るのに使う。

--- モニタ座標 ------------------------------------------------------------
get_active_monitor_work_rect() -> tuple(left, top, right, bottom) | None
  フォアグラウンドのウィンドウがあるモニターの「作業領域」(タスクバー/
  Dock を除いた領域)。overlay.py の状態表示位置決めに使う。

--- Ollama バックグラウンド起動 --------------------------------------------
ensure_ollama_running(ollama_url, timeout) -> bool
  Ollama に軽く接続確認し、応答が無ければトレイアプリ/Ollama.appを
  無窓で起動する。既に起動中・未導入ならそのまま何もせず False/True を
  ケースに応じて返す(例外は握りつぶす安全側)。① 自動推敲 ON 時のみ呼ぶ。

--- 起動直後ウォームアップ ------------------------------------------------
warmup()
  初回挿入の遅延を消すため、起動時に1回だけ呼ぶ。
  Win: pyperclip(OLE)と keyboard を暖機 / Mac: pyperclip と pynput を暖機。

これらの関数が実装されていれば、本体側は OS を一切意識しない。
"""

# このモジュールは実行されない(ドキュメント専用)。
# 実装側(windows.py / macos.py)が __all__ に必要な名前を並べる。
