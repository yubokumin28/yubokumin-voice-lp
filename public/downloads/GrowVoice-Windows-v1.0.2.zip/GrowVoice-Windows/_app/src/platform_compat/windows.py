# -*- coding: utf-8 -*-
"""windows.py - platform_compat の Windows 実装

旦那様の既存 Windows 環境の挙動を「1ミリも変えない」ことが本ファイルの最優先要件。
既存の inserter.py / singleton.py / tray.py / overlay.py に書かれているロジックを
そのまま関数化して移送している。

このファイルが読まれるのは sys.platform == "win32" のときのみ。
Mac 用の依存(pynput, pyobjc)は一切 import しない。
"""

import ctypes
from ctypes import wintypes
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import keyboard
import pyperclip


# ---------------------------------------------------------------------------
# パス情報(ROOT は呼び出し側から差し替え可能。既定はこのファイルから2階層上)
# ---------------------------------------------------------------------------
if getattr(sys, "frozen", False):
    # 単体exe(PyInstaller)時は exe のあるフォルダを基準にする。
    _ROOT = Path(sys.executable).resolve().parent
else:
    _ROOT = Path(__file__).resolve().parents[2]


def set_project_root(path):
    """呼び出し側からプロジェクト直下のパスを差し込む(主に tests 用)。"""
    global _ROOT
    _ROOT = Path(path)


# ===========================================================================
# ホットキー
# ===========================================================================

def is_modifier_held(name):
    """name(ctrl / alt / shift)が今押下中か。"""
    try:
        return keyboard.is_pressed(name)
    except Exception:
        return False


def register_hotkey_listener(key_label, on_press, on_release):
    """録音キーのフックを登録する(Windows: keyboard ライブラリ)。

    既存の hotkey_app.py はこれまで keyboard を直接使っていたが、
    Mac 対応のために間に挟む薄いラッパーを置く。挙動は素通し。
    listener は keyboard ライブラリのハンドル(int)。
    """
    handles = []
    handles.append(keyboard.on_press_key(
        key_label, lambda _e: on_press(), suppress=False))
    handles.append(keyboard.on_release_key(
        key_label, lambda _e: on_release(), suppress=False))
    return handles


def unregister_hotkey_listener(listener):
    """register_hotkey_listener が返したハンドル群を解除する。"""
    if not listener:
        return
    for h in listener:
        try:
            keyboard.unhook(h)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 全キーを on_event(event) に流す汎用フック群(hotkey_app.py 用)
# ---------------------------------------------------------------------------
# 既存 hotkey_app.py は keyboard.hook / add_hotkey / unhook_all / wait を直接
# 叩いていた。Mac でも同じ意味論を実現するため、間に薄い 4 API を挟む。
# Windows ではすべて keyboard ライブラリへの素通しで挙動は 1 ミリも変わらない。
# event オブジェクトは .name(キー名)と .event_type("down" / "up")を持つ。

def install_global_key_hook(on_event):
    """全キーの押下/解放イベントを on_event(event) に流す。

    event.event_type は "down" or "up"(keyboard ライブラリの定数は元から
    文字列なので、Win/Mac で同じ文字列で比較できる)。
    戻り値: keyboard.hook が返すハンドル(unhook 用)。
    """
    return keyboard.hook(on_event)


def add_emergency_reset_hotkey(label, callback):
    """単発の緊急リセットキーを登録する(例 "pause" で callback を呼ぶ)。"""
    return keyboard.add_hotkey(label, callback)


def unhook_all_global():
    """install_global_key_hook / add_emergency_reset_hotkey で登録した
    フックを全解除する。再登録(keepalive)前に呼ぶ。"""
    try:
        keyboard.unhook_all()
    except Exception:
        pass


def wait_forever():
    """メインスレッドを常駐させる(プロセスが終了するまでブロック)。"""
    keyboard.wait()


# ===========================================================================
# カーソル位置への挿入(既存 inserter.py の挙動を完全保存)
# ===========================================================================

def paste_at_cursor():
    """貼り付けキー(Ctrl+V)を送る。

    既存 inserter._paste_keystroke と同じ:
      - 修飾キー(Ctrl/Alt)の解放を最大 250ms 待つ
      - 解放されれば keyboard.send("ctrl+v")
      - 待ち切れない場合は v 単押し(押下中の Ctrl と合成)
    """
    if _wait_modifiers_release():
        keyboard.send("ctrl+v")
    else:
        keyboard.press("v")
        time.sleep(0.02)
        keyboard.release("v")


def type_text_directly(text):
    """IME を通さず Unicode を直接注入する(クリップボード不可時のフォールバック)。"""
    try:
        keyboard.write(text, delay=0.005)
        return True
    except Exception:
        return False


def _wait_modifiers_release(max_wait=0.25, poll=0.01):
    """Ctrl/Alt の解放を最大 max_wait 秒待つ。既存 inserter と同じ値。"""
    waited = 0.0
    while waited < max_wait:
        if not is_modifier_held("ctrl") and not is_modifier_held("alt"):
            return True
        time.sleep(poll)
        waited += poll
    return False


# ===========================================================================
# 単一インスタンス制御(既存 singleton.py を完全踏襲)
# ===========================================================================

_MUTEX_NAME = "Local\\VoiceInputTool_SingleInstance"
_ERROR_ALREADY_EXISTS = 183


class SingleInstance:
    """名前付きミューテックスによる単一インスタンス制御。"""

    def __init__(self, name=_MUTEX_NAME):
        self._kernel32 = ctypes.windll.kernel32
        self._handle = self._kernel32.CreateMutexW(None, False, name)
        last_error = self._kernel32.GetLastError()
        self.already_running = last_error == _ERROR_ALREADY_EXISTS

    def release(self):
        if self._handle:
            self._kernel32.CloseHandle(self._handle)
            self._handle = None


# ===========================================================================
# 自動起動(スタートアップに無窓起動 .vbs を置く / 既存 tray.py 流儀)
# ===========================================================================

_STARTUP_VBS_NAME = "音声入力ツール_自動起動.vbs"
_LAUNCH_BAT_NAME = "音声入力を起動.bat"


def _startup_dir():
    return (Path(os.environ.get("APPDATA", ""))
            / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")


def _startup_vbs_path():
    return _startup_dir() / _STARTUP_VBS_NAME


def is_autostart_enabled():
    try:
        return _startup_vbs_path().exists()
    except Exception:
        return False


def toggle_autostart():
    """自動起動を ON/OFF 反転。切替後の状態(True=ON)を返す。失敗時は元の状態。"""
    try:
        vbs = _startup_vbs_path()
        launch_bat = _ROOT / _LAUNCH_BAT_NAME
        if vbs.exists():
            vbs.unlink()
            return False
        vbs.parent.mkdir(parents=True, exist_ok=True)
        content = (
            'CreateObject("WScript.Shell").Run """'
            + str(launch_bat)
            + '""", 0, False\r\n'
        )
        vbs.write_text(content, encoding="cp932")
        return True
    except Exception:
        return is_autostart_enabled()


def get_autostart_description():
    return "Windows スタートアップ"


# ===========================================================================
# 子プロセス起動(無窓・分離) 既存 tray._spawn_detached と同等
# ===========================================================================

def find_no_console_python():
    """ターミナル窓を出さない pythonw.exe を返す。"""
    candidates = [
        _ROOT / ".venv" / "Scripts" / "pythonw.exe",
        Path(sys.executable).with_name("pythonw.exe"),
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    return sys.executable


def _popen_detached(cmd, low_priority=False):
    """コマンド列を親 console から完全分離して起動する(内部共通処理)。"""
    kwargs = {
        "cwd": str(_ROOT),
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
    }
    flags = (subprocess.CREATE_NEW_PROCESS_GROUP
             | getattr(subprocess, "DETACHED_PROCESS", 0x00000008))
    if low_priority:
        flags |= getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS",
                         0x00004000)
    kwargs["creationflags"] = flags
    subprocess.Popen(cmd, **kwargs)


def spawn_detached(python_path, script_path, *args, low_priority=False):
    """子プロセスを親 console から完全分離して起動する。"""
    _popen_detached([python_path, str(script_path), *args],
                    low_priority=low_priority)


# 役割名 -> 開発実行(.py)時のスクリプト名
_MODE_SCRIPTS = {
    "overlay": "overlay.py",
    "settings": "settings_ui.py",
    "proofread": "proofread_cli.py",
}


def spawn_app_mode(mode, *args, low_priority=False):
    """アプリの補助プロセス(録音ランプ/設定/推敲)を起動する。

    単体exe(frozen)時は exe 自身を `--gv-mode <mode>` で呼び直す。
    開発実行(.py)時は従来どおり 無窓 Python で src/*.py を起動する。
    呼び出し側は OS や frozen を意識しない。
    """
    str_args = [str(a) for a in args]
    if getattr(sys, "frozen", False):
        cmd = [sys.executable, "--gv-mode", mode, *str_args]
        _popen_detached(cmd, low_priority=low_priority)
        return
    pythonw = find_no_console_python()
    script = str(_ROOT / "src" / _MODE_SCRIPTS[mode])
    _popen_detached([pythonw, script, *str_args], low_priority=low_priority)


# ===========================================================================
# パス・OS UI を開く
# ===========================================================================

def open_path(path):
    """ファイル/フォルダを既定アプリで開く(Win: os.startfile)。"""
    os.startfile(str(path))


def open_system_taskbar_settings():
    """Windows のタスクバー設定を開く。"""
    os.startfile("ms-settings:taskbar")


# ===========================================================================
# プロセス生存確認(既存 overlay._parent_alive 同等)
# ===========================================================================

def is_process_alive(pid):
    if pid <= 0:
        return True
    try:
        PROCESS_QUERY_LIMITED = 0x1000
        h = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED, False, pid)
        if not h:
            return False
        ctypes.windll.kernel32.CloseHandle(h)
        return True
    except Exception:
        return True


# ===========================================================================
# モニタ座標(既存 overlay._get_active_monitor_work_rect 同等)
# ===========================================================================

class _RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


class _MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", _RECT),
                ("rcWork", _RECT), ("dwFlags", wintypes.DWORD)]


_MONITOR_DEFAULTTONEAREST = 2


def get_active_monitor_work_rect():
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        hmon = user32.MonitorFromWindow(hwnd, _MONITOR_DEFAULTTONEAREST)
        if not hmon:
            return None
        mi = _MONITORINFO()
        mi.cbSize = ctypes.sizeof(mi)
        if not user32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            return None
        r = mi.rcWork
        return (int(r.left), int(r.top), int(r.right), int(r.bottom))
    except Exception:
        return None


# ===========================================================================
# Ollama バックグラウンド起動(① 自動推敲 ON 時に使う・2026-07-19)
# ===========================================================================

def ensure_ollama_running(ollama_url="http://localhost:11434", timeout=0.8):
    """Ollama が起動していなければトレイアプリを無窓で起動する。

    既に起動中ならAPI応答で分かるので何もしない(多重起動防止)。
    未導入なら静かに諦める(安全側。proofread_cli と同じ思想)。
    """
    import urllib.request

    try:
        with urllib.request.urlopen(
                ollama_url.rstrip("/") + "/api/tags", timeout=timeout):
            return True  # 既に起動中
    except Exception:
        pass
    try:
        exe = (Path(os.environ.get("LOCALAPPDATA", ""))
               / "Programs" / "Ollama" / "ollama app.exe")
        if not exe.exists():
            return False  # 未導入
        subprocess.Popen(
            [str(exe)],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        return True
    except Exception:
        return False


# ===========================================================================
# 起動直後ウォームアップ(既存 inserter.warmup と同等)
# ===========================================================================

def warmup():
    """pyperclip(OLE)と keyboard の初回コストを起動時に潰す。"""
    try:
        original = pyperclip.paste()
        pyperclip.copy(original or "")
    except Exception:
        pass
    try:
        keyboard.is_pressed("ctrl")
        keyboard.is_pressed("alt")
    except Exception:
        pass


__all__ = [
    "set_project_root",
    "is_modifier_held",
    "register_hotkey_listener",
    "unregister_hotkey_listener",
    "install_global_key_hook",
    "add_emergency_reset_hotkey",
    "unhook_all_global",
    "wait_forever",
    "paste_at_cursor",
    "type_text_directly",
    "SingleInstance",
    "is_autostart_enabled",
    "toggle_autostart",
    "get_autostart_description",
    "find_no_console_python",
    "spawn_detached",
    "spawn_app_mode",
    "open_path",
    "open_system_taskbar_settings",
    "is_process_alive",
    "get_active_monitor_work_rect",
    "warmup",
    "ensure_ollama_running",
]
